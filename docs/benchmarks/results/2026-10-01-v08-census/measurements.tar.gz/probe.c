#include <sys/socket.h>
#include <sys/random.h>
#include <unistd.h>
int main(void){int s[2];char data[1024]={0};if(socketpair(AF_UNIX,SOCK_STREAM,0,s))return 1;if(write(s[0],data,sizeof(data))!=sizeof(data))return 2;if(read(s[1],data,sizeof(data))!=sizeof(data))return 3;if(getentropy(data,8))return 4;close(s[0]);close(s[1]);return 0;}
