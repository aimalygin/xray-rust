#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/random.h>
#include <stdlib.h>
#include <unistd.h>
int main(void){int s[2];char data[5120]={0};if(socketpair(AF_UNIX,SOCK_STREAM,0,s))return 1;if(write(s[0],data,1024)!=1024)return 2;if(read(s[1],data,1024)!=1024)return 3;struct iovec v[]={{data,1024},{data+1024,4096}};if(writev(s[0],v,2)!=5120)return 4;if(read(s[1],data,5120)!=5120)return 5;if(getentropy(data,8))return 6;arc4random_buf(data,16);close(s[0]);close(s[1]);return 0;}
