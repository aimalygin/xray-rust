from pathlib import Path
import hashlib,importlib.util,json,re,statistics
n=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('parity_summary',n/'collector-source/summarize-v07-protocol-parity.py');summary=importlib.util.module_from_spec(spec);spec.loader.exec_module(summary)
def read(p):return json.loads(p.read_text())
def heap(path):
 match=re.search(r'All zones: (\d+) nodes \((\d+) bytes\)',path.read_text());assert match,path
 return dict(nodes=int(match[1]),bytes=int(match[2]))
def amount(s):
 match=re.fullmatch(r'([\d.]+)([KMG]?)',s);assert match,s
 return float(match[1])*{'':1,'K':1024,'M':1048576,'G':1073741824}[match[2]]
def vmmap(path):
 text=path.read_text();fp=re.search(r'^Physical footprint:\s*(\S+)',text,re.M)
 zone_line=next((x for x in text.splitlines() if x.startswith('DefaultMallocZone')),None)
 if zone_line is None:
  assert 'No malloc zones in target process' in text,path
  return dict(physical_footprint_approx_bytes=amount(fp[1]),zone_unavailable=True,exclusion_reason='Target not fully started: dyld initialized, libSystem not yet initialized; do not use this startup snapshot as initialized allocator baseline')
 zone=zone_line.split()
 return dict(physical_footprint_approx_bytes=amount(fp[1]),zone_resident_approx_bytes=amount(zone[2]),zone_dirty_approx_bytes=amount(zone[3]),zone_swapped_approx_bytes=amount(zone[4]),zone_nodes=int(zone[5]),zone_live_approx_bytes=amount(zone[6]),zone_fragmentation_approx_bytes=amount(zone[7]),zone_fragmentation_percent=int(zone[8].rstrip('%')),raw_zone_line=' '.join(zone))
groups=[]
for name,count in [('h2-tun-memory-reproduction',30),('h2-tun-allocator-control',20)]:
 root=n/'evidence'/name;m=read(root/'manifest.json');q=read(root/'measurement-quality.json');s=read(root/'summary.json')
 assert m.get('finished_unix') and len(m['runs'])==count and m['status']=='pass'
 assert all(x['returncode']==0 and not x.get('surviving_process_group') and not x.get('remaining_engine_processes') for x in m['runs'])
 comparisons=[]
 for row in s['rows']:
  a=row['versions']['candidate']['metrics']
  for version,v in row['versions'].items():
   if version=='candidate':continue
   b=v['metrics'];metrics={}
   for k in ['rss_mib','cpu_ms','throughput_mib_s']:
    ratio=a[k]['median']/b[k]['median'];metrics[k]=dict(ratio=ratio,paired_bootstrap_95pct=summary.ratio_interval(a[k]['samples'],b[k]['samples']))
   comparisons.append(dict(case=row['case'],reference=version,metrics=metrics))
 groups.append(dict(name=name,runs=count,quality=q,versions=m['versions'],rows=s['rows'],candidate_comparisons=comparisons,manifest_sha256=hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()))
profiles=[]
for family,expected in [('profiles',8),('relief-profiles',4)]:
 dirs=sorted((n/family).iterdir());assert len(dirs)==expected
 for root in dirs:
  d=read(root/'diagnostic.json');assert d['returncode']==0 and d['usable_for_performance'] is False
  row=dict(family=family,name=root.name,case=d['case'],version=d['version'],engine_sha256=d['engine_sha256'],relief_reported_bytes=d.get('relief_reported_bytes'),snapshots=[])
  for snap in d['snapshots']:
   assert all(t['returncode']==0 for t in snap['tools'])
   stage=snap['stage'];item=dict(stage=stage,rss_before_bytes=int(snap['ps_before'].split(None,4)[2])*1024,rss_after_bytes=int(snap['ps_after'].split(None,4)[2])*1024,vmmap=vmmap(root/(stage+'-vmmap.txt')),
     after_checkpoint_already_present=snap['after_checkpoint_already_present'],after_checkpoint_present_at_end=snap['after_checkpoint_present_at_end'])
   hp=root/(stage+'-heap.txt')
   if hp.exists():item['heap']=heap(hp)
   row['snapshots'].append(item)
  by={x['stage']:x for x in row['snapshots']}
  row['live_heap_stable_after_to_idle10']=by['after']['heap']==by['idle10']['heap']
  if family=='relief-profiles':
   row['relief_live_heap_unchanged']=by['idle10']['heap']==by['relieved']['heap']
   row['relief_rss_change_bytes']=by['relieved']['rss_before_bytes']-by['idle10']['rss_before_bytes']
  profiles.append(row)
result=dict(timed_groups=groups,profiles=profiles,timed_runs=50,diagnostic_runs=12,original_evidence_replaced=False,runtime_changed=False,
 interpretation='RSS/free allocator region retention and fragmentation must remain separate from live allocations; no long-term leak or universal memory parity claim',
 profiler_caveat='The baseline2 case of plain/relief profiles also applied the worker setting to the harness via inherited environment. These diagnostic snapshots are not timings; the final allocator control applies overrides only to client_env and keeps the harness/server policy constant.')
(n/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'timed_runs':50,'diagnostic_runs':12,'quality':{g['name']:g['quality']['compiler_load_detected'] for g in groups},'all_live_heaps_stable_after_to_idle10':all(p['live_heap_stable_after_to_idle10'] for p in profiles)},indent=2))
for g in groups:
 print(g['name'])
 for row in g['rows']:
  print(row['case'],{v:{k:round(x['median'],4) for k,x in data['metrics'].items() if k in ['throughput_mib_s','cpu_ms','rss_mib']} for v,data in row['versions'].items()})
