"""Build only after reproduction completes; measured engine binaries stay unchanged."""
from pathlib import Path
import hashlib,json,os,subprocess,time
n=Path(__file__).resolve().parent;old=Path('/private/tmp/xray-v07-parity-20260920')
m=json.loads((n/'evidence/h2-tun-memory-reproduction/manifest.json').read_text())
assert m.get('finished_unix') and len(m['runs'])==30 and m['status']=='pass'
s=n/'harness-source';assert not s.exists()
subprocess.run(['git','clone','--shared',str(old/'protocol-followup-source'),str(s)],check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()=='b9577f874b3f102880ae078038855803d85f5d04'
p=s/'crates/xray-bench/src/protocol_bench.rs';text=p.read_text()
marker='/// Run one fresh child, retain validated payload counts and raw resource samples.'
code='''// Private diagnostic harness only: all such runs are excluded from timings.
async fn memory_checkpoint(stage: &str, pid: u32) -> Result<(), BenchError> {
    let Some(root) = std::env::var_os("XRAY_BENCH_MEMORY_CHECKPOINTS") else {
        return Ok(());
    };
    let root = PathBuf::from(root);
    let path = root.join(format!("{stage}.json"));
    fs::write(path, serde_json::to_vec(&json!({"stage":stage,"pid":pid,
        "time_unix":std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_secs_f64()})).map_err(|e| invalid(e.to_string()))?).map_err(io_error)?;
    let deadline = Instant::now() + Duration::from_secs(60);
    while !root.join(format!("{stage}.continue")).exists() {
        if Instant::now() >= deadline { return Err(invalid("memory checkpoint timed out")); }
        sleep(Duration::from_millis(25)).await;
    }
    Ok(())
}

'''
assert text.count(marker)==1;text=text.replace(marker,code+marker)
a='    let options = BenchOptions {';assert text.count(a)==1
text=text.replace(a,'    let diagnostic_pid = child.child.id();\n    memory_checkpoint("before", diagnostic_pid).await?;\n'+a)
a='        phase.set(BenchmarkPhase::Settle);\n        sleep(Duration::from_millis(500)).await;';assert text.count(a)==1
text=text.replace(a,'''        phase.set(BenchmarkPhase::Settle);
        memory_checkpoint("after", diagnostic_pid).await?;
        if std::env::var_os("XRAY_BENCH_MEMORY_CHECKPOINTS").is_some() {
            sleep(Duration::from_secs(10)).await;
            memory_checkpoint("idle", diagnostic_pid).await?;
        }
        sleep(Duration::from_millis(500)).await;''')
text=text.replace('"peak_rss_kib":summary.peak_rss_kib,"cpu_millis":cpu_ms,','"peak_rss_kib":summary.peak_rss_kib,"cpu_millis":cpu_ms,\n                "diagnostic_memory_checkpoints":std::env::var_os("XRAY_BENCH_MEMORY_CHECKPOINTS").is_some(),')
p.write_text(text)
subprocess.run(['rustfmt','--edition','2021',str(p)],cwd=s,check=True)
subprocess.run(['git','add','crates/xray-bench/src/protocol_bench.rs'],cwd=s,check=True)
subprocess.run(['git','commit','-m','Add private diagnostic memory checkpoints around TUN workload'],cwd=s,check=True)
patch=subprocess.check_output(['git','diff','--binary','HEAD^','HEAD'],cwd=s);(n/'diagnostic-harness.patch').write_bytes(patch)
env=dict(os.environ,CARGO_TARGET_DIR=str(n/'harness-build'));start=time.time()
command=['cargo','build','--offline','--locked','--release','-p','xray-bench','--bin','xray-bench']
with (n/'diagnostic-harness-build.log').open('w') as f:subprocess.run(command,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
binary=n/'harness-build/release/xray-bench'
record=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),parent_runtime_commit='b9577f874b3f102880ae078038855803d85f5d04',patch_sha256=hashlib.sha256(patch).hexdigest(),binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),command=command,seconds=time.time()-start,diagnostic_only=True,measured_engine_binaries_unchanged=True)
(n/'diagnostic-harness-build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
