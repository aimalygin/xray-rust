"""Profile only owned frozen clients; checkpoints and debugger snapshots invalidate timings."""
from pathlib import Path
import hashlib,importlib.util,json,os,signal,subprocess,time,sys
n=Path(__file__).resolve().parent;old=Path('/private/tmp/xray-v07-parity-20260920');s=old/'h3-read-batch-source'
spec=importlib.util.spec_from_file_location('bench',s/'scripts/run-v07-performance.py');bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
hmeta=json.loads((n/'diagnostic-harness-build.json').read_text());harness=Path(hmeta['binary'])
assert bench.sha(harness)==hmeta['binary_sha256']
engines={'baseline':Path('/private/tmp/xray-v07-bench-20260919/bin/baseline/xray-rust'),'candidate':old/'bin/reviewed-parity/xray-rust','workers12':old/'bin/reviewed-parity-workers12/xray-rust'}
engines['baseline2']=engines['baseline']
records=[]
for case,traffic,count in [('upload8','upload',8)]:
 for version in (list(engines) if case=='duplex1' else list(reversed(engines))):
  binary=engines[version];out=n/'relief-profiles'/(case+'-'+version);out.mkdir(parents=True,exist_ok=False)
  markers=out/'checkpoints';markers.mkdir()
  rec=dict(case=case,version=version,helper_sha256=bench.sha(n/'allocator-relief.dylib'),engine=str(binary),engine_sha256=bench.sha(binary),harness=hmeta,diagnostic_only=True,usable_for_performance=False,reason='diagnostic malloc relief helper, checkpoints and heap/vmmap snapshots; not a speed or baseline RSS comparison',snapshots=[])
  def save():bench.save(out/'diagnostic.json',rec)
  def ps(pid):return subprocess.check_output(['ps','-p',str(pid),'-o','pid=,ppid=,rss=,time=,command='],text=True).strip()
  def wait_stage(stage,child):
   p=markers/(stage+'.json');deadline=time.monotonic()+100
   while not p.exists():
    if child.poll() is not None:raise RuntimeError('diagnostic harness exited before '+stage)
    if time.monotonic()>deadline:raise TimeoutError(stage)
    time.sleep(.025)
   value=json.loads(p.read_text());assert value['pid']==rec.get('pid',value['pid']);return value
  def snapshot(stage,pid,with_heap=True):
   item=dict(stage=stage,started_unix=time.time(),ps_before=ps(pid),after_checkpoint_already_present=(markers/'after.json').exists(),tools=[])
   commands=[('vmmap',['vmmap','-summary',str(pid)])]
   if with_heap:commands.append(('heap',['heap','--sortBySize','--showSizes',str(pid)]))
   for name,args in commands:
    path=out/(stage+'-'+name+'.txt');start=time.time()
    with path.open('w') as f:code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=30).returncode
    item['tools'].append(dict(name=name,command=args,returncode=code,seconds=time.time()-start,path=path.name))
    if code:raise RuntimeError('snapshot failed: '+str(path))
   item.update(finished_unix=time.time(),ps_after=ps(pid),after_checkpoint_present_at_end=(markers/'after.json').exists())
   rec['snapshots'].append(item);save()
  print('START',case,version,flush=True)
  with bench.fixture(old/'bin/xray-core',out/'server') as configs:
   trigger=out/'relief.trigger';reply=out/'relief.reply'
   request=dict(binary=str(binary),config=configs['xhttp-h2'],path='tun',traffic=traffic,connections=count,iterations=8192,payload_size=65536,output=str(out/'run'),client_env={'DYLD_INSERT_LIBRARIES':str(n/'allocator-relief.dylib'),'H2_MEMORY_RELIEF_TRIGGER':str(trigger),'H2_MEMORY_RELIEF_REPLY':str(reply)})
   bench.save(out/'request.json',request)
   env=bench.env()
   for key in ['TOKIO_WORKER_THREADS','GOMAXPROCS','MallocStackLogging','DYLD_INSERT_LIBRARIES']:env.pop(key,None)
   if version in {'workers12','baseline2'}:env['TOKIO_WORKER_THREADS']='12' if version=='workers12' else '2'
   env['XRAY_BENCH_MEMORY_CHECKPOINTS']=str(markers)
   command=[str(harness),'protocol-run',str(out/'request.json')];rec.update(command=command,controlled_env={'TOKIO_WORKER_THREADS':env.get('TOKIO_WORKER_THREADS'),'MallocStackLogging':None});save()
   with (out/'driver.log').open('w') as log:
    child=subprocess.Popen(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
     stage=wait_stage('before',child);pid=stage['pid'];rec['pid']=pid
     fields=ps(pid).split(None,4);assert int(fields[1])==child.pid and fields[4].startswith(str(binary)+' run '),fields
     snapshot('before',pid);(markers/'before.continue').touch()
     time.sleep(.9);snapshot('active',pid,with_heap=False)
     wait_stage('after',child);snapshot('after',pid);(markers/'after.continue').touch()
     wait_stage('idle',child);snapshot('idle10',pid)
     trigger.touch();deadline=time.monotonic()+20
     while not reply.exists():
      if time.monotonic()>deadline:raise TimeoutError('relief helper did not answer')
      time.sleep(.025)
     rec['relief_reported_bytes']=int(reply.read_text());time.sleep(.25)
     snapshot('relieved',pid);(markers/'idle.continue').touch()
     rec['returncode']=child.wait(timeout=30);assert rec['returncode']==0
     result=json.loads((out/'run/result.json').read_text());assert result['status']=='pass' and result['diagnostic_memory_checkpoints']
     assert result['engine_sha256']==rec['engine_sha256']
     expected=count*8192*65536
     assert result['bytes_sent']==expected and result['bytes_received']==(expected if traffic=='full-duplex' else 0)
     rec['validated_payload_bytes']={'sent':result['bytes_sent'],'received':result['bytes_received']}
     assert str(binary)+' run -config '+str(out/'run/config.json') not in subprocess.check_output(['ps','-axo','pid=,command='],text=True)
    finally:
     if child.poll() is None:
      os.killpg(child.pid,signal.SIGTERM)
      try:child.wait(timeout=10)
      except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
     save()
  records.append(rec);bench.save(n/'memory-relief-profiles.json',records);print('END',case,version,flush=True)
print('MEMORY RELIEF PROFILES COMPLETE',flush=True)
