from pathlib import Path
import hashlib,json,os,subprocess
n=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args,env=None):return subprocess.check_output(['git','-C',str(n/'harness-source'),*args],text=True,env=env).strip()
guard=read(n/'main-guard.json');core=Path('/Users/antonmalygin/xray-rust')
assert subprocess.check_output(['git','-C',str(core),'rev-parse','HEAD'],text=True).strip()==guard['head']
for path,expected in guard['files'].items():assert sha(core/path)==expected,path
checked=set();timed=0
for group in (n/'evidence').iterdir():
 m=read(group/'manifest.json')
 for path,expected in m['file_hashes'].items():assert sha(Path(path))==expected,path;checked.add(path)
 for run in m['runs']:
  assert run['returncode']==0 and run['process_group_empty_after_run'] and not run['remaining_engine_processes']
  req=read(Path(run['command'][-1]));result=read(group/run['output_relative']/'result.json')
  assert result['iterations']==8192 and result['payload_size']==65536
  assert result['engine_sha256']==m['versions'][run['version']]['engine_sha256']
  assert result['bytes_sent']==(8 if 'upload-8' in run['case'] else 1)*512*1024*1024
  assert result['bytes_received']==(512*1024*1024 if 'full-duplex' in run['case'] else 0)
  assert result['client_env']==req.get('client_env',{})
  if group.name.endswith('allocator-control'):assert result['client_env']==run['controlled_environment']['client_env']
  timed+=1
assert timed==50
diagnostic=0
for family in ['profiles','relief-profiles']:
 for p in (n/family).iterdir():
  d=read(p/'diagnostic.json');r=read(p/'run/result.json')
  assert d['returncode']==0 and not d['usable_for_performance'] and r['diagnostic_memory_checkpoints']
  assert d['engine_sha256']==sha(Path(d['engine']))==r['engine_sha256']
  assert d['validated_payload_bytes']==dict(sent=r['bytes_sent'],received=r['bytes_received'])
  assert r['bytes_sent']==(8 if d['case']=='upload8' else 1)*512*1024*1024
  assert r['bytes_received']==(512*1024*1024 if d['case']=='duplex1' else 0)
  diagnostic+=1
assert diagnostic==12
b=read(n/'diagnostic-harness-build.json')
assert sha(Path(b['binary']))==b['binary_sha256'] and sha(n/'diagnostic-harness.patch')==b['patch_sha256']
index=n/'verify-harness.index';assert not index.exists()
env=dict(os.environ,GIT_INDEX_FILE=str(index))
try:
 git('read-tree',b['parent_runtime_commit'],env=env)
 git('apply','--cached','--check',str(n/'diagnostic-harness.patch'),env=env)
 git('apply','--cached',str(n/'diagnostic-harness.patch'),env=env)
 actual=git('write-tree',env=env);expected=git('rev-parse',b['source_commit']+'^{tree}')
 assert actual==expected
finally:index.unlink(missing_ok=True)
assert git('diff','--name-only',b['parent_runtime_commit'],b['source_commit'])=='crates/xray-bench/src/protocol_bench.rs'
relief=read(n/'allocator-relief-build.json')
assert sha(n/'allocator-relief.c')==relief['source_sha256'] and sha(n/'allocator-relief.dylib')==relief['dylib_sha256']
mobile=Path('/Users/antonmalygin/xray-rust-mobile')
assert not subprocess.check_output(['git','-C',str(mobile),'status','--porcelain'],text=True)
result=dict(timed_runs_verified=timed,diagnostic_runs_verified=diagnostic,external_manifest_files_verified=len(checked),guarded_core_files_verified=len(guard['files']),core_head_unchanged=guard['head'],mobile_clean=True,mobile_head=subprocess.check_output(['git','-C',str(mobile),'rev-parse','HEAD'],text=True).strip(),diagnostic_patch_reconstructed_tree=actual,diagnostic_patch_only_changes_harness=True)
(n/'input-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
