// Diagnostic-only helper for an owned benchmark client. It never changes OS policy.
#include <malloc/malloc.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
static void *relief_worker(void *unused) {
    (void)unused;
    const char *trigger = getenv("H2_MEMORY_RELIEF_TRIGGER");
    const char *reply = getenv("H2_MEMORY_RELIEF_REPLY");
    for (int i = 0; i < 15000; ++i) {
        if (access(trigger, F_OK) == 0) {
            size_t released = malloc_zone_pressure_relief(NULL, 0);
            int fd = open(reply, O_CREAT | O_EXCL | O_WRONLY, 0600);
            if (fd >= 0) { dprintf(fd, "%zu\n", released); close(fd); }
            return NULL;
        }
        usleep(20000);
    }
    return NULL;
}
__attribute__((constructor)) static void init_relief(void) {
    if (!getenv("H2_MEMORY_RELIEF_TRIGGER") || !getenv("H2_MEMORY_RELIEF_REPLY")) return;
    pthread_t thread;
    if (pthread_create(&thread, NULL, relief_worker, NULL) == 0) pthread_detach(thread);
}
