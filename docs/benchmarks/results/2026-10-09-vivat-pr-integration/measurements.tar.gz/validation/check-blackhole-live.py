import socket,subprocess,time,json,pathlib,struct
root=pathlib.Path('/private/tmp/xray-vivat-campaign/blackhole-live-correct-associate');root.mkdir(exist_ok=True)
engines={'rust':'/private/tmp/xray-vivat-final/bin/candidate/xray-rust','xray':'/private/tmp/xray-vivat-campaign/bin/xray-core'}
def readn(s,n):
 out=b''
 while len(out)<n:
  b=s.recv(n-len(out))
  if not b: raise RuntimeError('early EOF')
  out+=b
 return out
def connect(port,cmd):
 s=socket.create_connection(('127.0.0.1',port),2);s.settimeout(2);s.sendall(b'\x05\x01\x00');assert readn(s,2)==b'\x05\x00'
 s.sendall(b'\x05'+bytes([cmd])+b'\x00\x01\x7f\x00\x00\x01'+(9 if cmd==1 else 0).to_bytes(2,'big'))
 header=readn(s,4);assert header[:3]==b'\x05\x00\x00',header
 size={1:4,4:16}[header[3]];address=readn(s,size);p=int.from_bytes(readn(s,2),'big')
 return s,(socket.inet_ntop(socket.AF_INET if size==4 else socket.AF_INET6,address),p)
results=[]
for mode in ['none','http']:
 for engine,binary in engines.items():
  with socket.socket() as reservation:
   reservation.bind(('127.0.0.1',0));port=reservation.getsockname()[1]
  directory=root/f'{engine}-{mode}';directory.mkdir(exist_ok=True)
  cfg={'log':{'loglevel':'warning'},'inbounds':[{'protocol':'socks','listen':'127.0.0.1','port':port,'settings':{'auth':'noauth','udp':True,'ip':'127.0.0.1'}}],'outbounds':[{'protocol':'blackhole','tag':'block','settings':{'response':{'type':mode}}}]}
  path=directory/'config.json';path.write_text(json.dumps(cfg))
  args=[binary,'run','--config' if engine=='rust' else '-config',str(path)]
  with (directory/'server.log').open('w') as log:
   process=subprocess.Popen(args,stdout=log,stderr=log)
   try:
    for i in range(100):
     if process.poll() is not None:raise RuntimeError(f'{engine} exited; see {directory}')
     try:
      with socket.create_connection(('127.0.0.1',port),.05):pass
      break
     except OSError:time.sleep(.025)
    tcp,_=connect(port,1)
    with tcp:
     tcp_payload=b''
     while True:
      b=tcp.recv(4096)
      if not b:break
      tcp_payload+=b
    control,relay=connect(port,3)
    with control,socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as udp:
     udp.bind(('127.0.0.1',0));udp.settimeout(.4)
     packet=b'\x00\x00\x00\x01\x7f\x00\x00\x01\x00\x09body'
     responses=[]
     for _ in range(2):
      udp.sendto(packet,('127.0.0.1',relay[1]))
      try:responses.append(udp.recv(4096)[10:].hex())
      except TimeoutError:responses.append(None)
    results.append({'engine':engine,'mode':mode,'tcp':tcp_payload.hex(),'udp':responses})
   finally:
    process.terminate()
    try:process.wait(timeout=3)
    except subprocess.TimeoutExpired:process.kill();process.wait()
(root/'results.json').write_text(json.dumps(results,indent=2)+'\n')
for mode in ['none','http']:
 rows=[{k:v for k,v in r.items() if k!='engine'} for r in results if r['mode']==mode]
 assert rows[0]==rows[1],rows
print(json.dumps(results,indent=2))
