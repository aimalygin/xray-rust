import subprocess, json, pathlib, time
root=pathlib.Path('/private/tmp/xray-vivat-final')
collector=root/'candidate/scripts/run-v07-performance.py'
summarizer=root/'candidate/scripts/summarize-v07-performance.py'
results=[]
for protocol,suite in [('vless-tls','tun'),('reality-vision','reality')]:
 for connections in [1,8]:
  for traffic in ['upload','download','full-duplex']:
   case=f'{protocol}-tun-{traffic}-{connections}'
   directory=root/'performance'/case
   args=['python3',str(collector),'--root',str(root),'--harness',str(root/'bin/baseline/xray-bench'),'--suite',suite,'--case',case,'--iterations',str(16384//connections),'--output',str(directory)]
   print(case,flush=True)
   with (root/f'{case}.log').open('w') as output:
    result=subprocess.run(args,stdout=output,stderr=subprocess.STDOUT)
   summary=subprocess.run(['python3',str(summarizer),str(directory)],capture_output=True,text=True)
   results.append({'case':case,'collector':result.returncode,'summarizer':summary.returncode})
   (root/'matrix-status.json').write_text(json.dumps(results,indent=2)+'\n')
   if summary.returncode:
    print(summary.stderr,flush=True)
   else:
    row=json.loads((directory/'summary.json').read_text())['rows'][0]
    print(json.dumps({'case':case,'ratios':row.get('ratios'),'review':row['review'],'failed':result.returncode != 0}),flush=True)
   if result.returncode or summary.returncode:
    raise SystemExit('Stopped after a failed case; retain and investigate all outputs')
print('All 120 scheduled runs completed',flush=True)
