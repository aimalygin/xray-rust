from pathlib import Path
root=Path('/Users/antonmalygin/xray-rust');out=root/'target/v08-duplex-profile'
s=(out/'protocol-bench-original.rs').read_text()
s=s.replace('    let client_startup_seconds = client_started.elapsed().as_secs_f64();', '''    let profile_cycles: usize = std::env::var("XRAY_PROFILE_CYCLES")
        .unwrap_or_else(|_| "1".into()).parse().map_err(|_| invalid("bad profile cycles"))?;
    if !(1..=128).contains(&profile_cycles) || r.path != "socks" || matches!(r.traffic.as_str(), "udp" | "tcp-latency") {
        return Err(invalid("bounded SOCKS bulk diagnostic only"));
    }
    if let Ok(gate) = std::env::var("XRAY_PROFILE_GATE") {
        fs::write(&gate, child.child.id().to_string()).map_err(io_error)?;
        let started = Instant::now();
        while !PathBuf::from(format!("{gate}.go")).exists() {
            if started.elapsed() > Duration::from_secs(60) { return Err(invalid("profile gate timeout")); }
            sleep(Duration::from_millis(20)).await;
        }
    }
    let client_startup_seconds = client_started.elapsed().as_secs_f64();''',1)
s=s.replace('settle: Duration::from_millis(500),','settle: if profile_cycles > 1 { Duration::ZERO } else { Duration::from_millis(500) },',1)
s=s.replace('        let outcome = match (fd.as_ref(), r.traffic.as_str()) {','        let mut outcome = WorkloadOutcome::empty();\n        for _ in 0..profile_cycles {\n        let cycle = match (fd.as_ref(), r.traffic.as_str()) {',1)
s=s.replace('        let elapsed = started.elapsed();\n        phase.set(BenchmarkPhase::Settle);','        outcome.extend(cycle);\n        }\n        let elapsed = started.elapsed();\n        phase.set(BenchmarkPhase::Settle);',1)
s=s.replace('json!({"status":"pass", "path":r.path,"traffic":r.traffic,','json!({"diagnostic_only":true,"profile_cycles":profile_cycles,"status":"pass", "path":r.path,"traffic":r.traffic,',1)
(out/'protocol-bench-profile.rs').write_text(s)
print('Prepared diagnostic-only harness; production source not edited yet.')
