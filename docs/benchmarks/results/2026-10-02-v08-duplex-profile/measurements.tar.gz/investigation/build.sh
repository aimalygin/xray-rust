#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
export CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=target/v08-comparison-driver
cargo rustc --locked --offline --release -p xray-cli --bin xray-rust -- -C strip=none -C debuginfo=1 > target/v08-duplex-profile/symbol-build.log 2>&1
cp target/v08-comparison-driver/release/xray-rust target/v08-duplex-profile/symbols
cp target/v08-duplex-profile/protocol-bench-profile.rs crates/xray-bench/src/protocol_bench.rs
cargo build --locked --offline --release -p xray-bench --bin xray-bench > target/v08-duplex-profile/harness-build.log 2>&1
cp target/v08-comparison-driver/release/xray-bench target/v08-duplex-profile/profile-harness
git diff --binary -- crates/xray-bench/src/protocol_bench.rs > target/v08-duplex-profile/profile-harness.patch
cp target/v08-duplex-profile/protocol-bench-original.rs crates/xray-bench/src/protocol_bench.rs
cargo build --locked --offline --release -p xray-cli > target/v08-duplex-profile/restored-build.log 2>&1
cmp target/v08-comparison-driver/release/xray-rust target/v08-duplex-profile/normal
git diff --exit-code -- crates Cargo.toml Cargo.lock
shasum -a 256 target/v08-duplex-profile/normal target/v08-duplex-profile/symbols target/v08-duplex-profile/profile-harness
