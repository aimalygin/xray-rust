from pathlib import Path
import subprocess
root=Path('/Users/antonmalygin/xray-rust');base=root/'target/v08-duplex-profile'
for name in ['kernel','libc']:
 with (base/(name+'.log')).open('w') as log:
  print('start',name,flush=True)
  subprocess.run(['python3',str(base/'census.py'),'--campaign',name,'--repeats','4','--output',str(base/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  print('pass',name,flush=True)
