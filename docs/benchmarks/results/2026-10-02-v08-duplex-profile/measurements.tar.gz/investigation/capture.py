#!/usr/bin/env python3
"""Target-only CPU traces. Profiled timings are never performance evidence."""
import argparse,copy,ctypes,importlib.util,json,os,select,shutil,signal,subprocess,threading,time,uuid
from pathlib import Path
ROOT=Path('/Users/antonmalygin/xray-rust');BASE=ROOT/'target/v08-duplex-profile'
spec=importlib.util.spec_from_file_location('comparison',ROOT/'scripts/run-v08-protocol-comparison.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
notify=ctypes.CDLL('/usr/lib/system/libsystem_notify.dylib')
notify.notify_register_file_descriptor.argtypes=[ctypes.c_char_p,ctypes.POINTER(ctypes.c_int),ctypes.c_int,ctypes.POINTER(ctypes.c_int)]
notify.notify_cancel.argtypes=[ctypes.c_int]

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--version',choices=['candidate','xray'],required=True);p.add_argument('--traffic',choices=['upload','download','full-duplex'],default='full-duplex');p.add_argument('--output',type=Path,required=True);p.add_argument('--cycles',type=int,default=64);p.add_argument('--duration',type=int,default=10);a=p.parse_args()
 assert 1<=a.cycles<=128 and 2<=a.duration<=30
 for k in ['GOMAXPROCS','GOGC','GOMEMLIMIT','TOKIO_WORKER_THREADS','DYLD_INSERT_LIBRARIES']:os.environ.pop(k,None)
 os.umask(0o077);out=a.output.resolve();out.mkdir(exist_ok=False)
 paths={'candidate':BASE/'symbols','xray':ROOT/'target/v08-io-final/bin/xray','harness':BASE/'profile-harness'}
 assert not c.ambient()['compiler_load_detected'] and not c.followup.inventory(paths.values())
 c.device.verify_reference(paths['xray'])
 fd,token=ctypes.c_int(-1),ctypes.c_int(-1);key=('org.xray-rust.profile.'+str(uuid.uuid4())).encode()
 assert notify.notify_register_file_descriptor(key,ctypes.byref(fd),0,ctypes.byref(token))==0
 result={'diagnostic_only':True,'version':a.version,'traffic':a.traffic,'cycles':a.cycles,'duration_seconds':a.duration,'started_unix':time.time(),'file_hashes':{str(v):c.bench.sha(v) for v in [*paths.values(),Path(__file__).resolve()]}}
 stopped=threading.Event();ambient=[];observer_errors=[]
 def observe():
  try:
   while not stopped.is_set():
    ambient.append({'unix':time.time(),**c.ambient()});stopped.wait(1)
  except Exception as error:observer_errors.append(repr(error))
 observer=threading.Thread(target=observe);observer.start()
 driver=profiler=None
 try:
  with c.fixture(paths['xray'],out/'server','vmess-aes128') as (config,server_pid):
   binary=paths[a.version]
   if a.version=='xray':
    binary=out/'xray-client';shutil.copyfile(ROOT/'scripts/v08-reference-client.py',binary);binary.chmod(0o700)
    c.bench.save(Path(str(binary)+'.json'),{'mode':'xray','binaries':{'xray':str(paths['xray'])}})
   req={'binary':str(binary),'config':config,'path':'socks','traffic':a.traffic,'connections':1,'iterations':4096,'payload_size':65536,'output':str(out/'client'),'warmup':True,'client_preface':True,'prepare_client':a.version=='xray'}
   c.bench.save(out/'request.json',req)
   options={'Time Profiler':{'recordKernelStacks':True,'recordWaitingThreads':False,'contextSwitchSampling':False,'highFrequencySampling':False}}
   c.bench.save(out/'options.json',options)
   gate=out/'ready';env=dict(c.bench.env(),XRAY_PROFILE_CYCLES=str(a.cycles),XRAY_PROFILE_GATE=str(gate))
   with (out/'harness.log').open('w') as dl,(out/'xctrace.log').open('w') as pl:
    driver=subprocess.Popen([str(paths['harness']),'protocol-run',str(out/'request.json')],stdout=dl,stderr=dl,env=env,start_new_session=True)
    limit=time.monotonic()+30
    while not gate.exists():
     assert driver.poll() is None,'driver stopped before gate'
     assert time.monotonic()<limit,'driver startup timeout'
     time.sleep(.02)
    pid=int(gate.read_text());result['client_pid']=pid
    command=['xcrun','xctrace','record','--template','Time Profiler','--attach',str(pid),'--time-limit',str(a.duration)+'s','--output',str(out/'cpu.trace'),'--recording-options',str(out/'options.json'),'--notify-tracing-started',key.decode(),'--no-prompt']
    result['profiler_command']=command
    profiler=subprocess.Popen(command,stdout=pl,stderr=pl,start_new_session=True)
    limit=time.monotonic()+45
    while not select.select([fd.value],[],[],.1)[0]:
     assert profiler.poll() is None,'profiler stopped before recording'
     assert driver.poll() is None,'driver stopped while waiting for profiler'
     assert time.monotonic()<limit,'profiler start timeout'
    os.read(fd.value,4);result['tracing_started_unix']=time.time();Path(str(gate)+'.go').touch()
    result['profiler_returncode']=profiler.wait(a.duration+40)
    result['driver_returncode']=driver.wait(120)
    assert result['profiler_returncode']==result['driver_returncode']==0
    workload=json.loads((out/'client/result.json').read_text());assert workload['status']=='pass' and workload['diagnostic_only']
    size=4096*65536*a.cycles
    assert workload['bytes_sent']==(0 if a.traffic=='download' else size)
    assert workload['bytes_received']==(0 if a.traffic=='upload' else size)
    result['verified_bytes']={'sent':workload['bytes_sent'],'received':workload['bytes_received']}
   remaining=[s for s in c.followup.inventory(paths.values()) if int(s.split(None,1)[0])!=server_pid];assert not remaining
  assert not observer_errors and not any(s['compiler_load_detected'] for s in ambient)
  result['status']='pass'
 except BaseException as error:
  result['status']='fail';result['error']=repr(error);raise
 finally:
  for proc in [profiler,driver]:
   if proc and proc.poll() is None:
    os.killpg(proc.pid,signal.SIGTERM)
    try:proc.wait(5)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(5)
  notify.notify_cancel(token.value)
  stopped.set();observer.join();result['ambient']={'samples':ambient,'errors':observer_errors}
  result['finished_unix']=time.time();c.bench.save(out/'capture.json',result)
  print(result['status'],out,flush=True)
if __name__=='__main__':main()
