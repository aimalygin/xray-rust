from pathlib import Path
import subprocess
root=Path('/Users/antonmalygin/xray-rust');base=root/'target/v08-duplex-profile'
for version,index in [('candidate',2),('xray',2),('xray',3),('candidate',3),('candidate',4),('xray',4)]:
 name=('rust' if version=='candidate' else 'xray')+'-duplex-'+str(index);out=base/name
 print('capture',name,flush=True)
 subprocess.run(['python3',str(base/'capture.py'),'--version',version,'--cycles','96','--duration','10','--output',str(out)],cwd=root,check=True)
 subprocess.run(['xcrun','xctrace','export','--input',str(out/'cpu.trace'),'--xpath','/trace-toc/run[@number="1"]/data/table[@schema="time-profile"]','--output',str(out/'time-profile.xml')],cwd=root,check=True,stdout=subprocess.DEVNULL)
 with (out/'summary.log').open('w') as log:subprocess.run(['python3',str(base/'profile-summary.py'),str(out)],cwd=root,check=True,stdout=log)
 print('pass',name,flush=True)
