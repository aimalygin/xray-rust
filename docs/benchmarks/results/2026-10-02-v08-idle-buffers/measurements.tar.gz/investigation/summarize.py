import json, statistics, sys
from pathlib import Path
root=Path(__file__).resolve().parent
campaign=root/(sys.argv[1] if len(sys.argv)>1 else 'footprint')
runs=[json.loads(f.read_text()) for f in sorted(campaign.glob('*/result.json'))]
summary={}
for profile in sorted({r['profile'] for r in runs}):
 summary[profile]={}
 for version in sorted({r['version'] for r in runs}):
  rows=[r for r in runs if r['profile']==profile and r['version']==version]
  if not rows: continue
  fields={}
  for name in ['warm','idle-0','resumed-bulk-0','idle-1','resumed-bulk-1']:
   points=[next(p for p in r['phases'] if p['phase']==name) for r in rows]
   for key in ['rss_kib','footprint_kib','elapsed_seconds']:
    values=[p[key]/1024 if key.endswith('_kib') else p[key] for p in points if key in p]
    if values: fields[name+'_'+key.replace('_kib','_mib')]={'median':statistics.median(values),'samples':values}
  for cycle in range(2):
   latency=[sorted(next(p['latency_us'] for p in r['phases'] if p['phase']==f'first-request-{cycle}')) for r in rows]
   for quantile in [.5,.95,.99]:
    values=[v[min(int((len(v)-1)*quantile),len(v)-1)] for v in latency]
    fields[f'first-request-{cycle}_p{round(quantile*100)}_us']={'median':statistics.median(values),'samples':values}
   deltas=[]
   for r in rows:
    phases={p['phase']:p for p in r['phases']}
    before='warm' if cycle==0 else f'resumed-bulk-{cycle-1}'
    deltas.append(phases[f'idle-{cycle}']['cpu_ms']-phases[before]['cpu_ms'])
   fields[f'idle-{cycle}_cpu_ms']={'median':statistics.median(deltas),'samples':deltas}
  summary[profile][version]={'repeats':len(rows),'fields':fields}
(root/'footprint-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for p,versions in summary.items():
 print(p)
 for version,data in versions.items():
  print(version,'n=',data['repeats'],{k:round(v['median'],2) for k,v in data['fields'].items() if k.endswith('footprint_mib') or 'p95' in k or 'elapsed_seconds' in k or 'cpu_ms' in k})
