#!/usr/bin/env python3
"""RSS scaling for 0/32/128/512 held, payload-verified protocol connections.

Uses fresh full clients and the same pinned Xray fixture. No timed throughput
claims; each held connection first exchanges 8 KiB in both directions. Run only
when the other campaigns and compilers are stopped.
"""
import argparse
import asyncio
import copy
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import socket
import statistics
import subprocess
import time


async def client_run(c, binary, config, directory):
    directory.mkdir()
    port = c.bench.port()
    config = copy.deepcopy(config)
    config['inbounds'] = [{'protocol':'socks','listen':'127.0.0.1','port':port,'settings':{'auth':'noauth','udp':False}}]
    c.bench.save(directory/'config.json', config)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
        probe.connect(('8.8.8.8',80))  # route lookup only; sends no packets
        ip = probe.getsockname()[0]
    accepted, clients, tasks = set(), [], set()
    errors, points = [], []
    async def echo(reader, writer):
        accepted.add(writer)
        task = asyncio.current_task(); tasks.add(task)
        try:
            while data := await reader.read(65536):
                writer.write(data); await writer.drain()
        except (ConnectionError, asyncio.CancelledError):
            pass
        finally:
            writer.close(); accepted.discard(writer); tasks.discard(task)
    server = await asyncio.start_server(echo, ip, 0)
    target_port = server.sockets[0].getsockname()[1]
    payload = bytes(range(256))*32
    async def connect():
        reader, writer = await asyncio.open_connection('127.0.0.1',port)
        clients.append(writer)
        writer.write(b'\x05\x01\x00'); await writer.drain()
        assert await reader.readexactly(2) == b'\x05\x00'
        writer.write(b'\x05\x01\x00\x01'+socket.inet_aton(ip)+target_port.to_bytes(2,'big')); await writer.drain()
        response = await reader.readexactly(4)
        assert response[:3] == b'\x05\x00\x00'
        address_size = {1:4,4:16}.get(response[3])
        if response[3] == 3: address_size = (await reader.readexactly(1))[0]
        assert address_size is not None
        await reader.readexactly(address_size+2)
        writer.write(payload); await writer.drain()
        assert await reader.readexactly(len(payload)) == payload
    child = None
    try:
        with (directory/'stdout.log').open('w') as stdout, (directory/'stderr.log').open('w') as stderr:
            child = subprocess.Popen([str(binary),'run','-config',str(directory/'config.json')],stdout=stdout,stderr=stderr,env=c.bench.env(),start_new_session=True)
            for _ in range(100):
                assert child.poll() is None
                try:
                    r,w=await asyncio.open_connection('127.0.0.1',port)
                    w.close(); await w.wait_closed(); break
                except ConnectionError: await asyncio.sleep(.05)
            else: raise RuntimeError('client did not start')
            for count in [0,32,128,512]:
                while len(clients) < count:
                    await asyncio.wait_for(asyncio.gather(*(connect() for _ in range(min(16,count-len(clients))))),30)
                await asyncio.sleep(1)
                samples=[]
                for _ in range(5):
                    load=c.ambient()
                    if load['compiler_load_detected']:raise RuntimeError('compiler interference: '+str(load))
                    assert child.poll() is None
                    rss=int(subprocess.check_output(['ps','-o','rss=','-p',str(child.pid)],text=True))
                    samples.append({'unix':time.time(),'rss_kib':rss})
                    await asyncio.sleep(.25)
                if count: assert len(accepted)==count
                points.append({'connections':count,'rss_kib_median':statistics.median(s['rss_kib'] for s in samples),'samples':samples})
                print(directory.name,count,points[-1]['rss_kib_median'],flush=True)
    finally:
        for writer in clients:writer.close()
        if child is not None:
            if child.poll() is None: os.killpg(child.pid,signal.SIGTERM)
            try: child.wait(5)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(5)
        server.close();await server.wait_closed()
        for writer in list(accepted):writer.close()
        for task in list(tasks):task.cancel()
        await asyncio.gather(*list(tasks),return_exceptions=True)
    return {'status':'pass','binary':str(binary),'engine_sha256':c.bench.sha(binary),'points':points,'warmup_bytes_per_connection':len(payload),'checked_bytes_each_direction':len(payload)*len(clients),'client_returncode_after_stop':child.returncode}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();root=a.repo.resolve();out=a.output.resolve()
    spec=importlib.util.spec_from_file_location('comparison',root/'scripts/run-v08-protocol-comparison.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
    for var in ('GOMAXPROCS','TOKIO_WORKER_THREADS','GOMEMLIMIT','GOGC'):os.environ.pop(var,None)
    os.umask(0o077)
    soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE)
    resource.setrlimit(resource.RLIMIT_NOFILE,(4096 if hard == resource.RLIM_INFINITY else min(4096,hard),hard))
    paths={k:getattr(a,k).resolve(strict=True) for k in ('baseline','candidate','reference')}
    c.device.verify_reference(paths['reference'])
    assert not c.ambient()['compiler_load_detected'] and not c.followup.inventory(paths.values())
    out.mkdir(parents=True,exist_ok=False)
    hashes={str(p):c.bench.sha(p) for p in [*paths.values(),Path(__file__).resolve(),Path(c.__file__)]}
    manifest={'started_unix':time.time(),'file_hashes':hashes,'scope':'held connections after 8 KiB verified echo; RSS only; stock workers','runs':[],'repeats':3}
    try:
        for index,profile in enumerate(['ss2022-aes128','ss2022-chacha20','vmess-aes128','vmess-chacha20']):
            for repeat in range(1,4):
                with c.fixture(paths['reference'],out/f'{profile}-server-{repeat}',profile) as (config,pid):
                    order=['baseline','candidate'] if (index+repeat)%2 else ['candidate','baseline']
                    for version in order:
                        name=f'{profile}-{version}-{repeat}'
                        result=asyncio.run(asyncio.wait_for(client_run(c,paths[version],config,out/name),120))
                        remaining=[s for s in c.followup.inventory(paths.values()) if int(s.split(None,1)[0])!=pid]
                        assert not remaining
                        result.update(profile=profile,version=version,repeat=repeat,remaining_engine_processes=remaining,client_order=order)
                        c.bench.save(out/name/'result.json',result);manifest['runs'].append({'output_relative':name,'version':version,'repeat':repeat,'profile':profile})
                        c.bench.save(out/'manifest.json',manifest)
                assert not c.followup.inventory(paths.values())
        assert all(c.bench.sha(Path(path))==sha for path,sha in hashes.items())
        manifest['status']='pass'
    except BaseException:
        manifest['status']='fail';raise
    finally:
        manifest['finished_unix']=time.time();c.bench.save(out/'manifest.json',manifest)


if __name__=='__main__':main()
