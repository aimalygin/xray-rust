import argparse,copy,hashlib,importlib.util,json,os,pathlib,shutil,subprocess,time
ROOT=pathlib.Path('/Users/antonmalygin/xray-rust')
spec=importlib.util.spec_from_file_location('comparison',ROOT/'scripts/run-v08-protocol-comparison.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
p=argparse.ArgumentParser();p.add_argument('--binary',action='append',required=True);p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--profile',action='append');p.add_argument('--traffic',action='append');p.add_argument('--flows',type=int,action='append');p.add_argument('--repeats',type=int,default=3);p.add_argument('--idle',type=int,default=0);a=p.parse_args()
for v in ('GOMAXPROCS','TOKIO_WORKER_THREADS','GOMEMLIMIT','GOGC'):os.environ.pop(v,None)
os.umask(0o077)
binaries={name:pathlib.Path(path).resolve(strict=True) for name,path in (b.split('=',1) for b in a.binary)}
reference=ROOT/'target/v08-comparison-v3/bin/xray';harness=ROOT/'target/v08-comparison-v3/bin/harness'
paths=list(binaries.values())+[reference,harness]
assert not c.ambient()['compiler_load_detected'];assert not c.followup.inventory(paths)
out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
hashes={str(p):c.bench.sha(p) for p in paths}
cases=[case for case in c.cases(a.profile or ['ss2022-aes128','ss2022-chacha20','vmess-aes128','vmess-chacha20']) if case['connections'] in (a.flows or [1,8]) and case['traffic'] in (a.traffic or ['upload','download','full-duplex'])]
manifest={'started_unix':time.time(),'repeats':a.repeats,'cases':cases,'file_hashes':hashes,'runs':[],'source_commit':c.bench.command(['git','rev-parse','HEAD'],ROOT),'idle_connections':a.idle,'purpose':'causal controls; same harness, reference fixture and payload; rotating order'}
(out/'source.patch').write_text(c.bench.command(['git','diff','--binary','HEAD'],ROOT))
for f in ['crates/xray-proxy/src/aead.rs','crates/xray-proxy/benches/aead_backends.rs']:
 source=ROOT/f
 if source.exists():shutil.copyfile(source,out/source.name)
for index,case in enumerate(cases):
 for repeat in range(1,a.repeats+1):
  order=list(binaries);offset=(index+repeat-1)%len(order);order=order[offset:]+order[:offset]
  if repeat%2==0:order.reverse()
  assert not c.ambient()['compiler_load_detected']
  server_dir=out/f"{case['id']}-server-{repeat}"
  with c.fixture(reference,server_dir,case['profile']) as (config,pid):
   for name in order:
    run_name=f"{case['id']}-{name}-{repeat}"
    request={k:case[k] for k in ('path','traffic','connections','iterations','payload_size')}
    request.update(binary=str(binaries[name]),config=copy.deepcopy(config),output=str(out/run_name),warmup=True,client_preface=case['traffic'] not in ('tcp-latency','udp'),idle_connections=a.idle)
    req=out/(run_name+'.json');c.bench.save(req,request)
    result=c.measured_execute([str(harness),'protocol-run',str(req)],out/(run_name+'.log'))
    remaining=[s for s in c.followup.inventory(paths) if int(s.split(None,1)[0])!=pid]
    result.update(case=case['id'],version=name,repeat=repeat,output_relative=run_name,remaining_engine_processes=remaining,client_order=order)
    manifest['runs'].append(result);c.bench.save(out/'manifest.json',manifest)
    print(run_name,result['returncode'],round(result['seconds'],2),flush=True)
    assert result['returncode']==0 and not remaining and not result['surviving_process_group']
assert all(c.bench.sha(pathlib.Path(path))==sha for path,sha in hashes.items())
manifest.update(status='pass',finished_unix=time.time());c.bench.save(out/'manifest.json',manifest)
