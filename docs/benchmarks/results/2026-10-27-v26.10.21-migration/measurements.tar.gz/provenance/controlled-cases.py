import importlib.util,json,pathlib,subprocess,time,sys
root=pathlib.Path('/Users/antonmalygin/.codex/worktrees/xray-core-26-10-21/xray-rust');campaign=pathlib.Path('/Users/antonmalygin/xray-rust/target/benchmarks/2026-10-27-migration');control=campaign/'control';control.mkdir(exist_ok=True)
for name in ('error.txt','done.txt','paused.json','resume.txt'):(control/name).unlink(missing_ok=True)
spec=importlib.util.spec_from_file_location('m',root/'scripts/run-migration-benchmarks.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
accepted=json.loads((campaign/'accepted-blocks.json').read_text());finished={c['id'] for block in accepted for c in json.loads((campaign/block/'manifest.json').read_text())['cases']}
for case in m.cases():
 if case['id'] in finished:continue
 for attempt in range(1,6):
  name='case-'+case['id']+'-'+str(attempt)
  print('START',name,time.strftime('%Y-%m-%d %H:%M:%S'),flush=True)
  with (campaign/(name+'.log')).open('w') as log:
   r=subprocess.run([sys.executable,str(root/'scripts/run-migration-benchmarks.py'),'--inputs',str(campaign/'inputs.json'),'--output',str(campaign/name),'--case-id',case['id'],'--control-dir',str(control)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
  if not r.returncode:
   accepted.append(name);(campaign/'accepted-blocks.json').write_text(json.dumps(accepted,indent=2)+'\n');print('PASS',name,flush=True);break
  manifest=json.loads((campaign/name/'manifest.json').read_text());runs=manifest['runs']
  noise=bool(runs) and all(x['returncode']==0 and not x['remaining_engine_processes'] and not x['surviving_process_group'] and x['process_group_empty_after_run'] and not x['ambient_cpu']['observer_errors'] for x in runs) and any(x['ambient_cpu']['heavy_external_load'] or x['ambient_cpu']['compiler_load_detected'] for x in runs)
  if noise and attempt<5:
   print('REJECTED ENVIRONMENT',name,flush=True);(control/'last-rejected.txt').write_text(name);time.sleep(5);continue
  (control/'error.txt').write_text(name);print('FAILED',name,flush=True);sys.exit(r.returncode)
(control/'done.txt').write_text('complete');print('ALL FULL BLOCKS COMPLETE',flush=True)
