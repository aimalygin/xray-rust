import subprocess,sys,time
time.sleep(8)
started=time.monotonic()
while True:
 result=subprocess.check_output([sys.executable,'/private/tmp/xray-migration-bench-20261027/step.py'],text=True)
 if 'PAUSED' not in result or time.monotonic()-started>=20:break
print(result.strip(),flush=True)
