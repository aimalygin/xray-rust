import subprocess,sys,time
time.sleep(20)
while True:
 result=subprocess.check_output([sys.executable,'/private/tmp/xray-migration-bench-20261027/step.py'],text=True)
 if ' 0/10 ' not in result:break
print(result.strip(),flush=True)
