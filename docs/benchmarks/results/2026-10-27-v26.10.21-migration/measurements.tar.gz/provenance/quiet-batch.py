import subprocess,sys,time,json,pathlib
p=pathlib.Path('/Users/antonmalygin/xray-rust/target/benchmarks/2026-10-27-migration/control/paused.json')
block=json.loads(p.read_text())['block']
time.sleep(20)
for _ in range(2):
 result=subprocess.check_output([sys.executable,'/private/tmp/xray-migration-bench-20261027/step.py'],text=True)
 if 'PAUSED' not in result or json.loads(p.read_text())['block']!=block:break
print(result.strip(),flush=True)
