import json,pathlib,time,sys
campaign=pathlib.Path('/Users/antonmalygin/xray-rust/target/benchmarks/2026-10-27-migration');control=campaign/'control';old=None
if '--wait-only' not in sys.argv:
 state=json.loads((control/'paused.json').read_text());old=state['token'];(control/'resume.txt').write_text(old)
while True:
 if (control/'error.txt').exists(): print('FAILED '+(control/'error.txt').read_text(),flush=True);break
 if (control/'done.txt').exists():print('COMPLETE 2000/2000',flush=True);break
 try:
  state=json.loads((control/'paused.json').read_text())
  if state['token']!=old:
   accepted=json.loads((campaign/'accepted-blocks.json').read_text());total=sum(len(json.loads((campaign/block/'manifest.json').read_text())['runs']) for block in accepted)
   manifest=json.loads((campaign/state['block']/'manifest.json').read_text())
   print(state['block'],str(state['completed'])+'/'+str(len(manifest['cases'])*10),'| completed progress',total+state['completed'],'/ 2000 | PAUSED',flush=True);break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(.2)
