import subprocess,sys,time
started=time.monotonic()
while True:
 result=subprocess.check_output([sys.executable,'/private/tmp/xray-migration-bench-20261027/step.py'],text=True)
 if not 'PAUSED' in result or time.monotonic()-started>=30:break
print(result.strip(),flush=True)
