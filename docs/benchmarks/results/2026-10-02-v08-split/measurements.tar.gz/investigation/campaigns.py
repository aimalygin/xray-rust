from pathlib import Path
import subprocess
root=Path('/Users/antonmalygin/xray-rust');b=root/'target/v08-split-investigation'
base=['--binary','baseline='+str(b/'baseline'),'--binary','candidate='+str(b/'candidate'),'--reference',str(root/'target/v08-io-final/bin/xray'),'--profile','vmess-aes128','--profile','vmess-chacha20']
commands=[('broad-controls',['python3',str(b/'controls.py'),*base,'--harness',str(root/'target/v08-io-final/bin/harness'),'--traffic','upload','--traffic','download','--traffic','full-duplex','--traffic','tcp-latency','--flows','1','--flows','8','--repeats','4'])]
for label,size in [('held-large',1048576),('held-small',8192)]:
 commands.append((label,['python3',str(root/'scripts/run-v08-idle-buffer-controls.py'),*base,'--connections','512','--warmup-bytes',str(size),'--idle-seconds','11','--repeats','2']))
for name,command in commands:
 print('start',name,flush=True)
 with (b/(name+'.log')).open('w') as log:subprocess.run([*command,'--output',str(b/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('pass',name,flush=True)
