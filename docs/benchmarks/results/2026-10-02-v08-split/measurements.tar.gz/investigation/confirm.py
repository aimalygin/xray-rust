from pathlib import Path
import subprocess
root=Path('/Users/antonmalygin/xray-rust');b=root/'target/v08-split-investigation'
command=['python3',str(b/'controls.py'),'--binary','baseline='+str(b/'baseline'),'--binary','candidate='+str(b/'shared-codec'),'--reference',str(root/'target/v08-io-final/bin/xray'),'--harness',str(root/'target/v08-io-final/bin/harness'),'--profile','vmess-aes128','--profile','vmess-chacha20','--traffic','full-duplex','--flows','1','--flows','8','--repeats','6','--output',str(b/'shared-confirmation')]
with (b/'shared-confirmation.log').open('w') as log: subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('pass shared-confirmation')
