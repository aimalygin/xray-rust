set -eu
cd /Users/antonmalygin/xray-rust
cargo fmt --all
CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=target/v08-comparison-driver cargo test --locked --offline -p xray-proxy --lib vmess > target/v08-split-investigation/proxy-final-test.log 2>&1
CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=target/v08-comparison-driver cargo test --locked --offline -p xray-core-rs --lib policy:: > target/v08-split-investigation/core-final-test.log 2>&1
CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=target/v08-comparison-driver cargo build --locked --offline --release -p xray-cli > target/v08-split-investigation/final-build.log 2>&1
cp target/v08-comparison-driver/release/xray-rust target/v08-split-investigation/candidate
python3 - <<'PY'
import json,subprocess,hashlib
from pathlib import Path
root=Path('/Users/antonmalygin/xray-rust');b=root/'target/v08-split-investigation'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
patch=subprocess.check_output(['git','diff','--binary'],cwd=root)
r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null','crates/xray-proxy/src/vmess/split.rs'],cwd=root,capture_output=True);assert r.returncode==1;patch+=r.stdout
(b/'candidate.patch').write_bytes(patch)
i=json.loads((b/'identity.json').read_text());i.update(candidate_sha256=sha(b/'candidate'),patch_sha256=sha(b/'candidate.patch'),scope='SOCKS direct raw-TCP VMess only; native TCP halves, separate codec state, two relay tasks, immediate nonblocking drain for small writes; no increased buffer cap');(b/'identity.json').write_text(json.dumps(i,indent=2)+'\n')
print('frozen',i['candidate_sha256'])
PY
