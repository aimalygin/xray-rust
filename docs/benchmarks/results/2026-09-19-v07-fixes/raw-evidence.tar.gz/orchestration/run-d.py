from pathlib import Path
import subprocess, json, hashlib, shutil
r=Path('/private/tmp/xray-v07-opt-20260919')
old=Path('/private/tmp/xray-v07-bench-20260919')
source=r/'source'
binary=r/'bin/d/xray-rust'
binary.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(old/'build/release/xray-rust',binary)
patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=source)
(binary.parent/'source.patch').write_bytes(patch)
(binary.parent/'build.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest()},indent=2))
common=['python3',str(source/'scripts/run-v07-performance-followup.py'),'--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--repeats','3']
plan=[('d-h1','tun',['baseline='+str(old/'bin/baseline/xray-rust'),'candidate='+str(binary)],['xhttp-h1-tun-full-duplex-1'],512),
      ('d-wireguard','new',['fixed='+str(binary)],['wireguard-'+p+'-'+d+'-8' for p in ['socks','tun'] for d in ['upload','full-duplex']],None),
      ('d-hysteria-long','new',['baseline='+str(old/'bin/candidate/xray-rust'),'candidate='+str(binary)],['hysteria2-tun-'+d+'-8' for d in ['upload','full-duplex']],512)]
for name,suite,engines,cases,iterations in plan:
    args=common+['--suite',suite,'--output',str(r/'evidence'/name)]
    for e in engines:args+=['--engine',e]
    for c in cases:args+=['--case',c]
    if iterations:args+=['--iterations',str(iterations)]
    with (r/(name+'.log')).open('w') as log:
        code=subprocess.call(args,stdout=log,stderr=subprocess.STDOUT,cwd=source)
    print(name,code,flush=True)
    if code:break
    subprocess.run(['python3',str(source/'scripts/summarize-v07-performance.py'),str(r/'evidence'/name)],check=True)

bench=old/'bin/candidate/xray-bench'
with (r/'d-tun-echo.log').open('w') as log:
    subprocess.run([str(bench),'run','--engine','xray-rust','--xray-rust-bin',str(binary),'--no-auto-build','--runs','5','--workload','tun-tcp-freedom','--connections','16','--iterations','100','--payload-size','1024','--out-dir',str(r/'evidence/d-tun-echo')],stdout=log,stderr=subprocess.STDOUT,check=True)
