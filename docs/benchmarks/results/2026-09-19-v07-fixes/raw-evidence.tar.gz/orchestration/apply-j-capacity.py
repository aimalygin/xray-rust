from pathlib import Path
import shutil
r=Path('/private/tmp/xray-v07-opt-20260919');p=r/'source/crates/xray-core-rs/src/tun.rs'
backup=r/'i-source/tun.rs';backup.parent.mkdir(exist_ok=True);shutil.copy2(p,backup)
s=p.read_text().replace('AtomicBool, AtomicU64','AtomicU8, AtomicU64').replace('capacity_waiting: AtomicBool','capacity_wake: AtomicU8')
marker='''#[derive(Debug, Default)]
struct TcpUploadBufferState'''
assert marker in s
s=s.replace(marker,'''const UPLOAD_CAPACITY_IDLE: u8 = 0;
const UPLOAD_CAPACITY_WAITING: u8 = 1;
const UPLOAD_CAPACITY_READY: u8 = 2;

#[derive(Debug, Default)]
struct TcpUploadBufferState''')
old='''        if self.capacity_waiting.swap(false, Ordering::SeqCst) {
            self.capacity_available.notify_one();
        }'''
new='''        if self
            .capacity_wake
            .compare_exchange(
                UPLOAD_CAPACITY_WAITING,
                UPLOAD_CAPACITY_READY,
                Ordering::SeqCst,
                Ordering::SeqCst,
            )
            .is_ok()
        {
            self.capacity_available.notify_one();
        }'''
assert old in s;s=s.replace(old,new)
old='''            () = upload_capacity.capacity_available.notified() => {
                tcp_stack_dirty = true;
            }'''
new='''            // Leave READY armed until the next socket scan. A release can
            // race with this guard; clearing WAITING in the writer would hide
            // its pending notification and strand the buffered TCP data.
            () = upload_capacity.capacity_available.notified(),
                if upload_capacity.capacity_wake.load(Ordering::SeqCst) != UPLOAD_CAPACITY_IDLE => {
                tcp_stack_dirty = true;
            }'''
assert old in s;s=s.replace(old,new)
s=s.replace('.capacity_waiting','.capacity_wake').replace('.store(false, Ordering::SeqCst);','.store(UPLOAD_CAPACITY_IDLE, Ordering::SeqCst);').replace('.store(true, Ordering::SeqCst);','.store(UPLOAD_CAPACITY_WAITING, Ordering::SeqCst);')
p.write_text(s)
