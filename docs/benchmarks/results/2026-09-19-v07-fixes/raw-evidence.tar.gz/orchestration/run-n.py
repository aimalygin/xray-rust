from pathlib import Path
import subprocess,json,hashlib,shutil
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919');s=r/'source'
binary=r/'bin/n/xray-rust';binary.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(old/'build/release/xray-rust',binary)
patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=s)
(binary.parent/'source.patch').write_bytes(patch)
(binary.parent/'build.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest()},indent=2)+'\n')
common=['python3','scripts/run-v07-performance-followup.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','fixed='+str(binary),'--suite','new','--repeats','20']
for name,baseline in [('n-wireguard-delay',r/'bin/m/xray-rust'),('n-wireguard-go-delay',old/'bin/xray-core')]:
 args=['python3','scripts/run-v07-delayed-protocol.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(baseline),'--engine','candidate='+str(binary),'--protocol','wireguard','--path','socks','--iterations','32','--repeats','3','--output',str(r/'evidence'/name)]
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,stdout=log,stderr=subprocess.STDOUT)
 print(name,code,flush=True)
 subprocess.run(['python3','scripts/summarize-v07-performance.py',str(r/'evidence'/name)],cwd=s,check=True)
 if code:raise SystemExit(code)

for name,baseline in [('n-wireguard-long-delay',r/'bin/m/xray-rust'),('n-wireguard-go-long-delay',old/'bin/xray-core')]:
 args=['python3','scripts/run-v07-delayed-protocol.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(baseline),'--engine','candidate='+str(binary),'--protocol','wireguard','--path','socks','--connections','1','--iterations','256','--repeats','3','--output',str(r/'evidence'/name)]
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,stdout=log,stderr=subprocess.STDOUT)
 print(name,code,flush=True)
 subprocess.run(['python3','scripts/summarize-v07-performance.py',str(r/'evidence'/name)],cwd=s,check=True)
 if code:raise SystemExit(code)
for n in [8,16]:
 name=f'n-wireguard-duplex-{n}'
 args=common+['--connections',str(n),'--case',f'wireguard-socks-full-duplex-{n}','--output',str(r/'evidence'/name)]
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,stdout=log,stderr=subprocess.STDOUT)
 print(name,code,flush=True)
 subprocess.run(['python3','scripts/summarize-v07-performance.py',str(r/'evidence'/name)],cwd=s,check=True)
 if code:raise SystemExit(code)
