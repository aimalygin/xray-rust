from pathlib import Path
import subprocess,os,json,time
r=Path('/private/tmp/xray-v07-opt-20260919');s=r/'source';old=Path('/private/tmp/xray-v07-bench-20260919');rows=[]
env=os.environ|{'CARGO_TARGET_DIR':str(old/'build'),'CARGO_BUILD_JOBS':'4'}
for name,variable,binary in [('native','NATIVE_HYSTERIA_BINARY',r/'bin/hysteria-native'),('xray','XRAY_HYSTERIA_BINARY',old/'bin/xray-core')]:
 args=['cargo','test','--offline','--release','-p','xray-core-rs','--test','hysteria_runtime_tests','--test','runtime_data_path_tests','hysteria_runtime_','--','--ignored','--nocapture'];start=time.time()
 with (r/('selected-test-hysteria-'+name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,env=env|{variable:str(binary)},stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=args,environment={variable:str(binary)},returncode=code,seconds=time.time()-start));(r/'selected-hysteria-tests.json').write_text(json.dumps(rows,indent=2)+'\n')
 if code:raise SystemExit(code)
