from pathlib import Path
import shutil
r=Path('/private/tmp/xray-v07-opt-20260919');base=r/'source'
for name in ['client.rs','stack.rs','io.rs']:
 p=base/'crates/xray-wireguard/src'/name;q=r/'f-source'/name;q.parent.mkdir(exist_ok=True);shutil.copy2(p,q)
p=base/'crates/xray-wireguard/src/client.rs';s=p.read_text();old='''            let mut stack_task = Box::pin(stack.run(task_stop.clone()));
            loop {''';new='''            let mut stack_task = Box::pin(stack.run(task_stop.clone()));
            let diagnose = std::env::var_os("XRAYDIAG_WG_STATS").is_some();
            let mut tick = tokio::time::interval(Duration::from_millis(500));
            loop {''';assert old in s;s=s.replace(old,new)
s=s.replace('''                    _ = device.wait() => break,''','''                    _ = device.wait() => break,
                    _ = tick.tick(), if diagnose => { eprintln!("WG memory={:?}",device.memory_snapshot().await); },''');p.write_text(s)
p=base/'crates/xray-wireguard/src/stack.rs';s=p.read_text().replace('''    pub(crate) async fn run(mut self, stop: Stop) {
        loop {''','''    pub(crate) async fn run(mut self, stop: Stop) {
        let diagnose = std::env::var_os("XRAYDIAG_WG_STATS").is_some();
        let mut reported = Clock::now();
        loop {''');marker='''            let wake = self.wake.clone();''';assert marker in s
s=s.replace(marker,'''            if diagnose && reported.elapsed() >= Duration::from_millis(500) {
                eprintln!("WG stack delay={delay:?} tx_free={} rx={} incoming={}",self.device.tx.capacity(),self.device.rx.is_some(),self.incoming.len());
                for entry in self.flows.values() { if let Entry::Tcp(flow) = entry {
                    let socket=self.sockets.get::<tcp::Socket>(flow.handle);
                    eprintln!("WG flow={} state={:?} tx={} rx={}",flow.flow.id,socket.state(),socket.send_queue(),socket.recv_queue());
                }}
                reported=Clock::now();
            }
'''+marker);p.write_text(s)
p=base/'crates/xray-wireguard/src/io.rs';s=p.read_text();marker='''            socket.bind(&bind.into())?;''';assert marker in s;s=s.replace(marker,'''            if let Some(kib) = std::env::var("XRAYDIAG_UDP_RCV_KIB").ok().and_then(|s|s.parse::<usize>().ok()) {
                socket.set_recv_buffer_size(kib*1024)?;
            }
            if std::env::var_os("XRAYDIAG_WG_STATS").is_some() {
                eprintln!("WG carrier recv={} send={}",socket.recv_buffer_size()?,socket.send_buffer_size()?);
            }
'''+marker);p.write_text(s)
