from pathlib import Path
import subprocess,os,json,time,shutil,hashlib
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919');source=r/'source'
env=os.environ|{'CARGO_TARGET_DIR':str(old/'build'),'CARGO_BUILD_JOBS':'4','GOTOOLCHAIN':'go1.26.5','GOENV':'off','GOWORK':'off'}
results=[]
def run(name,args):
 started=time.time();print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=args,returncode=code,seconds=time.time()-started))
 (r/'final2-campaign.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,code,flush=True)
 return code
# The clean temporary snapshot and final validated binaries must exist first.
if subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip():raise SystemExit('Source must be clean')
run('final2-v05',['bash','scripts/run-v05-pre-device-benchmarks.sh',str(r/'evidence/final2-v05')])
run('final2-v06',['python3','scripts/run-v06-feature-benchmarks.py',str(r/'evidence/final2-v06')])
# Both historical scripts build before measuring. Freeze their exact final engines.
final=r/'bin/final2';final.mkdir(exist_ok=True,parents=True)
for name in ['xray-rust','xray-bench']:shutil.copy2(old/'build/release'/name,final/name)
(final/'build.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip(),'sha256':{name:hashlib.sha256((final/name).read_bytes()).hexdigest() for name in ['xray-rust','xray-bench']}},indent=2)+'\n')
for suite in ['new','tun','reality','legacy']:
 args=['python3','scripts/run-v07-performance-followup.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--suite',suite,'--repeats','5','--output',str(r/'evidence'/('final2-'+suite))]
 engines={'candidate':final/'xray-rust'} if suite=='new' else {'baseline':old/'bin/baseline/xray-rust','candidate':final/'xray-rust'}
 for label,binary in engines.items():args+=['--engine',label+'='+str(binary)]
 run('final2-'+suite,args)
 run('summary-final2-'+suite,['python3','scripts/summarize-v07-performance.py',str(r/'evidence'/('final2-'+suite))])
# Longer H1 transfer checks the one-second upload-capacity stall directly.
run('final2-h1-long',['python3','scripts/run-v07-performance-followup.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(old/'bin/baseline/xray-rust'),'--engine','candidate='+str(final/'xray-rust'),'--suite','tun','--case','xhttp-h1-tun-full-duplex-1','--iterations','512','--repeats','3','--output',str(r/'evidence/final2-h1-long')])
run('summary-final2-h1-long',['python3','scripts/summarize-v07-performance.py',str(r/'evidence/final2-h1-long')])
# Repeat the noisy delayed-download CPU comparison against the original 0.7.
run('final2-hysteria-delay-download',['python3','scripts/run-v07-delayed-protocol.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(old/'bin/candidate/xray-rust'),'--engine','candidate='+str(final/'xray-rust'),'--protocol','hysteria2','--path','tun','--traffic','download','--iterations','64','--repeats','5','--output',str(r/'evidence/final2-hysteria-delay-download')])
run('summary-final2-hysteria-delay-download',['python3','scripts/summarize-v07-performance.py',str(r/'evidence/final2-hysteria-delay-download')])

run('final2-hysteria-long',['python3','scripts/run-v07-performance-followup.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(old/'bin/candidate/xray-rust'),'--engine','candidate='+str(final/'xray-rust'),'--suite','new','--case','hysteria2-tun-upload-8','--case','hysteria2-tun-full-duplex-8','--iterations','512','--repeats','3','--output',str(r/'evidence/final2-hysteria-long')])
run('summary-final2-hysteria-long',['python3','scripts/summarize-v07-performance.py',str(r/'evidence/final2-hysteria-long')])

run('final2-wireguard-original-delay',['python3','scripts/run-v07-delayed-protocol.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(old/'bin/candidate/xray-rust'),'--engine','candidate='+str(final/'xray-rust'),'--protocol','wireguard','--path','socks','--iterations','32','--repeats','3','--output',str(r/'evidence/final2-wireguard-original-delay')])
run('summary-final2-wireguard-original-delay',['python3','scripts/summarize-v07-performance.py',str(r/'evidence/final2-wireguard-original-delay')])
