from pathlib import Path
import json,subprocess
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919');s=r/'source';summary=json.loads((r/'evidence/final2-tun/summary.json').read_text())
cases=[v['case'] for v in summary['rows'] if v['review'] and v['case']!='xhttp-h1-tun-full-duplex-1']
(r/'final2-tun-screen-plan.json').write_text(json.dumps({'reason':'Review screen crossings at 8x the original per-flow byte count; pre-existing H1 duplex has its own larger paired follow-up.','cases':cases},indent=2)+'\n')
if not cases:raise SystemExit(0)
name='final2-tun-screen';args=['python3','scripts/run-v07-performance-followup.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(old/'bin/baseline/xray-rust'),'--engine','candidate='+str(r/'bin/final2/xray-rust'),'--suite','tun','--iterations','512','--repeats','5','--output',str(r/'evidence'/name)]
for case in cases:args+=['--case',case]
with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,stdout=log,stderr=subprocess.STDOUT)
print(name,code,flush=True)
subprocess.run(['python3','scripts/summarize-v07-performance.py',str(r/'evidence'/name)],cwd=s,check=True)
if code:raise SystemExit(code)
