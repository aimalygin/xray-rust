from pathlib import Path
import subprocess,os,json,time
r=Path('/private/tmp/xray-v07-opt-20260919');source=r/'source';old=Path('/private/tmp/xray-v07-bench-20260919')
env={k:v for k,v in os.environ.items() if not k.startswith(('XRAY_','NATIVE_','CARGO_PROFILE_')) and k not in ('RUSTFLAGS','GOFLAGS','GOEXPERIMENT')}
env.update(CARGO_TARGET_DIR=str(old/'build'),CARGO_BUILD_JOBS='4',GOTOOLCHAIN='go1.26.5',GOENV='off',GOWORK='off',CGO_ENABLED='0')
cargo=['cargo','test','--offline','--release']
plan=[('native-wg-module-verify',['go','-C','tools/wireguard-reference','mod','verify'],{}),
 ('native-wg-fixture-tests',['go','-C','tools/wireguard-reference','test','-p=4','-mod=readonly','./...'],{}),
 ('gotatun',cargo+['--manifest-path','vendor/gotatun/Cargo.toml','--no-default-features','--features','ring,device','--lib'],{}),
 ('libraries',cargo+['-p','xray-core-rs','-p','xray-wireguard','-p','xray-transport','--lib'],{}),
 ('tun-data-path',cargo+['-p','xray-core-rs','--test','runtime_data_path_tests'],{}),
 ('wg-native',cargo+['-p','xray-wireguard','--test','lifecycle','--test','interop','--test','multi_peer_tests','--test','native_lifecycle','--test','network_change','--','--include-ignored','--nocapture'],{'NATIVE_WIREGUARD_BINARY':str(r/'bin/wireguard-native')}),
 ('wg-xray',cargo+['-p','xray-wireguard','--test','interop','--test','multi_peer_tests','--','--include-ignored','--nocapture'],{'XRAY_WIREGUARD_BINARY':str(old/'bin/xray-core')}),
 ('hy-native',cargo+['-p','xray-transport','--test','hysteria_interop_tests','--test','hysteria_native_interop_tests','--','--ignored','--nocapture'],{'NATIVE_HYSTERIA_BINARY':str(r/'bin/hysteria-native')}),
 ('hy-xray',cargo+['-p','xray-transport','--test','hysteria_interop_tests','--','--ignored','--nocapture'],{'XRAY_HYSTERIA_BINARY':str(old/'bin/xray-core')})]
for protocol,prefix,native in [('wireguard','WG','wireguard-native'),('hysteria','HY','hysteria-native')]:
 for label,selector,binary in [('native','NATIVE_',r/'bin'/native),('xray','XRAY_',old/'bin/xray-core')]:
  e={selector+protocol.upper()+'_BINARY':str(binary)}
  plan.append((protocol+'-core-'+label,cargo+['-p','xray-core-rs','--test',protocol+'_runtime_tests','--test','runtime_data_path_tests',protocol+'_runtime_','--','--ignored','--nocapture'],e))
  if protocol=='hysteria':plan.append(('hysteria-outbound-'+label,cargo+['-p','xray-core-rs','--lib','outbound::hysteria::tests','--','--include-ignored','--nocapture'],e))
plan += [('clippy',['cargo','clippy','--offline','--release','-p','xray-core-rs','-p','xray-wireguard','-p','xray-bench','--all-targets','--','-D','warnings'],{}),('format',['cargo','fmt','--all','--','--check'],{}),('python',['python3','-m','unittest','discover','-s','scripts/tests','-p','test_v07_performance*.py'],{})]
plan = [x for x in plan if x[0] in ('libraries','tun-data-path')] + plan[next(i for i,x in enumerate(plan) if x[0]=='wireguard-core-native'):]
# Repeat the full parallel Xray core group after its earlier isolated PSK timeout.
wg = next(x for x in plan if x[0]=='wireguard-core-xray')
index = plan.index(wg)+1
plan[index:index] = [(f'wireguard-core-xray-repeat-{n}',wg[1],wg[2]) for n in range(2,6)]
results=[]
for name,args,extra in plan:
 started=time.time();print('START',name,flush=True)
 with (r/('j-test-'+name+'.log')).open('w') as log:code=subprocess.call(args,cwd=source,env=env|extra,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=args,environment=extra,returncode=code,seconds=time.time()-started))
 (r/'j-tests.json').write_text(json.dumps(results,indent=2)+'\n')
 print('END',name,code,flush=True)
 if code:raise SystemExit(code)
