from pathlib import Path
import json
r=Path('/private/tmp/xray-v07-opt-20260919')
p=r/'final2-campaign.json'
if p.exists():
 for row in json.loads(p.read_text()):print(row['name'],row['returncode'],round(row['seconds'],1))
for suite in ['new','tun','reality','legacy','h1-long','hysteria-delay-download']:
 p=r/'evidence'/('final2-'+suite)/'manifest.json'
 if not p.exists():continue
 d=json.loads(p.read_text());runs=d['runs'];failed=[x for x in runs if x['returncode']]
 print(suite,len(runs),'/',len(d['cases'])*len(d['versions'])*d['repeats'],d.get('status','running'),'failures',[(x['case'],x['version'],x['repeat']) for x in failed])
 p=p.with_name('summary.json')
 if p.exists():
  summary=json.loads(p.read_text());print('review',[(x['case'],x['review']) for x in summary['rows'] if x['review']])
