from pathlib import Path
import subprocess,os,json,hashlib,shutil
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919');source=r/'source'
binary=r/'bin/g-diagnostic/xray-rust';binary.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/'build/release/xray-rust',binary)
patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=source);(binary.parent/'source.patch').write_bytes(patch)
(binary.parent/'build.json').write_text(json.dumps(dict(sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),patch_sha256=hashlib.sha256(patch).hexdigest(),diagnostic=True),indent=2))
for name,extra in [('g-default',{}),('g-udp4m',{'XRAYDIAG_UDP_RCV_KIB':'4096'})]:
 env=os.environ|{'XRAYDIAG_WG_STATS':'1'}|extra
 args=['python3',str(source/'scripts/run-v07-performance-followup.py'),'--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','diagnostic='+str(binary),'--suite','new','--case','wireguard-socks-full-duplex-8','--repeats','2','--output',str(r/'evidence'/name)]
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
 (r/'evidence'/name/'quality.json').write_text(json.dumps({'usable_for_performance':False,'reason':'Temporary runtime diagnostics; environment '+str(extra)},indent=2))
 print(name,code,flush=True)
