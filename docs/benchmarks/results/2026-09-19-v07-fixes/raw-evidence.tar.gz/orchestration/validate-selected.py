from pathlib import Path
import subprocess,os,json,time
r=Path('/private/tmp/xray-v07-opt-20260919');s=r/'source';old=Path('/private/tmp/xray-v07-bench-20260919')
env=os.environ|{'CARGO_TARGET_DIR':str(old/'build'),'CARGO_BUILD_JOBS':'4'}
plan=[('tun-data-path',['cargo','test','--offline','--release','-p','xray-core-rs','--test','runtime_data_path_tests'],{}),('wireguard-core-xray',['cargo','test','--offline','--release','-p','xray-core-rs','--test','wireguard_runtime_tests','--','--ignored','--nocapture'],{'XRAY_WIREGUARD_BINARY':str(old/'bin/xray-core')}),('clippy',['cargo','clippy','--offline','--release','-p','xray-core-rs','-p','xray-wireguard','-p','xray-bench','--all-targets','--','-D','warnings'],{}),('format',['cargo','fmt','--all','--','--check'],{})]
rows=[]
for name,args,extra in plan:
 print(name,flush=True);started=time.time()
 with (r/('selected-test-'+name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,env=env|extra,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=args,environment=extra,returncode=code,seconds=time.time()-started));(r/'selected-tests.json').write_text(json.dumps(rows,indent=2)+'\n')
 if code:raise SystemExit(code)
