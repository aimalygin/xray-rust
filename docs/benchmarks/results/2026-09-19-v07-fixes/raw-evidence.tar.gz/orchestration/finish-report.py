from pathlib import Path
import json,shutil,statistics,subprocess
r=Path('/private/tmp/xray-v07-opt-20260919');s=r/'source';e=r/'evidence';out=s/'docs/benchmarks/results/2026-09-19-v07-fixes';data=out/'data'
subprocess.run(['python3',str(r/'report-tables.py')],check=True)
for p in sorted(e.glob('final2-*')):
 for name in ['manifest.json','summary.json','quality.json']:
  if (p/name).exists():shutil.copy2(p/name,data/(p.name+'-'+name))
for name,src in [('build.json',r/'bin/final2/build.json'),('tests.json',r/'m-tests.json'),('selected-window.json',r/'selected-window.json')]:shutil.copy2(src,data/name)
for name in ['final2-v05.log','final2-v06.log','vendor-final-verify.log']:shutil.copy2(r/name,data/name)
for name in ['benchmark-raw.json','performance.json','build-manifest.json']:shutil.copy2(e/'final2-v06'/name,data/('v06-'+name))
controls={'close':{},'echo':{},'notes':['1000-connection close invocation rejected before measurement by the unchanged historical driver. The 64-connection group is complete; 256 replaces the unsupported larger diagnostic.','Historical harness Git provenance is runtime cwd metadata. Frozen binary hashes in the manifests identify the measured version.']}
for group,count in [('final2-close-control',64),('final2-close-control-256',256)]:
 controls['close'][count]={}
 for v in ['baseline','candidate']:
  vals=[json.loads(p.read_text())['connection_close']['avg_ns'] for p in sorted((e/group).glob(f'close-{count}-{v}-*/*/phase2-probe/result.json'))]
  assert len(vals)==5
  controls['close'][count][v]={'avg_ns_samples':vals,'median_ns':statistics.median(vals)}
for v in ['baseline','candidate']:
 controls['echo'][v]={}
 for k in ['cpu_millis','peak_rss_kib','duration_ms']:
  vals=[json.loads(p.read_text())[k]['median'] for p in sorted((e/'final2-echo-control').glob(v+'-*/*/xray-rust/tun-tcp-freedom/summary.json'))]
  assert len(vals)==5
  controls['echo'][v][k]={'samples':vals,'median':statistics.median(vals)}
(data/'close-echo-controls.json').write_text(json.dumps(controls,indent=2)+'\n')
text=(r/'report-draft.md').read_text();assert 'PENDING' not in text
(out/'README.md').write_text(text)
p=s/'docs/v07-performance.md';text=p.read_text().replace('Current evidence: [2026-09-19 comparison and protocol campaign](benchmarks/results/2026-09-19-v07/README.md).','Current evidence: [regression fixes and final campaign](benchmarks/results/2026-09-19-v07-fixes/README.md).\nThe [initial comparison](benchmarks/results/2026-09-19-v07/README.md) is retained with its failures.\n\nThe selected fixes pass both historical gates and 990/990 primary runs. They\nrestore idle-memory budgets and H1 TUN throughput, reduce Hysteria2 TUN memory,\nand resolve the observed WireGuard load failures. Follow-up results, residual\ntradeoffs and rejected alternatives are recorded in the final report; this\nhost evidence does not replace mobile-device/network acceptance.')
p.write_text(text)
p=s/'docs/roadmap.md';text=p.read_text();start=text.index('The [2026-09-19 performance campaign]');end=text.index('\nGoal: add Hysteria 2',start)
text=text[:start]+'''The [initial performance campaign](benchmarks/results/2026-09-19-v07/README.md)
found idle-RSS budget failures, repeatable H1 TUN stalls and WireGuard load
timeouts. The [fix campaign](benchmarks/results/2026-09-19-v07-fixes/README.md)
passes both unchanged historical gates and all 990 primary runs against frozen
`v0.6.1` / original-v0.7 controls. Shared async setup allocation, TUN capacity
wakeups, engine lock/queue ownership, TCP window advertisement and smoltcp loss
recovery are corrected. H1 TUN throughput returns to the v0.6.1 level;
Hysteria2's long eight-flow TUN upload improves from 72 to 211 MiB/s while RSS
falls from 104 to 47 MiB. WireGuard completes all 100 protocol runs and 40
additional eight/sixteen-flow duplex stress runs. The report retains initial
review flags, follow-up controls, rejected large-window variants and the
remaining memory/throughput tradeoffs. These host results do not establish
physical-device or unrestricted network acceptance for the revised runtime.
See the [reproduction method](v07-performance.md).
''' +text[end:];p.write_text(text)
print('Report and current documentation updated')
