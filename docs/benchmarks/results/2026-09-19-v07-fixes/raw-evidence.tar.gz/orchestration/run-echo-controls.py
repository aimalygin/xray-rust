from pathlib import Path
import subprocess, importlib.util, json, os
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919')
spec=importlib.util.spec_from_file_location('bench',r/'source/scripts/run-v07-performance.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
out=r/'evidence/echo-controls';out.mkdir()
versions={'v061':old/'bin/baseline/xray-rust','v07':old/'bin/candidate/xray-rust','fixed':r/'bin/d/xray-rust','legacy_loop_ablation':r/'bin/c-diagnostic/xray-rust'}
manifest={'repeats':3,'versions':{v:{'binary':str(p),'sha256':b.sha(p)} for v,p in versions.items()},'driver_sha256':b.sha(old/'bin/candidate/xray-bench'),'runs':[]}
for rep in range(3):
 for version in (list(versions) if rep%2==0 else list(reversed(versions))):
  name=f'{version}-{rep+1}';print(name,flush=True)
  os.environ.pop('XRAYDIAG_OLD_TUN_LOOP',None)
  if version=='legacy_loop_ablation':os.environ['XRAYDIAG_OLD_TUN_LOOP']='1'
  args=[str(old/'bin/candidate/xray-bench'),'run','--engine','xray-rust','--xray-rust-bin',str(versions[version]),'--no-auto-build','--runs','1','--workload','tun-tcp-freedom','--connections','16','--iterations','100','--payload-size','1024','--out-dir',str(out/name)]
  result=b.execute(args,out/(name+'.log'),r/'source');result.update(version=version,repeat=rep+1,output_relative=name)
  manifest['runs'].append(result);b.save(out/'manifest.json',manifest)
  if result['returncode']:raise RuntimeError(name)
