from pathlib import Path
import subprocess,json,hashlib,time
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919');out=r/'evidence/final2-close-control';out.mkdir(exist_ok=False)
versions={'baseline':old/'bin/baseline/xray-bench','candidate':r/'bin/final2/xray-bench'}
manifest={'repeats':5,'versions':{v:{'binary':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for v,p in versions.items()},'connections':[64,1000],'runs':[]}
for count in [64,1000]:
 for repeat in range(1,6):
  for version in list(versions) if repeat%2 else reversed(versions):
   name=f'close-{count}-{version}-{repeat}';args=[str(versions[version]),'phase2-probe','--iterations','10000','--members','64','--connections',str(count),'--chain-depth','8','--out-dir',str(out/name)];started=time.time()
   with (out/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=r/'source',stdout=log,stderr=subprocess.STDOUT,timeout=120)
   manifest['runs'].append(dict(name=name,version=version,connections=count,repeat=repeat,returncode=code,seconds=time.time()-started));(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(name,code,flush=True)
   if code:raise SystemExit(code)
# Same frozen external driver for both engine versions: isolate TUN echo CPU.
import importlib.util
spec=importlib.util.spec_from_file_location('collector',r/'source/scripts/run-v07-performance.py');collector=importlib.util.module_from_spec(spec);spec.loader.exec_module(collector)
out=r/'evidence/final2-echo-control';out.mkdir(exist_ok=False)
versions={'baseline':old/'bin/baseline/xray-rust','candidate':r/'bin/final2/xray-rust'};driver=old/'bin/candidate/xray-bench'
manifest={'repeats':5,'driver_sha256':collector.sha(driver),'versions':{v:{'binary':str(p),'sha256':collector.sha(p)} for v,p in versions.items()},'runs':[]}
for repeat in range(1,6):
 for version in list(versions) if repeat%2 else reversed(versions):
  name=f'{version}-{repeat}';args=[str(driver),'run','--engine','xray-rust','--xray-rust-bin',str(versions[version]),'--no-auto-build','--runs','1','--workload','tun-tcp-freedom','--connections','16','--iterations','100','--payload-size','1024','--out-dir',str(out/name)]
  result=collector.execute(args,out/(name+'.log'),r/'source');result.update(version=version,repeat=repeat,output_relative=name);manifest['runs'].append(result);collector.save(out/'manifest.json',manifest);print('echo',name,result['returncode'],flush=True)
  if result['returncode']:raise SystemExit(result['returncode'])
# Check the short new-protocol workload with an immediate original-v0.7 control.
name='final2-hysteria-short';args=['python3','scripts/run-v07-performance-followup.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(old/'bin/candidate/xray-rust'),'--engine','candidate='+str(r/'bin/final2/xray-rust'),'--suite','new','--case','hysteria2-tun-upload-8','--case','hysteria2-tun-full-duplex-8','--iterations','64','--repeats','5','--output',str(r/'evidence'/name)]
with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=r/'source',stdout=log,stderr=subprocess.STDOUT)
print(name,code,flush=True)
subprocess.run(['python3','scripts/summarize-v07-performance.py',str(r/'evidence'/name)],cwd=r/'source',check=True)
if code:raise SystemExit(code)
# Isolate the high-variance REALITY throughput screen with fresh fixtures.
for name,iterations in [('final2-reality-repeat',512),('final2-reality-long',2048)]:
 args=['python3','scripts/run-v07-performance-followup.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(old/'bin/baseline/xray-rust'),'--engine','candidate='+str(r/'bin/final2/xray-rust'),'--suite','reality','--case','reality-vision-socks-full-duplex-8','--iterations',str(iterations),'--repeats','5','--output',str(r/'evidence'/name)]
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=r/'source',stdout=log,stderr=subprocess.STDOUT)
 print(name,code,flush=True)
 subprocess.run(['python3','scripts/summarize-v07-performance.py',str(r/'evidence'/name)],cwd=r/'source',check=True)
 if code:raise SystemExit(code)
