from pathlib import Path
import subprocess,json,hashlib,shutil,importlib.util,time
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919');s=r/'source'
binary=r/'bin/j/xray-rust';binary.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(old/'build/release/xray-rust',binary)
patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=s)
(binary.parent/'source.patch').write_bytes(patch)
(binary.parent/'build.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest()},indent=2))
common=['python3',str(s/'scripts/run-v07-delayed-protocol.py'),'--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(r/'bin/i/xray-rust'),'--engine','candidate='+str(binary),'--protocol','hysteria2','--path','tun','--traffic','download','--iterations','64','--repeats','5','--output',str(r/'evidence/j-hysteria-delay')]
with (r/'j-hysteria-delay.log').open('w') as log:code=subprocess.call(common,stdout=log,stderr=subprocess.STDOUT,cwd=s)
print('j-hysteria-delay',code,flush=True)
subprocess.run(['python3',str(s/'scripts/summarize-v07-performance.py'),str(r/'evidence/j-hysteria-delay')],check=True)
spec=importlib.util.spec_from_file_location('bench',s/'scripts/run-v07-performance.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
out=r/'evidence/j-echo';out.mkdir()
versions={'v061':old/'bin/baseline/xray-rust','i':r/'bin/i/xray-rust','j':binary}
manifest={'repeats':5,'versions':{v:{'binary':str(p),'sha256':b.sha(p)} for v,p in versions.items()},'driver_sha256':b.sha(old/'bin/candidate/xray-bench'),'runs':[]}
for rep in range(5):
 for version in (list(versions) if rep%2==0 else list(reversed(versions))):
  name=f'{version}-{rep+1}';print(name,flush=True)
  args=[str(old/'bin/candidate/xray-bench'),'run','--engine','xray-rust','--xray-rust-bin',str(versions[version]),'--no-auto-build','--runs','1','--workload','tun-tcp-freedom','--connections','16','--iterations','100','--payload-size','1024','--out-dir',str(out/name)]
  result=b.execute(args,out/(name+'.log'),s);result.update(version=version,repeat=rep+1,output_relative=name)
  manifest['runs'].append(result);b.save(out/'manifest.json',manifest)
  if result['returncode']:raise RuntimeError(name)
with (r/'j-h1.log').open('w') as log:
 code=subprocess.call(['python3',str(s/'scripts/run-v07-performance-followup.py'),'--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(old/'bin/baseline/xray-rust'),'--engine','candidate='+str(binary),'--suite','tun','--case','xhttp-h1-tun-full-duplex-1','--iterations','512','--repeats','3','--output',str(r/'evidence/j-h1')],stdout=log,stderr=subprocess.STDOUT,cwd=s)
print('j-h1',code,flush=True)
subprocess.run(['python3',str(s/'scripts/summarize-v07-performance.py'),str(r/'evidence/j-h1')],check=True)
