from pathlib import Path
import shutil
r=Path('/private/tmp/xray-v07-opt-20260919');base=r/'source/crates/xray-wireguard/src'
for name in ['client.rs','stack.rs','io.rs']:
 p=base/name;q=r/'k-source'/name;q.parent.mkdir(exist_ok=True);shutil.copy2(p,q)
p=base/'client.rs';s=p.read_text();old='''            let mut stack_task = Box::pin(stack.run(task_stop.clone()));
            loop {''';assert old in s;s=s.replace(old,'''            let mut stack_task = Box::pin(stack.run(task_stop.clone()));
            let mut tick = tokio::time::interval(Duration::from_millis(500));
            loop {''');s=s.replace('''                    _ = device.wait() => break,''','''                    _ = device.wait() => { eprintln!("WGTRACE device ended"); break; },
                    _ = tick.tick() => { eprintln!("WGTRACE memory={:?}",device.memory_snapshot().await); },''');p.write_text(s)
p=base/'stack.rs';s=p.read_text();s=s.replace('''    read_eof: bool,
}''','''    read_eof: bool,
    diag_sent: u64,
    diag_received: u64,
    diag_last_io: Clock,
}''',1)
s=s.replace('''                read_eof: false,''','''                read_eof: false,
                diag_sent: 0,
                diag_received: 0,
                diag_last_io: Clock::now(),''')
s=s.replace('''                            Poll::Ready(Ok(_)) => {
                                progress = true;''','''                            Poll::Ready(Ok(n)) => {
                                flow.diag_sent += n as u64;
                                flow.diag_last_io = Clock::now();
                                progress = true;''',1)
s=s.replace('''                                Poll::Ready(Ok(n)) if n != 0 => {
                                    progress = true;''','''                                Poll::Ready(Ok(n)) if n != 0 => {
                                    flow.diag_received += n as u64;
                                    flow.diag_last_io = Clock::now();
                                    progress = true;''',1)
s=s.replace('''    pub(crate) async fn run(mut self, stop: Stop) {
        loop {''','''    pub(crate) async fn run(mut self, stop: Stop) {
        let mut reported = Clock::now();
        loop {''')
marker='''            let wake = self.wake.clone();''';assert marker in s;s=s.replace(marker,'''            if reported.elapsed() >= Duration::from_millis(500) {
                for entry in self.flows.values() { if let Entry::Tcp(flow) = entry {
                    if flow.diag_last_io.elapsed() < Duration::from_secs(2) { continue; }
                    let socket=self.sockets.get::<tcp::Socket>(flow.handle);
                    eprintln!("WGTRACE flow={} port={} state={:?} tx={} rx={} sent={} received={} write_eof={} read_eof={} delay={delay:?} tx_free={} incoming={} held_rx={}", flow.flow.id,flow.port,socket.state(),socket.send_queue(),socket.recv_queue(),flow.diag_sent,flow.diag_received,flow.write_eof,flow.read_eof,self.device.tx.capacity(),self.incoming.len(),self.device.rx.is_some());
                    if let Some(records) = self.device.diag.lock().unwrap().packets.get(&flow.port) {
                        for record in records { eprintln!("WGTRACE packet {record}"); }
                    }
                }}
                reported=Clock::now();
            }
'''+marker)
s=s.replace('''    mtu: usize,
}
struct Receive(Packet<Ip>);''','''    mtu: usize,
    diag: Arc<std::sync::Mutex<Diagnostic>>,
}
struct Receive(Packet<Ip>, Arc<std::sync::Mutex<Diagnostic>>);''')
s=s.replace('''struct Transmit {
    permit: mpsc::OwnedPermit<Packet<Ip>>,
    mtu: usize,
}''','''struct Transmit {
    permit: mpsc::OwnedPermit<Packet<Ip>>,
    mtu: usize,
    diag: Arc<std::sync::Mutex<Diagnostic>>,
}''')
s=s.replace('''            rx: None,''','''            rx: None,
            diag: Arc::new(std::sync::Mutex::new(Diagnostic::default())),''')
s=s.replace('''Some((Receive(self.rx.take().unwrap()), transmit))''','''Some((Receive(self.rx.take().unwrap(), self.diag.clone()), transmit))''')
s=s.replace('''            permit: self.tx.clone().try_reserve_owned().ok()?,
            mtu: self.mtu,''','''            permit: self.tx.clone().try_reserve_owned().ok()?,
            mtu: self.mtu,
            diag: self.diag.clone(),''')
s=s.replace('''        f(&self.0.into_bytes())''','''        let bytes = self.0.into_bytes();
        self.1.lock().unwrap().record(false, &bytes);
        f(&bytes)''')
s=s.replace('''        let result = f(&mut bytes);
        if let Ok(packet)''','''        let result = f(&mut bytes);
        self.diag.lock().unwrap().record(true, &bytes);
        if let Ok(packet)''')
s+='''
#[derive(Default)]
struct Diagnostic {
    packets: HashMap<u16, std::collections::VecDeque<String>>,
}
impl Diagnostic {
    fn record(&mut self, outgoing: bool, bytes: &[u8]) {
        use smoltcp::wire::{IpProtocol, Ipv4Packet, Ipv6Packet, TcpPacket};
        let (protocol,payload) = match bytes.first().map(|b| b >> 4) {
            Some(4) => { let Ok(ip) = Ipv4Packet::new_checked(bytes) else {return}; (ip.next_header(), ip.payload()) },
            Some(6) => { let Ok(ip) = Ipv6Packet::new_checked(bytes) else {return}; (ip.next_header(), ip.payload()) },
            _ => return,
        };
        if protocol != IpProtocol::Tcp { return; }
        let Ok(tcp) = TcpPacket::new_checked(payload) else { return; };
        let port = if outgoing { tcp.src_port() } else { tcp.dst_port() };
        let line = format!("{} seq={:?} ack={:?} win={} len={} syn={} fin={} rst={} ack_flag={}", if outgoing {"tx"} else {"rx"},tcp.seq_number(),tcp.ack_number(),tcp.window_len(),tcp.payload().len(),tcp.syn(),tcp.fin(),tcp.rst(),tcp.ack());
        let records = self.packets.entry(port).or_default();
        if records.len() == 16 { records.pop_front(); }
        records.push_back(line);
    }
}
'''
assert s.count('diag_sent: 0')==1, 'TcpFlow initializer not found'
p.write_text(s)
p=base/'io.rs';s=p.read_text();s=s.replace('''            socket.bind(&bind.into())?;''','''            eprintln!("WGTRACE carrier recv={} send={}",socket.recv_buffer_size()?,socket.send_buffer_size()?);
            socket.bind(&bind.into())?;''')
s=s.replace('''                if result? != packet.len()''','''                if let Err(ref error) = result { eprintln!("WGTRACE UDP send error={error:?}"); }
                if result? != packet.len()''')
s=s.replace('''                }) => break result?,''','''                }) => {
                    if let Err(ref error) = result { eprintln!("WGTRACE UDP receive error={error:?}"); }
                    break result?;
                },''');p.write_text(s)
