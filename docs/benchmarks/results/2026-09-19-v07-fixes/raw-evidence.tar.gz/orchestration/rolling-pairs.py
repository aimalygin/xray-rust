from pathlib import Path
import sys,json,statistics
r=Path('/private/tmp/xray-v07-opt-20260919/evidence')/(sys.argv[1] if len(sys.argv)>1 else 'final2-tun');m=json.loads((r/'manifest.json').read_text());complete=0;flags=[]
for case in m['cases']:
 rows={};ready=True
 for version in ['baseline','candidate']:
  runs=[v for v in m['runs'] if v['case']==case['id'] and v['version']==version]
  if len(runs)!=m['repeats'] or any(v['returncode'] for v in runs):ready=False;break
  values=[]
  for run in runs:
   paths=list((r/run['output_relative']).rglob('result.json'))
   if len(paths)!=1:raise RuntimeError(run)
   values.append(json.loads(paths[0].read_text()))
  rows[version]=values
 if not ready:continue
 complete+=1
 for metric in ['throughput_mib_s','cpu_millis','peak_rss_kib']:
  def value(x):
   return x[metric] if metric in x else x['throughput_mbps']/8/1.048576
  b=statistics.median(value(x) for x in rows['baseline']);c=statistics.median(value(x) for x in rows['candidate'])
  if b and (c/b<.85 if metric=='throughput_mib_s' else c/b>1.15):flags.append(dict(case=case['id'],metric=metric,baseline=round(b,3),candidate=round(c,3),ratio=round(c/b,3)))
print(json.dumps(dict(completed_cases=complete,screen_flags=flags),indent=2))
