from pathlib import Path
import tarfile,json,hashlib,subprocess
r=Path('/private/tmp/xray-v07-opt-20260919');source=r/'source'
out=source/'docs/benchmarks/results/2026-09-19-v07-fixes'
out.mkdir(parents=True,exist_ok=True)
items=[]
for base in ['evidence','collector-history']:
 for p in (r/base).rglob('*'):
  if p.is_file():items.append((p,str(p.relative_to(r))))
for name in ['smoltcp-0.14.0.metadata.json']:
 p=r/'references'/name;items.append((p,'references/'+name))
items.append((r/'smoltcp-runtime-tcp.diff','references/smoltcp-runtime-tcp.diff'))
for p in sorted(r.glob('*.log')):items.append((p,'logs/'+p.name))
for p in sorted(r.glob('*.lock')):items.append((p,'references/'+p.name))
for p in sorted(r.glob('*.json')):items.append((p,'metadata/'+p.name))
for p in sorted(r.glob('*.py')):items.append((p,'orchestration/'+p.name))
for p in (r/'bin').rglob('*'):
 if p.is_file() and p.suffix in ('.json','.patch'):
  items.append((p,'builds/'+str(p.relative_to(r/'bin'))))
for name in ['run-v07-performance-followup.py','run-v07-delayed-protocol.py','run-v07-performance.py','summarize-v07-performance.py','run-v07-apple-protocol-fixture.py']:
 p=source/'scripts'/name;items.append((p,'collectors/'+name))
patch=r/'final-source.patch'
patch.write_bytes(subprocess.check_output(['git','diff','7f87ffe7eaf4ed088a45172d2468df956f26550b','HEAD','--binary'],cwd=source))
items.append((patch,'source/final.patch'))
intermediate=r/'intermediate-i-source.patch'
intermediate.write_bytes(subprocess.check_output(['git','diff','7f87ffe7eaf4ed088a45172d2468df956f26550b','ae123b7bd4a8a9501054fb097ffef01e0c884f2e','--binary'],cwd=source))
items.append((intermediate,'source/intermediate-i.patch'))
documentation=r/'final-documentation.patch'
documentation.write_bytes(subprocess.check_output(['git','diff','HEAD','--binary','--','docs/roadmap.md','docs/v07-performance.md','docs/v07-wireguard-adapter.md'],cwd=source))
items.append((documentation,'source/documentation.patch'))

manifest={name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p,name in items}
(out/'artifact-index.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
with tarfile.open(out/'raw-evidence.tar.gz','w:gz') as archive:
 for p,name in sorted(items,key=lambda row:row[1]):archive.add(p,arcname=name,recursive=False)
print(json.dumps({'files':len(items),'archive_bytes':(out/'raw-evidence.tar.gz').stat().st_size,'sha256':hashlib.sha256((out/'raw-evidence.tar.gz').read_bytes()).hexdigest()},indent=2))
