from pathlib import Path
import subprocess,json,hashlib,shutil
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919');s=r/'source'
binary=r/'bin/o/xray-rust';binary.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/'build/release/xray-rust',binary)
patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=s);(binary.parent/'source.patch').write_bytes(patch)
(binary.parent/'build.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest()},indent=2)+'\n')
rows=[]
for connections in [16,8]:
 for repeat in range(1,21):
  name=f'o-wireguard-duplex-{connections}-{repeat:02}'
  args=['python3','scripts/run-v07-performance-followup.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','fixed='+str(binary),'--suite','new','--repeats','1','--connections',str(connections),'--case',f'wireguard-socks-full-duplex-{connections}','--output',str(r/'evidence'/name)]
  with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,stdout=log,stderr=subprocess.STDOUT)
  rows.append(dict(name=name,returncode=code));(r/'o-stress.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,code,flush=True)
  subprocess.run(['python3','scripts/summarize-v07-performance.py',str(r/'evidence'/name)],cwd=s,check=True)
  if code:raise SystemExit(code)
for name,baseline,iterations in [('o-wireguard-go-delay',old/'bin/xray-core',32),('o-wireguard-long-delay',r/'bin/m/xray-rust',256),('o-wireguard-go-long-delay',old/'bin/xray-core',256)]:
 args=['python3','scripts/run-v07-delayed-protocol.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(baseline),'--engine','candidate='+str(binary),'--protocol','wireguard','--path','socks','--iterations',str(iterations),'--repeats','3','--output',str(r/'evidence'/name)]
 if iterations==256:args+=['--connections','1']
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,stdout=log,stderr=subprocess.STDOUT)
 print(name,code,flush=True)
 subprocess.run(['python3','scripts/summarize-v07-performance.py',str(r/'evidence'/name)],cwd=s,check=True)
 if code:raise SystemExit(code)
