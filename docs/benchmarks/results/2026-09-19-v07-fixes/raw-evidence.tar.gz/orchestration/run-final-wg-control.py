from pathlib import Path
import subprocess,json,time
r=Path('/private/tmp/xray-v07-opt-20260919');s=r/'source';old=Path('/private/tmp/xray-v07-bench-20260919')
args=['python3','scripts/run-v07-delayed-protocol.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(old/'bin/xray-core'),'--engine','candidate='+str(r/'bin/final/xray-rust'),'--protocol','wireguard','--path','socks','--iterations','32','--repeats','3','--output',str(r/'evidence/final-wireguard-go-delay')]
start=time.time()
with (r/'final-wireguard-go-delay.log').open('w') as log:code=subprocess.call(args,cwd=s,stdout=log,stderr=subprocess.STDOUT)
(r/'final-wireguard-go-delay-run.json').write_text(json.dumps({'command':args,'returncode':code,'seconds':time.time()-start},indent=2)+'\n')
subprocess.run(['python3','scripts/summarize-v07-performance.py',str(r/'evidence/final-wireguard-go-delay')],cwd=s,check=True)
raise SystemExit(code)
