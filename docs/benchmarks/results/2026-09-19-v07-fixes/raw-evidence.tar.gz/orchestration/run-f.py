from pathlib import Path
import subprocess, json, hashlib, shutil
r=Path('/private/tmp/xray-v07-opt-20260919')
old=Path('/private/tmp/xray-v07-bench-20260919')
source=r/'source'
binary=r/'bin/f/xray-rust'
binary.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(old/'build/release/xray-rust',binary)
patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=source)
(binary.parent/'source.patch').write_bytes(patch)
(binary.parent/'build.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest()},indent=2))
common=['python3',str(source/'scripts/run-v07-performance-followup.py'),'--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--repeats','3']
plan=[('f-wireguard','new',['baseline='+str(r/'bin/e/xray-rust'),'candidate='+str(binary)],['wireguard-'+p+'-'+d+'-8' for p in ['socks','tun'] for d in ['upload','full-duplex']],None)]
for name,suite,engines,cases,iterations in plan:
    args=common+['--suite',suite,'--output',str(r/'evidence'/name)]
    for e in engines:args+=['--engine',e]
    for c in cases:args+=['--case',c]
    if iterations:args+=['--iterations',str(iterations)]
    with (r/(name+'.log')).open('w') as log:
        code=subprocess.call(args,stdout=log,stderr=subprocess.STDOUT,cwd=source)
    print(name,code,flush=True)
    if code:break
    subprocess.run(['python3',str(source/'scripts/summarize-v07-performance.py'),str(r/'evidence'/name)],check=True)

with (r/'f-delay.log').open('w') as log:
    code=subprocess.call(['python3',str(source/'scripts/run-v07-delayed-protocol.py'),'--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(r/'bin/e/xray-rust'),'--engine','candidate='+str(binary),'--protocol','wireguard','--repeats','3','--output',str(r/'evidence/f-delay')],stdout=log,stderr=subprocess.STDOUT,cwd=source)
print('f-delay',code,flush=True)
