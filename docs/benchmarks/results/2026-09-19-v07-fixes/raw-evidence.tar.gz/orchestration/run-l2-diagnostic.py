from pathlib import Path
import subprocess,json,hashlib,shutil
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919');s=r/'source'
binary=r/'bin/l2-diagnostic/xray-rust';binary.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/'build/release/xray-rust',binary)
patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=s);(binary.parent/'source.patch').write_bytes(patch)
(binary.parent/'build.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest(),'usable_for_performance':False,'reason':'TCP window/progress traces and periodic device polls'},indent=2)+'\n')
rows=[]
for n in range(1,21):
 name=f'l2-wireguard-{n:02}';out=r/'evidence'/name
 args=['python3','scripts/run-v07-performance-followup.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','diagnostic='+str(binary),'--suite','new','--repeats','1','--case','wireguard-socks-full-duplex-8','--output',str(out)]
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,stdout=log,stderr=subprocess.STDOUT)
 if out.exists():(out/'quality.json').write_text(json.dumps({'usable_for_performance':False,'reason':'Instrumented TCP header/progress trace and 500 ms polling; use only to diagnose stalled flow'},indent=2)+'\n')
 rows.append({'name':name,'returncode':code});(r/'l2-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,code,flush=True)
 if code:break
