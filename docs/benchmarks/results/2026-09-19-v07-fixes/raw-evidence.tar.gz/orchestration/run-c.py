from pathlib import Path
import subprocess, json, hashlib, shutil, os
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919');source=r/'source'
binary=r/'bin/c-diagnostic/xray-rust';binary.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(old/'build/release/xray-rust',binary)
patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=source)
(binary.parent/'source.patch').write_bytes(patch)
(binary.parent/'build.json').write_text(json.dumps({'diagnostic_only':True,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest()},indent=2))
common=['python3',str(source/'scripts/run-v07-performance-followup.py'),'--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','diagnostic='+str(binary)]
plan=[('c-h1-current','tun',['xhttp-h1-tun-full-duplex-1'],1,128,{'XRAYDIAG_H1':'1'}),
      ('c-h1-legacy','tun',['xhttp-h1-tun-full-duplex-1'],1,128,{'XRAYDIAG_H1':'1','XRAYDIAG_OLD_TUN_LOOP':'1'}),
      ('c-wireguard-tick','new',['wireguard-socks-upload-8','wireguard-socks-full-duplex-8'],3,512,{'XRAYDIAG_WG_STATS':'1'})]
for name,suite,cases,repeats,iterations,flags in plan:
    args=common+['--suite',suite,'--output',str(r/'evidence'/name),'--repeats',str(repeats),'--iterations',str(iterations)]
    for c in cases:args+=['--case',c]
    env=os.environ.copy();env.update(flags)
    with (r/(name+'.log')).open('w') as log:rc=subprocess.call(args,env=env,cwd=source,stdout=log,stderr=subprocess.STDOUT)
    (r/'evidence'/name/'diagnostic-policy.json').write_text(json.dumps({'usable_for_performance':False,'environment':flags,'reason':'instrumented engine; WireGuard tick deliberately repolls the stack; legacy TUN loop can deadlock bounded transports'},indent=2))
    print(name,rc,flush=True)
