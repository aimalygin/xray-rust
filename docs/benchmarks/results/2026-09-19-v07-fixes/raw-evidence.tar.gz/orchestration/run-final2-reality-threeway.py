from pathlib import Path
import subprocess
r=Path('/private/tmp/xray-v07-opt-20260919');old=Path('/private/tmp/xray-v07-bench-20260919');s=r/'source';name='final2-reality-threeway'
a=['python3','scripts/run-v07-performance-followup.py','--harness',str(old/'bin/protocol-bench'),'--reference',str(old/'bin/xray-core'),'--engine','baseline='+str(old/'bin/baseline/xray-rust'),'--engine','original='+str(old/'bin/candidate/xray-rust'),'--engine','candidate='+str(r/'bin/final2/xray-rust'),'--suite','reality','--case','reality-vision-socks-full-duplex-8','--iterations','512','--repeats','20','--output',str(r/'evidence'/name)]
with (r/(name+'.log')).open('w') as log:code=subprocess.call(a,cwd=s,stdout=log,stderr=subprocess.STDOUT)
subprocess.run(['python3','scripts/summarize-v07-performance.py',str(r/'evidence'/name)],cwd=s,check=True)
raise SystemExit(code)
