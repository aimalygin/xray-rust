from pathlib import Path
import json,shutil
r=Path('/private/tmp/xray-v07-opt-20260919');s=r/'source';out=s/'docs/benchmarks/results/2026-09-19-v07-fixes';data=out/'data';data.mkdir(parents=True,exist_ok=True)
counts=[];reviews=[];new=[]
for suite in ['new','tun','reality','legacy']:
 p=r/'evidence'/('final2-'+suite);manifest=json.loads((p/'manifest.json').read_text());summary=json.loads((p/'summary.json').read_text())
 counts.append(dict(suite=suite,cases=len(manifest['cases']),runs=len(manifest['runs']),failed=len(summary['failures']),status=manifest['status']))
 for row in summary['rows']:
  if row['review']:reviews.append(dict(suite=suite,case=row['case'],metrics={k:row['ratios'][k] for k in row['review']}))
  if suite=='new':new.append(row)
 for name in ['manifest','summary']:shutil.copy2(p/(name+'.json'),data/(suite+'-'+name+'.json'))
(data/'campaign-summary.json').write_text(json.dumps(dict(counts=counts,reviews=reviews),indent=2)+'\n')
lines=['| Suite | Cases | Runs | Failed |','| --- | ---: | ---: | ---: |']+[f"| {v['suite']} | {v['cases']} | {v['runs']} | {v['failed']} |" for v in counts]
(out/'matrix-table.md').write_text('\n'.join(lines)+'\n')
lines=['| Case | MiB/s median [min–max] | Echo median (µs) | RSS (MiB) | CPU (ms/MiB) |','| --- | ---: | ---: | ---: | ---: |']
for row in new:
 v=row['versions']['candidate'];m=v['metrics']
 if not v['complete']:lines.append(f"| {row['case']} | INCOMPLETE ({v['passed_repeats']} repeats passed) | — | — | — |");continue
 t=m['throughput_mib_s'];latency=m.get('latency_us',{}).get('median')
 lines.append(f"| {row['case']} | {t['median']:.2f} [{t['min']:.2f}–{t['max']:.2f}] | {latency if latency is not None else '—'} | {m['rss_mib']['median']:.2f} | {m['cpu_ms_per_mib']['median']:.2f} |")
(out/'protocol-table.md').write_text('\n'.join(lines)+'\n')
lines=['| Suite / case | Crossings of the 15% review screen |','| --- | --- |']+[f"| {v['suite']} / {v['case']} | "+', '.join(f'{k}: {n:.3f}×' for k,n in v['metrics'].items())+' |' for v in reviews]
(out/'review-table.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(counts=counts,reviews=reviews),indent=2))
