from pathlib import Path
import subprocess,json,hashlib,shutil
r=Path('/private/tmp/xray-v07-opt-20260919');s=r/'source';m=Path('/Users/antonmalygin/xray-rust');old=Path('/private/tmp/xray-v07-bench-20260919')
guards=json.loads((r/'main-starting-hashes.json').read_text());base=guards['head']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=m,text=True).strip()==base,'Main HEAD changed'
expected=json.loads((old/'main-installed-hashes.json').read_text())|guards['files']
paths=set(subprocess.check_output(['git','diff','--name-only',base,'HEAD'],cwd=s,text=True).splitlines())
report=s/'docs/benchmarks/results/2026-09-19-v07-fixes'
assert (report/'README.md').is_file(),'Final report missing'
paths.update(str(p.relative_to(s)) for p in report.rglob('*') if p.is_file())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in sorted(paths):
 src=s/name;dst=m/name
 assert src.is_file(),f'Removal unsupported: {name}'
 if name in expected:
  assert dst.is_file() and digest(dst)==expected[name],f'Main changed: {name}'
 else:
  ref=subprocess.run(['git','show',base+':'+name],cwd=m,capture_output=True)
  if ref.returncode==0:
   assert dst.is_file() and digest(dst)==hashlib.sha256(ref.stdout).hexdigest(),f'Main changed: {name}'
  else:assert not dst.exists(),f'Unexpected existing file: {name}'
installed={}
for name in sorted(paths):
 dst=m/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s/name,dst);installed[name]=digest(dst)
 assert installed[name]==digest(s/name)
(r/'main-fixes-installed-hashes.json').write_text(json.dumps(installed,indent=2)+'\n')
print(json.dumps({'files':len(installed),'head':base,'committed':False},indent=2))
