Rerun of the 2026-10-30 perf-branch campaign (main 9b06d374 vs branch).
The first campaign (../2026-10-30-perf-branch) stopped at block 109/200:
grpc-socks-full-duplex-1 "after" (d1fcd45d) lost its connection to grpc-go's
"too_many_pings" policy (BDP pings sampled at read time). Fixed in 84997341.
before, harness, reference and origin are byte-identical copies of the first
campaign's frozen inputs; after is a fresh isolated build of 84997341.
04:12 stop: five environment rejections in a row on reality-vision-socks-upload-1
(an App Store install held installd at 100-450% CPU). orchestrate-v1.py is
the controller up to then; orchestrate.py (v2) waits for 30 s without heavy
external load before each attempt and allows ten rejected attempts per case.
03:50 stop: vmess-chacha20-socks-udp-1 attempt 1, one "before" (main) UDP echo
trial hung until the harness's 120 s timeout (the echo client does not
retransmit a lost datagram). Retried as attempt 2. progress-1.log and
progress-2.log are the logs up to those stops.
