#!/bin/bash
# After the three-engine base groups: the 1000-flow memory group again, one
# engine at a time; one sing-box REALITY probe; the final 200-case campaign;
# then the remaining three-engine groups (run2.sh).
set -uo pipefail
ulimit -n 8192
ROOT=/Users/antonmalygin/xray-rust
T=$ROOT/target/benchmarks/2026-10-30-three-engine
F=$ROOT/target/benchmarks/2026-10-30-perf-final.noindex
CORE=/private/tmp/xray-migration-tools/xray-v26.10.21
SB=$T/comparators/bin/sing-box-v1.14.4
SBDIR=$T/comparators/sing-box
PY=/private/tmp/xray-migration-bench-20261027/python/bin/python
cd "$ROOT"

until grep -q "ALL GROUPS DONE" "$T/progress.log"; do sleep 10; done
echo "base groups done $(date +%T)"

# Back to back, three engines' 1000-flow runs exhaust the 16,384 ephemeral
# ports while earlier sockets sit in TIME_WAIT (Xray-core reset its third run
# in the compare group). Each engine runs alone after 90 s.
for engine in xray-rust xray-core sing-box; do
  sleep 90
  case "$engine" in
    sing-box) bins=(--sing-box-bin "$SB" --sing-box-dir "$SBDIR") ;;
    *) bins=(--xray-rust-bin "$F/bin/after" --xray-core-bin "$CORE") ;;
  esac
  "$F/bin/harness" run --engine "$engine" "${bins[@]}" --no-auto-build --runs 5 \
    --workload many-idle-flows --connections 1000 --duration-ms 5000 \
    --out-dir "$T/base-flows-1000-$engine" > "$T/base-flows-1000-$engine.log" 2>&1
  echo "flows-1000 $engine exit=$? $(date +%T)"
done

# Does stable sing-box's REALITY client reach a v26.10.21 server? Its source
# removes the X25519MLKEM768 key share that such servers require.
"$F/bin/harness" compare --xray-rust-bin "$F/bin/after" --xray-core-bin "$CORE" --no-auto-build \
  --sing-box-bin "$SB" --sing-box-dir "$SBDIR" \
  --runs 1 --workload reality-vision-xudp --connections 1 --iterations 100 --payload-size 512 \
  --run-timeout-ms 60000 --out-dir "$T/probe-sing-box-reality" > "$T/probe-sing-box-reality.log" 2>&1
echo "sing-box REALITY probe exit=$? $(date +%T)"

"$PY" "$F/orchestrate.py" > "$F/progress.log" 2>&1
echo "campaign exit=$? $(date +%T)"
grep -q "ALL CASES COMPLETE" "$F/progress.log" || exit 1

bash "$T/run2.sh" > "$T/progress2.log" 2>&1
echo "stream groups exit=$? $(date +%T)"
