"""Smoke, then one block per case with retries on environment noise.

Runs unattended from the repository root with a clean tree. Records accepted
blocks in accepted-blocks.json; never overwrites an attempt directory.
"""
import importlib.util
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/Users/antonmalygin/xray-rust')
CAMPAIGN = pathlib.Path('/Users/antonmalygin/xray-rust/target/benchmarks/2026-10-30-perf-rerun')
REFERENCE_SHA256 = 'b8c58f14180eb0cad5665fa2cefb7d10897eec945d007212a053fc1de2257ee8'
COLLECTOR = ROOT / 'scripts/run-migration-benchmarks.py'

spec = importlib.util.spec_from_file_location('m', COLLECTOR)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def run(name, extra):
    print('START', name, time.strftime('%Y-%m-%d %H:%M:%S'), flush=True)
    with (CAMPAIGN / (name + '.log')).open('w') as log:
        return subprocess.run(
            [sys.executable, str(COLLECTOR), '--inputs', str(CAMPAIGN / 'inputs.json'),
             '--output', str(CAMPAIGN / name), '--reference-sha256', REFERENCE_SHA256, *extra],
            cwd=ROOT, stdout=log, stderr=subprocess.STDOUT).returncode


def noise_only(name):
    try:
        runs = json.loads((CAMPAIGN / name / 'manifest.json').read_text())['runs']
    except (FileNotFoundError, json.JSONDecodeError, KeyError):
        return False
    return bool(runs) and all(
        x['returncode'] == 0 and not x['remaining_engine_processes'] and not x['surviving_process_group']
        and x['process_group_empty_after_run'] and not x['ambient_cpu']['observer_errors'] for x in runs
    ) and any(x['ambient_cpu']['heavy_external_load'] or x['ambient_cpu']['compiler_load_detected'] for x in runs)


def main():
    accepted_path = CAMPAIGN / 'accepted-blocks.json'
    accepted = json.loads(accepted_path.read_text()) if accepted_path.exists() else []
    if not (CAMPAIGN / 'smoke-01' / 'manifest.json').exists():
        if run('smoke-01', ['--smoke']):
            print('SMOKE FAILED; full measurements not started', flush=True)
            sys.exit(1)
        print('PASS smoke-01', flush=True)
    finished = {c['id'] for block in accepted for c in json.loads((CAMPAIGN / block / 'manifest.json').read_text())['cases']}
    for case in m.cases():
        if case['id'] in finished:
            continue
        for attempt in range(1, 6):
            name = f"case-{case['id']}-{attempt}"
            if (CAMPAIGN / name).exists():
                continue
            if not run(name, ['--case-id', case['id']]):
                accepted.append(name)
                accepted_path.write_text(json.dumps(accepted, indent=2) + '\n')
                print('PASS', name, flush=True)
                break
            if noise_only(name) and attempt < 5:
                print('REJECTED ENVIRONMENT', name, flush=True)
                time.sleep(30)
                continue
            print('FAILED', name, flush=True)
            print((CAMPAIGN / (name + '.log')).read_text()[-1500:], flush=True)
            sys.exit(1)
    print('ALL CASES COMPLETE', flush=True)


if __name__ == '__main__':
    main()
