"""Interleaved trials of one collector case across any number of client binaries.

usage: ab.py OUT ROUNDS CASE NAME=BINARY [NAME=BINARY ...]
Uses the collector's fixture and request shape (same server, same payload) and
rotates the version order every round. Prints each trial and the medians of
throughput, client CPU per GiB and peak footprint. Never touches the repo.
"""
import copy, importlib.util, json, pathlib, statistics, subprocess, sys, time

ROOT = pathlib.Path('/Users/antonmalygin/xray-rust')
CAMPAIGN = ROOT / 'target/benchmarks/2026-10-30-perf-rerun'
spec = importlib.util.spec_from_file_location('m', ROOT / 'scripts/run-migration-benchmarks.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

out = pathlib.Path(sys.argv[1]).resolve(); rounds = int(sys.argv[2]); case_id = sys.argv[3]
binaries = dict(arg.split('=', 1) for arg in sys.argv[4:])
inputs = json.loads((CAMPAIGN / 'inputs.json').read_text())
paths = {name: pathlib.Path(inputs[name]['path']) for name in ('harness', 'reference', 'origin')}
case = {c['id']: c for c in m.cases()}[case_id]
out.mkdir(parents=True, exist_ok=False)
names = list(binaries)
rows = {name: [] for name in names}
with m.fixture(paths, out / 'server', case['profile']) as (config, _allowed):
    for i in range(rounds):
        shift = i % len(names)
        for name in names[shift:] + names[:shift]:
            trial = f'{name}-{i}'
            request = {k: case[k] for k in ('path', 'traffic', 'connections', 'iterations', 'payload_size')}
            request.update(binary=str(pathlib.Path(binaries[name]).resolve()), config=copy.deepcopy(config),
                           output=str(out / trial), warmup=case['path'] == 'socks',
                           client_preface=case['path'] == 'socks' and case['traffic'] in m.BULK)
            (out / (trial + '.json')).write_text(json.dumps(request))
            rc = subprocess.run([str(paths['harness']), 'protocol-run', str(out / (trial + '.json'))],
                                stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT, cwd=ROOT).returncode
            result = json.loads((out / trial / 'result.json').read_text())
            if rc or result.get('status') != 'pass':
                print(f'{trial} FAILED rc={rc} {result.get("error", "")}', flush=True)
                continue
            size = (result['bytes_sent'] + result['bytes_received']) / 2**20
            row = dict(mibs=result['throughput_mib_s'], cpu=result['cpu_millis'] * 1024 / size,
                       fp=(result.get('peak_footprint_kib') or 0) / 1024, lat=(result.get('latency_us') or {}).get('p50'))
            rows[name].append(row)
            print(f'{trial} ' + ' '.join(f'{k}={v:.1f}' for k, v in row.items() if v is not None), flush=True)
for name in names:
    if rows[name]:
        med = {k: statistics.median(r[k] for r in rows[name]) for k in ('mibs', 'cpu', 'fp')}
        print(f'MEDIAN {case_id} {name}: {med["mibs"]:.1f} MiB/s, {med["cpu"]:.0f} ms/GiB, {med["fp"]:.1f} MiB footprint, n={len(rows[name])}', flush=True)
