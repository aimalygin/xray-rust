from pathlib import Path
import json
ROOT=Path('/Users/antonmalygin/xray-rust');BASE=ROOT/'target/v08-download-investigation';R=ROOT/'docs/benchmarks/results/2026-10-02-v08-download'
def read(p):return json.loads(p.read_text())
x=read(R/'data/inputs.json');s=read(R/'data/control-summary.json');parity=read(R/'data/summary-mac-3pct.json');sdk=read(R/'data/mobile-identity.json')
def value(group,case,version,metric):
 return next(r for r in s[group] if r['case']==case and r['version']==version)['metrics'][metric]['median']
def pct(a,b):return 100*(b/a-1)
rows=[]
for cipher in ['aes128','chacha20']:
 for flows in [1,8]:
  case=f'vmess-{cipher}-socks-download-{flows}';a=value('confirmation',case,'baseline','cpu_ms');b=value('confirmation',case,'combined','cpu_ms');c=value('confirmation',case,'baseline','throughput_mib_s');d=value('confirmation',case,'combined','throughput_mib_s')
  rows.append(f'| {cipher} / {flows} | {a:.0f} → {b:.0f} | {pct(a,b):+.1f}% | {c:.1f} → {d:.1f} | {pct(c,d):+.1f}% |')
latency=[]
for r in s['latency-controls']:
 if r['version']!='baseline':continue
 case=r['case'];a=r['metrics']['latency_p95_us']['median'];b=value('latency-controls',case,'combined','latency_p95_us');latency.append(f'| {case.removeprefix("vmess-").replace("-socks-", " / ")} | {a:.0f} → {b:.0f} | {pct(a,b):+.1f}% |')
case='vmess-chacha20-socks-tcp-latency-8';a=value('latency-confirmation',case,'baseline','latency_p95_us');b=value('latency-confirmation',case,'combined','latency_p95_us')
memory=[]
for group in ['small-memory','bulk-memory']:
 for profile in ['vmess-aes128','vmess-chacha20']:
  vals={v:next(r for r in s[group] if r['profile']==profile and r['version']==v and r['connections']==512)['rss_mib']['median'] for v in ['baseline','four','combined']}
  memory.append(f'| {group} / {profile} | {vals["baseline"]:.3f} | {vals["four"]:.3f} | {vals["combined"]:.3f} | {vals["combined"]-vals["baseline"]:+.3f} |')
reference=[];targets={'cpu':0,'speed':0,'rss':0}
for r in parity['rows']:
 bulk=any('-'+t+'-' in r['case'] for t in ['upload','download','full-duplex'])
 for v in ['xray','singbox']:
  m=r['comparisons'][v]['metrics'];targets['rss']+=bool(m['rss_mib']['meets_point_target'])
  if bulk:
   targets['cpu']+=bool(m['cpu_ms']['meets_point_target']);targets['speed']+=bool(m['throughput_mib_s']['meets_point_target'])
 if bulk and r['case'].startswith('vmess-aes128-'):
  m=r['comparisons']['xray']['metrics'];g=r['comparisons']['singbox']['metrics'];label=r['case'].removeprefix('vmess-aes128-socks-')
  reference.append(f'| {label} | {m["cpu_ms"]["candidate"]:.0f} | {m["cpu_ms"]["reference"]:.0f} | {g["cpu_ms"]["reference"]:.0f} | {m["throughput_mib_s"]["candidate"]:.1f} | {m["throughput_mib_s"]["reference"]:.1f} | {g["throughput_mib_s"]["reference"]:.1f} |')
ci=read(R/'data/ci-run.json');mobile=read(R/'data/mobile-ci-run.json');ci_ok=ci['conclusion']=='success' and mobile['conclusion']=='success'
text=f'''# Bounded VMess download batching — Apple M3 Pro

The retained combination improves one-flow AES download in two ordinary-release campaigns. A 16 KiB ciphertext read-ahead floor after 64 KiB of authenticated TCP payload and a four-record output batch reduce both socket read and write calls. The five-repeat confirmation improves AES one-flow throughput 12.3% and CPU 14.3%. Neither standalone variant justifies selection on its own. The cost is real: about **12 MiB additional retained RSS at 512 connections after large exchanges**; the short-exchange campaign shows no increase.

## Identity and scope

- Measured/committed runtime: `{x['candidate']['commit']}`, tree `{x['candidate']['tree']}`.
- Ordinary release SHA-256: `{x['candidate']['sha256']}`; committed rebuild is byte-identical.
- Baseline: `{x['baseline']['commit']}` from the [previous upload optimization](../2026-10-01-v08-send/README.md), including its existing read/write buffering.
- Same frozen harness, Xray-core v26.7.28 and sing-box 1.13.20 as that report. Complete compiler, source patches and executable identities are in [inputs](data/inputs.json).
- M3 Pro/macOS desktop SOCKS loopback; stock worker counts, verified 256 MiB per direction per flow, one/eight flows, rotating client order. All attempts and every repetition are retained. This is an interactive desktop, not an isolated CPU or device-energy measurement. Absolute numbers from different campaigns/dates are not interchangeable.

## Retained behavior and memory bounds

TCP emits at most four record fragments per poll and at most four local maximum payloads (below 32 KiB). The byte bound also handles a peer sending larger legal records, so the default adaptive relay cannot grow past 32 KiB on this read path. Already available bytes return immediately if the next record would block; no batching timer is introduced. UDP retains a whole datagram per read and never enables the read-ahead floor.

The existing ciphertext allocation gains a 16 KiB floor only after decoding 64 KiB of authenticated TCP payload in total. This threshold is cumulative over the connection, not a sustained-throughput detector. Growth occurs on a later socket read after consumed plaintext has been erased; the floor never requires reading 16 KiB before returning a complete record. Maximum accepted peer record sizes, authentication, nonce allocation and fail-closed behavior remain unchanged. No global pool or second plaintext buffer is introduced. Large legal peer records retain the pre-existing larger frame allowance.

## Five-repeat download confirmation

CPU means process CPU time for verified work, not instantaneous utilization. The harness CPU counter has 10 ms granularity. All samples, minima and maxima are in [control summaries](data/control-summary.json).

| Cipher / flows | CPU ms, baseline → combined | CPU change | MiB/s, baseline → combined | Speed change |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(rows)}

One-flow AES baseline throughput ranges 1457–1507 MiB/s; combined ranges 1590–1738. CPU is 210 ms in all five baseline repeats, versus 160–190 ms combined. The earlier three-way campaign gives a larger one-flow gain (1401.5 → 1742.5 MiB/s, 220 → 170 ms); the smaller independent confirmation is the headline result. Eight-flow AES throughput is essentially unchanged. Upload and duplex exploratory results are mixed/small and do not establish a general improvement.

The input-only variant has only small download changes and an eight-flow AES duplex slowdown in its first campaign. Output-only gains do not consistently repeat: single AES download is 1446.1 → 1503.3 MiB/s initially, but 1484.1 → 1476.1 in confirmation. Both complete standalone campaigns remain archived; selection is the combination, not a claim that every individual change wins.

## Short requests

Three paired repeats cover TCP request/response and UDP for both ciphers and flow counts. Typical latency medians differ by 0–3 µs. Tail changes are mixed:

| Case | p95 µs, baseline → combined | Change |
| --- | ---: | ---: |
{chr(10).join(latency)}

The initial ChaCha TCP eight-flow p95 increase prompted a separate five-repeat check: **{a:.0f} → {b:.0f} µs ({pct(a,b):+.1f}%)**. Both series, including every p99 and CPU value, remain in the summaries. These small desktop samples do not establish strict latency parity or a general latency improvement.

The first latency campaign stopped after three completed trials because the observer saw unrelated `xcodebuild` activity. All three are excluded from accepted performance results and archived under `latency-controls-rejected-1`; no protocol trial failed. The entire campaign was repeated after 30 consecutive compiler-free samples. No compilation overlaps accepted campaigns.

## Held memory

Each fresh client holds 0/32/128/512 verified connections, with five RSS samples at each point and three rotating repeats. `small-memory` exchanges 8 KiB in each direction per connection; `bulk-memory` exchanges 1 MiB. Numbers below are median settled RSS at 512 connections, in MiB.

| Exchange / cipher | Baseline | Output-only | Combined | Combined delta |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(memory)}

Combined bulk RSS rises about 12.3–12.4%, on top of earlier retained buffering costs already present in baseline `f930d10`. Short 8 KiB exchanges differ by less than 0.1 MiB. These are retained process-memory measurements after traffic, not a claim of zero allocation cost or a device memory acceptance result. The previous rejected 16-record receive variant remains excluded.

## Separate call census

Twelve injected-counter trials cover single-flow AES download on all four frozen versions, three repeats each. **Only counts are used**; instrumented CPU, timing and RSS are excluded from performance claims. The calibrated counter library is the one from the [preceding census](../2026-10-01-v08-census/README.md).

| Version | Receive calls (`recvfrom`) | Socket write-family calls |
| --- | ---: | ---: |
| baseline | 36,878 | 18,586 |
| input-only | 18,465 | 18,458 |
| output-only | 36,885 | 9,435 |
| combined | 18,464 | 9,309 |

`recv` forwards to `recvfrom`, and `send` to `sendto`; wrappers are not double-counted. These are libc entry counts, not a complete kernel syscall trace or a per-call CPU attribution. They establish that the combination roughly halves both read and write calls; the separate normal-release controls establish the speed/CPU effect.

## Fresh three-client comparison

All 270 VMess trials pass: AES, ChaCha and auto × upload/download/full-duplex/TCP latency/UDP × one/eight flows × three clients × three repeats. Rust has lower RSS in **{targets['rss']}/60** reference comparisons and meets **{targets['cpu']}/36** bulk CPU and **{targets['speed']}/36** bulk throughput point targets under the explicit 3% desktop allowance. Overall parity remains **{parity['parity']['status']}**. Point medians do not waive interval uncertainty, startup/tail deficits or device acceptance.

| AES traffic / flows | Rust CPU ms | Xray CPU ms | sing-box CPU ms | Rust MiB/s | Xray MiB/s | sing-box MiB/s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(reference)}

See [strict results](data/summary-strict.json) and [3% results with intervals](data/summary-mac-3pct.json). Earlier Trojan/SS2022 reports retain their original runtime identities; they are not relabeled as measurements of this runtime.

## Verification and remaining gates

139 protocol tests, 493 core library tests (two existing manual tests ignored), formatting/Clippy and ten Xray/sing-box carrier, routing/DNS/TUN, lifecycle and Xray Mux integration tests pass. New tests cover deferred read-ahead allocation, coalesced reads without fill waits, the authenticated TCP threshold/UDP exclusion and large peer records with bounded TCP output and intact UDP.

[Full exact-runtime CI](https://github.com/aimalygin/xray-rust/actions/runs/{ci['databaseId']}) and [SDK CI](https://github.com/aimalygin/xray-rust-mobile/actions/runs/{mobile['databaseId']}) {'pass' if ci_ok else 'are still in progress; final platform acceptance is pending'}. SDK `{sdk['commit']}` pins the measured core; canonical source and release metadata checks pass. ABI 1.8 and 0.8.0-rc.1 metadata are unchanged. Physical Apple acceptance remains deferred, Android hardware unavailable, and publication artifact locks unprepared. No release, device energy, WAN or TUN performance parity is claimed.

The archive contains **316 accepted normal paired trials**, **36 held-memory clients**, **12 diagnostic trials**, **270 fresh reference trials**, and the excluded latency attempt. Independent verification rehashes every member, reconstructs all summaries/selections, checks payload conservation and ties the release digest to the exact core/SDK CI identities. Generated connection credentials/configs and executables are excluded from the public archive.

```sh
python3 docs/benchmarks/results/2026-10-02-v08-download/data/verify.py \\
  --repo "$PWD" --report docs/benchmarks/results/2026-10-02-v08-download \\
  --rebuild target/v08-comparison-driver/release/xray-rust
```
'''
(R/'README.md').write_text(text)
print('Report written',targets)
