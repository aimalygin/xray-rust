#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
export CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=target/v08-comparison-driver
export XRAY_CLIENT_PROTOCOL_BINARY=/Users/antonmalygin/xray-rust/target/v08-io-final/bin/xray XRAY_CLIENT_PROTOCOL_REFERENCE=xray
cargo test --offline --locked -p xray-core-rs --test vmess_runtime_tests --test runtime_data_path_tests vmess_runtime_ -- --ignored --nocapture > target/v08-download-investigation/xray-interop.log 2>&1
cargo test --offline --locked -p xray-core-rs --test mux_runtime_tests -- --ignored --nocapture > target/v08-download-investigation/xray-mux.log 2>&1
export XRAY_CLIENT_PROTOCOL_BINARY=/Users/antonmalygin/xray-rust/target/v08-io-final/bin/singbox XRAY_CLIENT_PROTOCOL_REFERENCE=sing-box
cargo test --offline --locked -p xray-core-rs --test vmess_runtime_tests --test runtime_data_path_tests vmess_runtime_ -- --ignored --nocapture > target/v08-download-investigation/singbox-interop.log 2>&1
