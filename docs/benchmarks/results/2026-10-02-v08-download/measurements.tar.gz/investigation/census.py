#!/usr/bin/env python3
"""Separate libc call counts. Instrumented CPU/RSS/timings are not performance evidence."""
import copy, importlib.util, json, os, time
from pathlib import Path
ROOT=Path('/Users/antonmalygin/xray-rust'); BASE=ROOT/'target/v08-download-investigation'
spec=importlib.util.spec_from_file_location('comparison',ROOT/'scripts/run-v08-protocol-comparison.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
def main():
    for k in ['GOMAXPROCS','GOGC','GOMEMLIMIT','TOKIO_WORKER_THREADS','DYLD_INSERT_LIBRARIES','XRAY_CENSUS_MAP']:os.environ.pop(k,None)
    os.umask(0o077)
    paths={k:BASE/k for k in ['baseline','read16','four','combined']};reference=ROOT/'target/v08-io-final/bin/xray'
    harness=ROOT/'target/v08-census-investigation/census-harness';library=ROOT/'target/v08-census-investigation/libcensus.dylib'
    active=[*paths.values(),reference,harness]
    assert not c.ambient()['compiler_load_detected'] and not c.followup.inventory(active)
    c.device.verify_reference(reference)
    out=BASE/'libc';out.mkdir(exist_ok=False)
    cases=[x for x in c.cases(['vmess-aes128']) if x['traffic']=='download' and x['connections']==1]
    m={'diagnostic_only':True,'scope':__doc__,'repeats':3,'cases':cases,'versions':list(paths),'started_unix':time.time(),'file_hashes':{str(p):c.bench.sha(p) for p in [*active,library,Path(__file__).resolve()]},'runs':[]}
    try:
        for index,case in enumerate(cases):
            for repeat in range(1,4):
                order=list(paths);offset=(index+repeat-1)%len(order);order=order[offset:]+order[:offset]
                if repeat%2==0:order.reverse()
                with c.fixture(reference,out/f"{case['id']}-server-{repeat}",case['profile']) as (config,pid):
                    for version in order:
                        name=f"{case['id']}-{version}-{repeat}";dest=out/name
                        request={k:case[k] for k in ['path','traffic','connections','iterations','payload_size']}
                        request.update(binary=str(paths[version]),config=copy.deepcopy(config),output=str(dest),warmup=True,client_preface=True,client_env={'DYLD_INSERT_LIBRARIES':str(library),'XRAY_CENSUS_MAP':str(dest/'calls.map')})
                        req=out/(name+'.json');c.bench.save(req,request)
                        r=c.measured_execute([str(harness),'protocol-run',str(req)],out/(name+'.log'))
                        remaining=[s for s in c.followup.inventory(active) if int(s.split(None,1)[0])!=pid]
                        r.update(case=case['id'],version=version,repeat=repeat,output_relative=name,remaining_engine_processes=remaining,client_order=order);m['runs'].append(r);c.bench.save(out/'manifest.json',m)
                        print(name,r['returncode'],flush=True)
                        assert r['returncode']==0 and not remaining and not r['surviving_process_group'] and not r['ambient_cpu']['compiler_load_detected'] and not r['ambient_cpu']['observer_errors']
                        x=json.loads((dest/'result.json').read_text());assert x['status']=='pass' and x['diagnostic_only']
                        for snapshot in x['process_census'].values():assert 'error' not in snapshot['os'] and snapshot['interpose'][0]==0x58524159434e5331
                assert not c.followup.inventory(active)
        assert all(c.bench.sha(Path(p))==h for p,h in m['file_hashes'].items());m['status']='pass'
    except BaseException:
        m['status']='fail';raise
    finally:m['finished_unix']=time.time();c.bench.save(out/'manifest.json',m)
if __name__=='__main__':main()
