#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
export CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=target/v08-comparison-driver
cargo fmt --all
cargo test --locked --offline -p xray-proxy --lib > target/v08-download-investigation/combined-tests.log 2>&1
cargo build --locked --offline --release -p xray-cli > target/v08-download-investigation/combined-build.log 2>&1
cp target/v08-comparison-driver/release/xray-rust target/v08-download-investigation/combined
git diff --binary > target/v08-download-investigation/combined.patch
shasum -a 256 target/v08-download-investigation/combined
