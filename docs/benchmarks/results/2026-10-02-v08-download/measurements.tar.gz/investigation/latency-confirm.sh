#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
python3 scripts/run-v08-cpu-controls.py --binary baseline=target/v08-download-investigation/baseline --binary combined=target/v08-download-investigation/combined --reference target/v08-io-final/bin/xray --harness target/v08-io-final/bin/harness --profile vmess-chacha20 --traffic tcp-latency --flows 8 --repeats 5 --output target/v08-download-investigation/latency-confirmation > target/v08-download-investigation/latency-confirmation.log 2>&1
