#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
python3 scripts/run-v08-cpu-controls.py --binary baseline=target/v08-download-investigation/baseline --binary four=target/v08-download-investigation/four --binary combined=target/v08-download-investigation/combined --reference target/v08-io-final/bin/xray --harness target/v08-io-final/bin/harness --profile vmess-aes128 --profile vmess-chacha20 --traffic download --repeats 5 --output target/v08-download-investigation/confirmation > target/v08-download-investigation/confirmation.log 2>&1
python3 target/v08-download-investigation/census.py > target/v08-download-investigation/libc.log 2>&1
python3 target/v08-download-investigation/census-summary.py target/v08-download-investigation/libc target/v08-download-investigation/libc-summary.json
bash target/v08-download-investigation/memory.sh
