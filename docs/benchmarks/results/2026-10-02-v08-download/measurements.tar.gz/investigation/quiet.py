import importlib.util,json,time
from pathlib import Path
root=Path('/Users/antonmalygin/xray-rust');p=root/'scripts/run-v08-protocol-comparison.py'
s=importlib.util.spec_from_file_location('comparison',p);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
samples=[];clean=0;deadline=time.monotonic()+600
while clean<30:
 x=c.ambient();samples.append({'unix':time.time(),**x});clean=0 if x['compiler_load_detected'] else clean+1
 (root/'target/v08-download-investigation/quiet-observation.json').write_text(json.dumps(samples,indent=2)+'\n')
 if time.monotonic()>deadline:raise RuntimeError('compiler did not become quiet within ten minutes')
 time.sleep(1)
print('Thirty consecutive compiler-free samples',flush=True)
