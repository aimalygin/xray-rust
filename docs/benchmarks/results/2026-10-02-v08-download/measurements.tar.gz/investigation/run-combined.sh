#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
python3 scripts/run-v08-cpu-controls.py --binary baseline=target/v08-download-investigation/baseline --binary four=target/v08-download-investigation/four --binary combined=target/v08-download-investigation/combined --reference target/v08-io-final/bin/xray --harness target/v08-io-final/bin/harness --profile vmess-aes128 --repeats 3 --output target/v08-download-investigation/combined-controls > target/v08-download-investigation/combined-controls.log 2>&1
python3 target/v08-download-investigation/summarize.py target/v08-download-investigation target/v08-download-investigation/combined-summary.json controls:combined-controls
