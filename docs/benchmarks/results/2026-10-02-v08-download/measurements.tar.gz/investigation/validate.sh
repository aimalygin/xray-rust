#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
export CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=target/v08-comparison-driver
cargo fmt --all -- --check
cargo test --locked --offline -p xray-proxy --all-targets > target/v08-download-investigation/proxy-tests.log 2>&1
cargo test --locked --offline -p xray-core-rs --lib > target/v08-download-investigation/core-tests.log 2>&1
cargo clippy --locked --offline -p xray-proxy --all-targets -- -D warnings -W clippy::perf -W clippy::suspicious > target/v08-download-investigation/clippy.log 2>&1
bash target/v08-download-investigation/interop.sh
