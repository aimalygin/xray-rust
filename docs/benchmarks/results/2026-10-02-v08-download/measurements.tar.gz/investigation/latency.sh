#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
python3 scripts/run-v08-cpu-controls.py --binary baseline=target/v08-download-investigation/baseline --binary combined=target/v08-download-investigation/combined --reference target/v08-io-final/bin/xray --harness target/v08-io-final/bin/harness --profile vmess-aes128 --profile vmess-chacha20 --traffic tcp-latency --traffic udp --repeats 3 --output target/v08-download-investigation/latency-controls > target/v08-download-investigation/latency-controls.log 2>&1
