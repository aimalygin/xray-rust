#!/usr/bin/env python3
"""Diagnostic sample stacks only: these instrumented trials are NOT timing evidence."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import threading
import time

root=Path('/Users/antonmalygin/xray-rust')
spec=importlib.util.spec_from_file_location('control',root/'scripts/run-v08-cpu-controls.py')
control=importlib.util.module_from_spec(spec);spec.loader.exec_module(control)
original=control.c.measured_execute
original_cases=control.c.cases
def long_cases(*args,**kwargs):
    result=original_cases(*args,**kwargs)
    for case in result: case['iterations']=6000
    return result
control.c.cases=long_cases
baseline=str(root/'target/v08-batch-investigation/profile-baseline')

def profile(args,log):
    stop=threading.Event();samplers=[];seen=set()
    def observe():
        while not stop.is_set():
            lines=subprocess.check_output(['ps','-axo','pid=,args='],text=True).splitlines()
            for line in lines:
                fields=line.strip().split(None,1)
                if len(fields)!=2 or not fields[1].startswith(baseline+' run '):continue
                pid=int(fields[0])
                if pid in seen:continue
                seen.add(pid)
                output=log.with_suffix('.sample.txt')
                with log.with_suffix('.sample.log').open('w') as stream:
                    samplers.append(subprocess.Popen(['/usr/bin/sample',str(pid),'1','1','-mayDie','-file',str(output)],stdout=stream,stderr=stream))
            stop.wait(.02)
    thread=threading.Thread(target=observe);thread.start()
    try:
        result=original(args,log)
    finally:
        stop.set();thread.join()
        for process in samplers:
            try:process.wait(10)
            except subprocess.TimeoutExpired:process.terminate();process.wait()
    result['profiling_only']=True
    result['sampled_pids']=sorted(seen)
    return result

control.c.measured_execute=profile
sys.argv=[__file__,'--binary','baseline='+baseline,
          '--reference',str(root/'target/v08-io-final/bin/xray'),
          '--harness',str(root/'target/v08-io-final/bin/harness'),
          '--output',str(root/'target/v08-batch-investigation/profile-bounded'),
          '--profile','vmess-aes128','--flows','1','--repeats','3']
control.main()
