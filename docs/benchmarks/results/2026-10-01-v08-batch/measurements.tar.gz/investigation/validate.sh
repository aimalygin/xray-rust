#!/usr/bin/env bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
export CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=target/v08-comparison-driver
cargo fmt --all --check
cargo test --offline --locked -p xray-proxy --all-targets > target/v08-batch-investigation/final-proxy-tests.log 2>&1
cargo test --offline --locked -p xray-core-rs --lib > target/v08-batch-investigation/final-core-tests.log 2>&1
cargo clippy --offline --locked -p xray-proxy --all-targets -- -D warnings -W clippy::perf -W clippy::suspicious > target/v08-batch-investigation/final-clippy.log 2>&1
export XRAY_CLIENT_PROTOCOL_BINARY=/Users/antonmalygin/xray-rust/target/v08-io-final/bin/xray
cargo test --offline --locked -p xray-core-rs --test vmess_runtime_tests --test runtime_data_path_tests vmess_runtime_ -- --ignored --nocapture > target/v08-batch-investigation/xray-interop.log 2>&1
cargo test --offline --locked -p xray-core-rs --test mux_runtime_tests -- --ignored --nocapture > target/v08-batch-investigation/xray-mux.log 2>&1
export XRAY_CLIENT_PROTOCOL_BINARY=/Users/antonmalygin/xray-rust/target/v08-io-final/bin/singbox XRAY_CLIENT_PROTOCOL_REFERENCE=sing-box
cargo test --offline --locked -p xray-core-rs --test vmess_runtime_tests --test runtime_data_path_tests vmess_runtime_ -- --ignored --nocapture > target/v08-batch-investigation/singbox-interop.log 2>&1
cargo build --offline --locked --release -p xray-cli > target/v08-batch-investigation/committed-rebuild.log 2>&1
cmp target/v08-comparison-driver/release/xray-rust target/v08-batch-investigation/batch2
