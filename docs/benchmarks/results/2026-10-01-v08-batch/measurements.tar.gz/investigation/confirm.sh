#!/usr/bin/env bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
common=(--binary baseline=target/v08-batch-investigation/baseline --binary batch2=target/v08-batch-investigation/batch2 --reference target/v08-io-final/bin/xray --profile vmess-aes128 --profile vmess-chacha20)
python3 target/v08-batch-investigation/held-memory.py --repo /Users/antonmalygin/xray-rust "${common[@]}" --warmup-bytes 8192 --output target/v08-batch-investigation/small-held-memory > target/v08-batch-investigation/small-held-memory.log 2>&1
python3 target/v08-batch-investigation/held-memory.py --repo /Users/antonmalygin/xray-rust "${common[@]}" --warmup-bytes 1048576 --output target/v08-batch-investigation/bulk-held-memory > target/v08-batch-investigation/bulk-held-memory.log 2>&1
python3 scripts/run-v08-cpu-controls.py "${common[@]}" --harness target/v08-io-final/bin/harness --repeats 3 --traffic tcp-latency --traffic udp --output target/v08-batch-investigation/latency-controls > target/v08-batch-investigation/latency-controls.log 2>&1
python3 scripts/run-v08-cpu-controls.py "${common[@]}" --harness target/v08-io-final/bin/harness --repeats 5 --case-id vmess-aes128-socks-upload-1 --case-id vmess-aes128-socks-upload-8 --case-id vmess-aes128-socks-download-1 --case-id vmess-aes128-socks-download-8 --case-id vmess-chacha20-socks-upload-1 --case-id vmess-chacha20-socks-upload-8 --output target/v08-batch-investigation/confirmation-controls > target/v08-batch-investigation/confirmation-controls.log 2>&1
