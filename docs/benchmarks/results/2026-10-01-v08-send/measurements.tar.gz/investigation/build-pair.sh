#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
export CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=target/v08-comparison-driver
cargo fmt --all
cargo test --locked --offline -p xray-proxy --all-targets > target/v08-send-investigation/pair-tests.log 2>&1
cargo test --locked --offline -p xray-core-rs --lib > target/v08-send-investigation/core-tests.log 2>&1
cargo clippy --locked --offline -p xray-proxy --all-targets -- -D warnings -W clippy::perf -W clippy::suspicious > target/v08-send-investigation/clippy.log 2>&1
cargo build --locked --offline --release -p xray-cli > target/v08-send-investigation/pair-build.log 2>&1
cp target/v08-comparison-driver/release/xray-rust target/v08-send-investigation/pair
shasum -a 256 target/v08-send-investigation/pair
git diff --binary > target/v08-send-investigation/pair.patch
