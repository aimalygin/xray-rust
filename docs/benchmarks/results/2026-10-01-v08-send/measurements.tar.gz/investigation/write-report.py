#!/usr/bin/env python3
"""Render claims from validated medians, while retaining complete raw evidence."""
import json
from pathlib import Path
ROOT=Path('/Users/antonmalygin/xray-rust');BASE=ROOT/'target/v08-send-investigation';REPORT=ROOT/'docs/benchmarks/results/2026-10-01-v08-send'
def read(p):return json.loads(p.read_text())
s=read(REPORT/'data/control-summary.json');i=read(REPORT/'data/inputs.json');d=read(REPORT/'data/libc-summary.json')
def metric(group,case,version,key):return next(r for r in s[group] if r['case']==case and r['version']==version)['metrics'][key]['median']
def pct(a,b):return 100*(b/a-1)
lines=['# Bounded VMess writes and Apple padding CSPRNG — Apple M3 Pro','',
'Combining two full VMess records per send with Apple’s system padding CSPRNG reduces upload CPU in repeated ordinary-release controls. The write buffer remains bounded at 16 KiB and grows to that size only when a caller supplies two full records. Short transfers retain the single-record allocation. The extra retained RSS after large transfers is measured below; this is not a zero-memory-cost optimization.','',
'## Identity and method','',f"Baseline runtime `{i['baseline']['commit']}`; candidate runtime `{i['candidate']['commit']}`, tree `{i['candidate']['tree']}`. Candidate release SHA-256 `{i['candidate']['sha256']}`. The committed release rebuild is byte-identical to the frozen measured candidate. All binaries use normal release optimization and stock workers.",'',
'Xray-core v26.7.28 and sing-box 1.13.20 retain the pinned executables and common harness from the preceding reports. Exact commits, hashes, build flags and compiler versions are in [inputs](data/inputs.json) and [builds](data/builds.json). This is desktop SOCKS loopback on M3 Pro/macOS 26.6.2, with a common fresh Xray fixture. Each bulk flow verifies 256 MiB per direction, with one or eight flows. Variant/client order rotates between repeated fresh processes.','',
'All 214 accepted paired normal-release trials, 24 held-memory clients, 270 fresh three-client VMess trials and 12 separate diagnostic trials pass. Timing campaigns do not overlap local compilation or diagnostic instrumentation. Two initial short-transfer memory campaigns were interrupted by observed `ANECompilerService` activity and are excluded in full. Their completed/partial measurements and failure logs remain archived; the replacement campaign ran after a quiet interval. The whole-case reference collector retains any rejected attempts and its selection decisions.','',
'## What changed','',
'- On Apple targets only, AES public body padding calls `arc4random_buf`, the system CSPRNG also used by the pinned Go runtime. Empty requests are skipped for older Apple OS compatibility. Session keys, IVs, request authentication, nonce allocation and header randomness retain the existing path. Non-Apple AES padding and the measured ChaCha entropy cache are unchanged. No application RNG state or new buffer is added per connection for this change.',
'- TCP writes accept at most two full records from the caller’s available data. The ciphertext shares one bounded allocation and is sent together; each record keeps its own nonce, masked/authenticated length and AEAD tag. Plaintext is encrypted in place after reserving the complete bound. A short request progresses immediately. Partial socket writes resume without accepting more plaintext or duplicating bytes. Any encoding failure clears pending data and poisons the stream. UDP remains one datagram per write.',
'- The earlier two-record receive limit remains unchanged. Maximum individual wire-record size remains 8 KiB; pending TCP ciphertext may now retain 16 KiB after bulk writes.','',
'## Paired upload confirmation','',
'Medians of five independent repeats, after the exploratory three-repeat campaigns. CPU is process time for the verified workload, not instantaneous CPU utilization. All samples and ranges, including conflicting exploratory points, are in [control summaries](data/control-summary.json).','',
'| Cipher / flows | Baseline CPU ms | Candidate CPU ms | CPU change | Baseline MiB/s | Candidate MiB/s | Speed change |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for cipher in ['aes128','chacha20']:
 for flows in [1,8]:
  case=f'vmess-{cipher}-socks-upload-{flows}';a=metric('confirmation',case,'baseline','cpu_ms');b=metric('confirmation',case,'pair','cpu_ms');u=metric('confirmation',case,'baseline','throughput_mib_s');v=metric('confirmation',case,'pair','throughput_mib_s')
  lines.append(f'| {cipher} / {flows} | {a:.0f} | {b:.0f} | {pct(a,b):+.1f}% | {u:.1f} | {v:.1f} | {pct(u,v):+.1f}% |')
lines += ['', 'The standalone Apple padding change is not a stable eight-flow optimization: its first campaign improves AES upload CPU from 1,340 to 1,210 ms and speed from 3,026.8 to 3,253.3 MiB/s, but the subsequent three-way campaign regresses to 1,470 ms / 2,286.4 MiB/s versus the simultaneous baseline’s 1,350 ms / 3,027.9 MiB/s. Both sets are retained. Only the combined implementation is selected, based on its repeated controls; fewer entropy calls alone do not establish a speed benefit.', '',
'The three-way combined AES campaign improves one-flow full-duplex CPU 400 → 330 ms and throughput 1,649.0 → 2,015.6 MiB/s; eight-flow full-duplex improves CPU 2,870 → 2,640 ms, with a smaller speed gain. Download medians are near the baseline. ChaCha has no padding-source change; its separate controls isolate the bounded write batching effect, with lower upload/full-duplex CPU and little download change. These small desktop series do not promise the same percentage across hosts or workloads.','',
'## Retained memory at 512 connections','',
'Each fresh client holds 0/32/128/512 payload-verified connections. Every connection exchanges the stated payload in each direction before five settled RSS samples. Medians below cover three rotating repeats; all sizes, sample times and ranges are archived.','',
'| Cipher | Exchange per direction | Baseline RSS MiB | Candidate RSS MiB | Difference MiB | Difference |','| --- | --- | ---: | ---: | ---: | ---: |']
for group,label in [('small-memory','8 KiB'),('bulk-memory','1 MiB')]:
 for cipher in ['aes128','chacha20']:
  def rss(version):return next(r for r in s[group] if r['profile']=='vmess-'+cipher and r['version']==version and r['connections']==512)['rss_mib']['median']
  a=rss('baseline');b=rss('pair');lines.append(f'| {cipher} | {label} | {a:.2f} | {b:.2f} | {b-a:+.2f} | {pct(a,b):+.1f}% |')
lines += ['','These deltas are relative to runtime `1804e17`, which already includes the retained two-record receive batch. They are additional to that earlier optimization’s documented memory cost. The 16-record buffering variant rejected in the previous investigation is not reinstated.','',
'## Separate call census','',
'Twelve trials interpose libc calls on the frozen baseline and candidate, for AES upload at one/eight flows and three repeats. Only call/byte counts are used here; every instrumented timing, CPU and RSS value is excluded from performance claims. Calibration and coverage limits are documented in the [preceding census](../2026-10-01-v08-census/README.md). `send` forwards to `sendto`; the table counts only the lower layer to avoid double-counting. These are library entry counts, not a complete kernel syscall trace.','',
'| Flows | Version | Write calls | Mean KiB per call | getentropy calls | arc4random_buf calls |','| --- | --- | ---: | ---: | ---: | ---: |']
for row in d:
 m=row['metrics'];v=lambda k:m[k]['median'];lines.append(f"| {row['case'].rsplit('-',1)[1]} | {row['version']} | {v('deduplicated_write_calls'):,.0f} | {v('mean_write_bytes')/1024:.2f} | {v('getentropy_calls'):,.0f} | {v('arc4random_buf_calls'):,.0f} |")
lines += ['','The count changes verify the intended mechanism, while the separate normal-release controls establish the measured CPU/speed effect. This is not evidence that Go has no syscalls, nor an attribution of a fixed CPU percentage to a particular call family.','',
'## Fresh Xray-core / sing-box comparison','',
'All 270 trials cover AES, ChaCha and auto; upload, download, full-duplex, TCP latency and UDP; one/eight flows; three clients and three rotating repeats. The exact point ratios and strict/3% desktop-allowance judgments are in [comparison data](data/summary-mac-3pct.json). Earlier Trojan/SS2022 comparisons remain tied to their own runtime identities; they are not relabeled as measurements of this candidate.','',
'## Validation and remaining scope','',
'136 protocol tests, 493 core library tests, formatting, Clippy and ten local Xray/sing-box carrier, TUN/DNS/lifecycle and Xray Mux integration tests pass. Tests cover both ciphers/length encodings, record boundaries within a write pair, partial writes, short allocations, UDP, nonce exhaustion within a pair and authenticated termination. The initial sandboxed core test run could not bind sockets; its failure log and the successful unrestricted rerun are both retained.','',
'Candidate-bound CI and the SDK pin are recorded with exact identities in this report’s data. Physical Apple acceptance remains deferred by the owner and Android hardware is unavailable. Host results do not establish phone energy, WAN or TUN performance, or publication-artifact acceptance. Both PRs remain drafts.','',
'## Evidence','',
'[Archive](measurements.tar.gz), [member checksums](evidence-index.json), [independent verification](data/verification.json). The verifier reconstructs complete matrices, byte counts, case selection, all numeric summaries and libc counts from archived results, and checks the release hash and exact core/SDK CI identities. Generated connection credentials/configurations and executables remain local.','']
latency=['## Short-request controls','',
'Three fresh paired repeats cover TCP request/response and UDP at one/eight flows for both ciphers. This checks short-message effects separately from bulk transfer. CPU snapshots have 10 ms granularity; very short runs should not be interpreted as precise zero-cost results. All median/p95/p99 samples are retained in the control data.','',
'| Cipher / traffic / flows | Baseline p95 µs | Candidate p95 µs | Change | Baseline CPU ms | Candidate CPU ms |','| --- | ---: | ---: | ---: | ---: | ---: |']
for row in s['latency-controls']:
 if row['version']!='baseline':continue
 case=row['case'];a=row['metrics']['latency_p95_us']['median'];b=metric('latency-controls',case,'pair','latency_p95_us');u=row['metrics']['cpu_ms']['median'];v=metric('latency-controls',case,'pair','cpu_ms')
 latency.append(f"| {case.removeprefix('vmess-').replace('-socks-', ' / ')} | {a:.0f} | {b:.0f} | {pct(a,b):+.1f}% | {u:.0f} | {v:.0f} |")
latency += ['', 'Typical latency medians differ by only 0–2 µs. P95 changes are mixed (−14.5% to +7.3%) and the three-repeat ranges overlap in every case. The worse point estimates remain visible; no general latency improvement or strict latency non-regression is claimed.', '']
index=lines.index('## Retained memory at 512 connections');lines[index:index]=latency
comparison=read(REPORT/'data/summary-mac-3pct.json')
bulk=[r for r in comparison['rows'] if any('-socks-'+kind+'-' in r['case'] for kind in ['upload','download','full-duplex'])]
counts={key:sum(c['metrics'][key]['meets_point_target'] for row in bulk for c in row['comparisons'].values()) for key in ['cpu_ms','throughput_mib_s']}
rss=sum(c['metrics']['rss_mib']['meets_point_target'] for row in comparison['rows'] for c in row['comparisons'].values())
extra=[f"Rust uses lower RSS in **{rss}/60** reference comparisons, and meets **{counts['cpu_ms']}/36** bulk CPU and **{counts['throughput_mib_s']}/36** bulk speed point targets with the explicit 3% desktop allowance. Overall parity is **{comparison['parity']['status']}**; point medians alone do not waive uncertainty or remaining latency/startup deficits.",'',
'Fresh AES bulk medians (same candidate; not the paired-control baseline campaign):','',
'| Traffic / flows | Rust CPU ms | Xray CPU ms | sing-box CPU ms | Rust MiB/s | Xray MiB/s | sing-box MiB/s |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for row in bulk:
 if not row['case'].startswith('vmess-aes128-'):continue
 v=row['versions'];values=[v[client]['metrics'][key]['median'] for key in ['cpu_ms','throughput_mib_s'] for client in ['candidate','xray','singbox']]
 extra.append('| '+row['case'].split('-socks-',1)[1]+' | '+' | '.join(f'{value:.1f}' for value in values)+' |')
extra += ['','The remaining deficits are workload-specific: consult all cases and intervals in the JSON rather than extrapolating upload improvements to download or declaring universal parity.','']
index=lines.index('## Validation and remaining scope');lines[index:index]=extra
ci=read(BASE/'ci-run.json');sdk_ci=read(BASE/'mobile-ci-run.json');sdk=read(BASE/'mobile-identity.json')
index=lines.index('## Evidence')
lines[index:index]=[f"[Full core CI]({ci['url']}) at `{ci['headSha']}`: **{ci['conclusion'] or ci['status']}**. [SDK CI]({sdk_ci['url']}) at `{sdk['commit']}`: **{sdk_ci['conclusion'] or sdk_ci['status']}**. SDK core metadata pins the measured runtime; canonical adapters match it. ABI/version and unprepared artifact locks are unchanged.",'']
if not (REPORT/'data/verification.json').exists():
 lines=[line.replace('data/verification.json', 'data/verification-evidence.json') for line in lines]
(REPORT/'README.md').write_text('\n'.join(lines))
