#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
common=(--repo /Users/antonmalygin/xray-rust --binary baseline=target/v08-send-investigation/baseline --binary pair=target/v08-send-investigation/pair --reference target/v08-io-final/bin/xray --profile vmess-aes128 --profile vmess-chacha20)
python3 target/v08-batch-investigation/held-memory.py "${common[@]}" --warmup-bytes 8192 --output target/v08-send-investigation/small-memory > target/v08-send-investigation/small-memory.log 2>&1
python3 target/v08-batch-investigation/held-memory.py "${common[@]}" --warmup-bytes 1048576 --output target/v08-send-investigation/bulk-memory > target/v08-send-investigation/bulk-memory.log 2>&1
