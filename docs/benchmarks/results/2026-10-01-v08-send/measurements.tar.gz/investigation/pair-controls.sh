#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
python3 scripts/run-v08-cpu-controls.py --binary baseline=target/v08-send-investigation/baseline --binary arc=target/v08-send-investigation/arc --binary pair=target/v08-send-investigation/pair --reference target/v08-io-final/bin/xray --harness target/v08-io-final/bin/harness --profile vmess-aes128 --repeats 3 --output target/v08-send-investigation/pair-controls > target/v08-send-investigation/pair-controls.log 2>&1
python3 scripts/run-v08-cpu-controls.py --binary baseline=target/v08-send-investigation/baseline --binary pair=target/v08-send-investigation/pair --reference target/v08-io-final/bin/xray --harness target/v08-io-final/bin/harness --profile vmess-chacha20 --repeats 3 --output target/v08-send-investigation/chacha-controls > target/v08-send-investigation/chacha-controls.log 2>&1
