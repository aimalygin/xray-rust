#!/bin/bash
set -euo pipefail
cd /Users/antonmalygin/xray-rust
bash target/v08-send-investigation/memory.sh
python3 scripts/run-v08-cpu-controls.py --binary baseline=target/v08-send-investigation/baseline --binary pair=target/v08-send-investigation/pair --reference target/v08-io-final/bin/xray --harness target/v08-io-final/bin/harness --profile vmess-aes128 --profile vmess-chacha20 --traffic upload --repeats 5 --output target/v08-send-investigation/confirmation > target/v08-send-investigation/confirmation.log 2>&1
python3 target/v08-send-investigation/census.py > target/v08-send-investigation/libc.log 2>&1
