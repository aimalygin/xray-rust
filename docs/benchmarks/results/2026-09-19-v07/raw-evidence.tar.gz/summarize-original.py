from pathlib import Path
import json, statistics, hashlib
root=Path('/private/tmp/xray-v07-bench-20260919')
versions=['baseline','candidate']
rows={}
artifacts={}
def add(key,unit,version,values,budget=None):
 assert len(values)==5,(key,len(values))
 row=rows.setdefault(key,{'id':key,'unit':unit,'versions':{}})
 row['versions'][version]={'samples':values,'median':statistics.median(values),'min':min(values),'max':max(values)}
 if budget:row['maximum']=budget
for version in versions:
 p=root/'evidence'/f'{version}-regression'
 for group in ['route','dns','phase2']:
  docs=[json.loads(x.read_text()) for x in sorted(p.glob(f'{group}-*/**/result.json'))]
  assert len(docs)==5,(version,group,len(docs))
  if group=='route':add('route','ns',version,[x['avg_ns'] for x in docs],500)
  elif group=='dns':
   for key in ['last_hit_avg_ns','semantic_miss_avg_ns']:
    add('dns-selector-'+key,'ns',version,[next(y for y in x['outbound_selector_prefilter'] if y['rules']==4096)[key] for x in docs],30000)
  else:
   add('phase2-rss','KiB',version,[x['peak_rss_kib'] for x in docs],10240)
   for key,budget in {'round_robin_selection':200,'chain_selection':600,'override_switch':250,'selection_snapshot':3000,'health_snapshot':3500,'dns_cache_hit':300,'connection_snapshot':5000,'accounting_snapshot':100,'connection_close':4000,'diagnostic_queue_round_trip':150,'tun_stats_snapshot':50}.items():
    add(key,'ns',version,[x[key]['avg_ns'] for x in docs],budget)
 for group,budget in [('idle',5120),('flows-100',7500),('flows-1000',25000),('tcp',None),('tun-fd',8192)]:
  files=list((p/f'process-{group}').rglob('result.json'));docs=[json.loads(x.read_text()) for x in files]
  assert len(docs)==5
  for key,unit in [('peak_rss_kib','KiB'),('cpu_millis','ms')]:
   add(group+'-'+key,unit,version,[x[key] for x in docs],budget if key=='peak_rss_kib' else None)
  if group in ['tcp','tun-fd']:
   add(group+'-latency','us',version,[x['latency_us']['median'] for x in docs],55 if group=='tcp' else None)
 feature=json.loads((root/'evidence'/f'{version}-features/performance.json').read_text())
 for x in feature['measurements']:
  add('v06-'+x['id'],x['unit'],version,x['samples'])
 for folder in [p,root/'evidence'/f'{version}-features']:
  for file in folder.rglob('*'):
   if file.is_file():artifacts[str(file.relative_to(root/'evidence'))]=hashlib.sha256(file.read_bytes()).hexdigest()
for row in rows.values():
 b,c=[row['versions'][v]['median'] for v in versions]
 row['candidate_baseline_ratio']=c/b if b else None
 row['candidate_budget_failed']=bool(row.get('maximum') and c>row['maximum'])
result={'baseline_commit':'ed5258a3a589c2a1f9330142f37c8f3d28a640fa','candidate_commit':'7f87ffe7eaf4ed088a45172d2468df956f26550b','repeats':5,'rows':list(rows.values()),'artifact_sha256':artifacts}
(root/'evidence/original-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for row in rows.values():
 ratio=row['candidate_baseline_ratio']
 if row['candidate_budget_failed'] or ratio and ratio>1.15:
  print(row['id'],row['versions']['baseline']['median'],row['versions']['candidate']['median'],round(ratio,2),'budget failed' if row['candidate_budget_failed'] else '')
