from pathlib import Path
import json, shutil, hashlib, tarfile
root=Path('/private/tmp/xray-v07-bench-20260919')
report=root/'harness/docs/benchmarks/results/2026-09-19-v07'
report.mkdir(parents=True,exist_ok=True)
data=report/'data';data.mkdir(exist_ok=True)
for name in ['original-summary.json']:
 shutil.copy2(root/'evidence'/name,data/name)
shutil.copy2(root/'host-build.json',data/'host-build.json')
shutil.copy2(root/'benchmark-source.patch',report/'benchmark-source.patch')
for _,_,_,name in json.loads((root/'diagnostic-plan.json').read_text()):
 assert (root/'evidence'/name/'summary.json').exists(), f'missing planned diagnostic: {name}'
original=json.loads((data/'original-summary.json').read_text())
byid={r['id']:r for r in original['rows']}
lines=['# v0.7 development performance verification — 2026-09-19','',
'**The candidate fails the unchanged historical memory budgets and has repeatable WireGuard load-completion failures and an XHTTP H1 TUN throughput regression.** This campaign does not establish a regression-free RC. Both old release gates and clean transport/protocol measurements are retained. Earlier transport/protocol collections were invalidated after a driver child-process leak was discovered and are excluded from conclusions.','',
'- Baseline: tag `v0.6.1`, commit `ed5258a3a589c2a1f9330142f37c8f3d28a640fa`.',
'- Candidate: v0.7 development commit `7f87ffe7eaf4ed088a45172d2468df956f26550b` (Cargo package version remains `0.6.1`).',
'- Reference: clean Xray-core `v26.7.28`, commit `5ca6f4b7d4dc20a881d4330e498892697627ec0c`.',
'- Same Apple M3 Pro host, 12 logical CPUs, 18 GiB RAM; Rust 1.96.0; release, thin LTO, one codegen unit. Exact [host/build identity](data/host-build.json).',
'- Immutable external client binaries, serial measurements, five fresh-process repeats. Baseline/candidate order alternates in paired matrices. [Method and reproduction commands](../../../v07-performance.md).','',
'## Historical release gates','',
'Original v0.5 pre-device and v0.6 feature scripts ran from each clean source checkout. Their thresholds were not changed. v0.6.1 passes both gates; the candidate passes v0.6 features but fails v0.5 memory limits. The validator stops at its first budget failure; independent inspection of all completed raw results also finds the 1000-flow failure.','',
'| Measurement (median of five) | v0.6.1 | v0.7 candidate | Change | Existing maximum |',
'| --- | ---: | ---: | ---: | ---: |']
for key in ['idle-peak_rss_kib','flows-100-peak_rss_kib','flows-100-cpu_millis','flows-1000-peak_rss_kib','tcp-latency','tun-fd-peak_rss_kib','tun-fd-cpu_millis','tun-fd-latency','connection_close','v06-process-throughput','v06-vless-encryption-throughput','v06-ip-on-demand-latency','v06-xhttp-memory']:
 r=byid[key];b,c=[r['versions'][v]['median'] for v in ['baseline','candidate']]
 lines.append(f"| {key} ({r['unit']}) | {b:,.3f} | {c:,.3f} | {(c/b-1)*100:+.1f}% | {r.get('maximum') if r.get('maximum') is not None else '—'} |")
lines+=['','Full sample ranges, every original gate metric and original artifact hashes: [original-summary.json](data/original-summary.json). The connection-close probe remains under its 4000 ns budget despite a roughly threefold slowdown. TUN CPU time rose from 130 to 320 ms on the unchanged echo workload; its latency changed much less. These findings require investigation, not relaxed limits. The 100-flow CPU median changed from 10 to 20 ms, a single timing-quantization step; this short sample alone does not establish a doubled sustained CPU cost.','',
'## Completed matrices','',
'| Suite | Cases | Scheduled runs | Failed runs | Evidence |','| --- | ---: | ---: | ---: | --- |']
summaries={}
for suite in ['legacy','tun','new','reality']:
 folder=root/'evidence'/f'{suite}-clean'
 manifest=json.loads((folder/'manifest.json').read_text())
 summary=json.loads((folder/'summary.json').read_text())
 assert manifest.get('finished_unix') and len(manifest['runs'])==len(manifest['cases'])*len(manifest['versions'])*manifest['repeats']
 assert not manifest['preflight_campaign_processes']
 assert all(r['process_group_empty_after_run'] and not r['remaining_engine_processes'] and not r['surviving_process_group'] for r in manifest['runs'])
 shutil.copy2(folder/'manifest.json',data/f'{suite}-manifest.json')
 shutil.copy2(folder/'summary.json',data/f'{suite}-summary.json')
 summaries[suite]=summary
 lines.append(f"| {suite} | {len(manifest['cases'])} | {len(manifest['runs'])} | {len(summary['failures'])} | [manifest](data/{suite}-manifest.json), [summary](data/{suite}-summary.json) |")
lines += ['', '### Main observations', '',
'- Hysteria2 passed all 100 clean measured runs. WireGuard passed 83/100: SOCKS upload/eight flows and full-duplex/eight flows completed 0/5 each; TUN upload/eight flows completed 2/5, and TUN full-duplex/eight flows completed 1/5. All 17 failed runs exceeded the unchanged 120-second driver limit. The other WireGuard groups passed.',
'- All 300 paired TUN runs completed. The four screened cases are VLESS/TLS single-flow upload/full-duplex CPU and XHTTP H1 single-flow download/full-duplex throughput. The H1 short full-duplex medians are about 41.66 → 7.33 MiB/s; all five candidate samples show the slowdown. The larger-volume diagnostic confirmed the drop: 57.58 → 8.73 MiB/s, about 85% lower.',
'- The additional REALITY/Vision matrix completed 119/120 runs: candidate SOCKS full-duplex/eight flows, repeat one, returned early EOF before the completion marker. The group receives no passing median; an independent five-pair repeat completed successfully. No completed REALITY group crossed the 15% screen.',
'- Clean Freedom TUN full-duplex comparisons did not reproduce the preliminary slowdown; its median throughput ratios were about 1.00× and 1.02× for one/eight flows. Neither XHTTP H2 nor H3 TUN crossed the screening threshold.']
if not summaries['legacy']['failures'] and not any(r['review'] for r in summaries['legacy']['rows']):
 lines += ['- The historical transport matrix completed all 370 paired measured runs, with no failed run and no case crossing the 15% screen. This is bounded evidence for the listed workloads, not a general proof of no regression.']
lines+=['','Legacy uses the original per-version harness: REALITY/Vision bulk plus WebSocket, HTTPUpgrade, gRPC and XHTTP H1/H2/H3. TUN adds Freedom, VLESS/TLS and XHTTP through a common fd-backed driver. The additional REALITY/Vision matrix covers SOCKS and TUN, one/eight flows, upload/download/full-duplex. New protocols cover Hysteria2/WireGuard, SOCKS/TUN, one/eight flows, all three bulk directions, TCP echo latency and UDP echo.','',
'## Hysteria2 and WireGuard','',
'Throughput counts validated application bytes in both directions. UDP is request/reply with one outstanding packet per flow, not a maximum one-way packet-rate measurement. TCP latency under TUN uses the historical sequential driver (`concurrent_flows: 1`); bulk TCP and UDP are concurrent. All new-protocol results below are candidate measurements: v0.6.1 has neither protocol.','',
'| Case | MiB/s median [min–max] | Echo median (µs) | RSS median (MiB) | CPU median (ms/MiB) |',
'| --- | ---: | ---: | ---: | ---: |']
for row in summaries['new']['rows']:
 v=row['versions']['candidate'];m=v['metrics']
 if not v['complete']:
  lines.append(f"| {row['case']} | **INCOMPLETE: {v['passed_repeats']}/5 passed** | — | — | — |")
 else:
  t=m['throughput_mib_s'];lat=m.get('latency_us',{}).get('median')
  lines.append(f"| {row['case']} | {t['median']:.2f} [{t['min']:.2f}–{t['max']:.2f}] | {lat if lat is not None else '—'} | {m['rss_mib']['median']:.2f} | {m['cpu_ms_per_mib']['median']:.2f} |")
lines+=['','## Comparisons requiring review','',
'The predeclared screening threshold is >15% throughput loss or >15% latency/CPU/RSS growth. This screen is not itself proof of regression. Short CPU measurements have 10 ms quantization and RSS samples are discrete; raw ranges and repeatability matter. Failed groups receive no passing median.','',
'| Suite / case | Threshold crossings (candidate/baseline median) |','| --- | --- |']
for suite in ['legacy','tun','reality']:
 for row in summaries[suite]['rows']:
  if row['review']:
   lines.append('| '+suite+' / '+row['case']+' | '+', '.join(f"{metric}: {row['ratios'][metric]:.3f}×" for metric in row['review'] if metric!='cpu_ms')+' |')
lines += ['', '## WireGuard client isolation control', '',
'The same generic SOCKS driver, 32 MiB per flow/direction, eight flows and fresh pinned server were repeated five times with the pinned Go Xray-core client (`noKernelTun: true`). This isolates the Rust-client path without changing the traffic generator or server. It does not identify the defective function or prove all reference behavior correct.', '',
'| Case | Go client completed | MiB/s median [min–max] |', '| --- | ---: | ---: |']
folder=root/'evidence/wireguard-control-clean'
control=json.loads((folder/'summary.json').read_text())
manifest=json.loads((folder/'manifest.json').read_text())
assert manifest.get('finished_unix') and len(manifest['runs'])==10
assert all(r['process_group_empty_after_run'] and not r['remaining_engine_processes'] for r in manifest['runs'])
for name in ['manifest','summary']:
 shutil.copy2(folder/f'{name}.json',data/f'wireguard-control-{name}.json')
for row in control['rows']:
 v=row['versions']['reference-client']
 t=v['metrics'].get('throughput_mib_s')
 value=f"{t['median']:.2f} [{t['min']:.2f}–{t['max']:.2f}]" if t else '—'
 lines.append(f"| {row['case']} | {v['passed_repeats']}/5 | {value} |")
lines += ['', '[Control manifest](data/wireguard-control-manifest.json), [all control measurements](data/wireguard-control-summary.json).', '']
summaries['wireguard-control']=control
for folder in sorted((root/'evidence').glob('*-diagnostic-clean')):
 diagnostic=json.loads((folder/'summary.json').read_text())
 manifest=json.loads((folder/'manifest.json').read_text())
 assert manifest.get('finished_unix') and len(manifest['runs'])==len(manifest['cases'])*len(manifest['versions'])*manifest['repeats']
 assert all(r['process_group_empty_after_run'] and not r['remaining_engine_processes'] for r in manifest['runs'])
 for name in ['manifest','summary']:
  shutil.copy2(folder/f'{name}.json',data/f'{folder.name}-{name}.json')
 lines += ['', f"## Diagnostic repeat: {folder.name}", '',
 f"{manifest['cases'][0]['iterations']} iterations per flow; five paired repeats. This supplements the original group; it does not replace it. [Manifest](data/{folder.name}-manifest.json), [summary](data/{folder.name}-summary.json).", '',
 '| Case / metric | Baseline median [min–max] | Candidate median [min–max] | Candidate/baseline |', '| --- | ---: | ---: | ---: |']
 for row in diagnostic['rows']:
  for metric in ['throughput_mib_s','cpu_ms_per_mib','rss_mib']:
   b=row['versions']['baseline']['metrics'].get(metric)
   c=row['versions']['candidate']['metrics'].get(metric)
   if b and c:
    lines.append(f"| {row['case']} / {metric} | {b['median']:.2f} [{b['min']:.2f}–{b['max']:.2f}] | {c['median']:.2f} [{c['min']:.2f}–{c['max']:.2f}] | {c['median']/b['median']:.3f}× |")
 summaries[folder.name]=diagnostic
lines += ['', '## Interpretation of the follow-up measurements', '',
'- **WireGuard:** the Go client completed 10/10 controls with the same driver, payload, server implementation and fresh-fixture policy. The Rust client completed 0/10 corresponding primary SOCKS upload/full-duplex runs. This supports investigating the Rust-client path and its interaction with the server; it does not by itself locate a faulty function. Rust TUN upload/full-duplex failures remain open as well.',
'- **XHTTP H1 TUN full-duplex/one flow:** the larger workload confirmed the slowdown in all five pairs. At 32 MiB per direction, median throughput fell from 57.58 to 8.73 MiB/s (candidate/baseline 0.152×, about 85% lower); sample ranges do not overlap. At 4 MiB per direction it was 41.66 → 7.33 MiB/s. This is a repeatable regression in the measured path, not merely a short-window CPU artifact. CPU per MiB changed much less (+5.6% in the larger diagnostic); TUN upload batching and packet-up timing are investigation starting points, not established causes.',
'- **VLESS/TLS TUN CPU:** at 256 MiB per direction, upload CPU per MiB remained 13.8% higher and full-duplex 6.5% higher. Those increases are below the 15% screening threshold but are retained as measured cost changes; the result does not mean CPU usage is identical. Throughput ratios were 0.999× and 0.995×.',
'- **XHTTP H1 TUN download/one flow:** increasing the volume from 4 to 256 MiB removed the 17% median throughput loss; the larger-workload ratio was 0.994×, with overlapping sample ranges. The primary short group remains in the report.',
'- **REALITY/Vision:** an independent repeat of the same eight-flow SOCKS full-duplex case passed all five baseline/candidate pairs. The original early EOF therefore did not reproduce in that repeat. It remains a recorded failure requiring triage; a successful repeat does not turn the original group into a pass.',
'- **Before RC:** resolve the unchanged 100/1000-flow RSS-budget failures, the repeated WireGuard upload/full-duplex timeouts and the confirmed H1 TUN slowdown. Investigate the old TUN echo CPU/connection-close increases and the isolated REALITY EOF. Repeat the affected cases and original gates on each proposed fix without changing their limits.']
failures=[(s,f) for s,r in summaries.items() for f in r['failures']]
if failures:
 lines+=['','## Failed measured runs','', '| Suite / case / version / repeat | Result |','| --- | --- |']
 for suite,f in failures:
  message=(f.get('error') or f"exit {f['returncode']}").replace('|','/').replace('\n',' ')
  lines.append(f"| {suite} / {f['case']} / {f['version']} / {f['repeat']} | {message} |")
lines+=['','## Harness verification and limitations','',
'- Release Clippy for all xray-bench targets passed; 207 release library tests and nine Python evidence/process-lifetime tests passed. Clean smoke controls passed for Hysteria2 TUN upload/eight flows, WireGuard SOCKS upload/one flow, Freedom TUN full-duplex/one flow in both versions, and all 24 paired REALITY scenarios.',
'- The initial generic driver mistakenly used a fixture handle without a destructor, leaving engine processes alive. Inventory found 669 orphan engines; all campaign processes were stopped. All affected transport/protocol collections carry `quality.json` with `usable_for_performance: false` and are excluded from conclusions. The original release gates ran before the leak. The corrected driver kills/waits on every exit path; the collector checks process groups and engine inventory after every run. Dedicated success/failure/interruption tests cover cleanup.',
'- Initial smoke runs exposed ENOBUFS handling in the new driver and the Darwin socketpair 2/4 KiB defaults. The driver now retains backpressured frames and requests 1 MiB send/receive queues at both ends, recording accepted sizes. Preliminary default-buffer throughput is excluded from capacity comparisons. Original regression workloads were not modified.',
'- Generic Hysteria/WireGuard/TUN runs use a fresh reference server and synthetic keys per repeat. Pre-clean protocol findings are invalidated and provide no performance evidence. The extra REALITY suite shares one freshly started server after the original eight-second warmup, with fresh client processes.',
'- Generic bulk traffic is a validated raw byte pattern, not an inner HTTPS workload; do not interpret its REALITY results as a dedicated TLS zero-copy benchmark. The original REALITY bulk workload is retained separately.',
'- Engine RSS and CPU exclude driver/server processes. Those processes still share host CPU, and the desktop host was not isolated from other activity. Generic sampling is every 100 ms, with 500 ms pre/post intervals; CPU includes sampled setup and settling work. Driver TCP buffers are 64 KiB per direction/flow, with a bounded output queue.',
'- Local IPv4 synthetic origins and fd-backed Darwin-utun frames only; no real OS TUN interface or host routes were created. These are not phone, WAN, energy, loss or network-transition results. REALITY may contact its cover destination during setup; application payload remains on this host.',
'- Open release work: resolve unchanged memory-budget failures, investigate TUN CPU/connection-close changes and every failed or repeatable screened transport regression; rerun affected cases and original gates against any fix.','',
'## Raw evidence','',
'`raw-evidence.tar.gz` retains manifests, requests/configs, raw result JSON/resource samples, logs, preliminary diagnostics, collector snapshots and host/build identity. The [benchmark source patch](benchmark-source.patch) applies to the candidate commit and preserves the measured driver plus the final collector extensions. The archive excludes executable binaries and build caches. Synthetic fixture keys are test-only and local. SHA-256 is recorded in [artifact-hashes.json](artifact-hashes.json). Extract into a directory to inspect raw results; full-suite manifests provide `output_relative` so the summarizer works after relocation. Older preliminary runs retain their original absolute paths.','']
(report/'README.md').write_text('\n'.join(lines))
with tarfile.open(report/'raw-evidence.tar.gz','w:gz') as archive:
 archive.add(root/'evidence',arcname='evidence')
 archive.add(root/'collectors',arcname='collectors')
 archive.add(root/'host-build.json',arcname='host-build.json')
 archive.add(root/'benchmark-source.patch',arcname='benchmark-source.patch')
 archive.add(root/'summarize-original.py',arcname='summarize-original.py')
 for name in ['cleanup-inventory.json','cleanup-result.json','wireguard-stall-processes.txt','run-clean-campaign.py','run-supplementary.py','diagnostic-plan.json','compose-report.py']:
  archive.add(root/name,arcname=name)
 for path in sorted(root.glob('*.log')):archive.add(path,arcname='logs/'+path.name)
hashes={str(f.relative_to(report)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(report.rglob('*')) if f.is_file() and f.name!='artifact-hashes.json'}
(report/'artifact-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(report)
