from pathlib import Path
import json,os,subprocess
root=Path('/private/tmp/xray-v07-bench-20260919')
os.environ['GOTOOLCHAIN']='go1.26.5'
for suite in ['new','tun','reality','legacy']:
 m=json.loads((root/'evidence'/f'{suite}-clean/manifest.json').read_text())
 assert m.get('finished_unix') and len(m['runs'])==len(m['cases'])*len(m['versions'])*m['repeats']
collector=root/'harness/scripts/run-v07-performance.py'
summary=root/'harness/scripts/summarize-v07-performance.py'
control=root/'harness/scripts/run-v07-wireguard-control.py'
name='wireguard-control-clean'
with (root/(name+'.log')).open('w') as log:
 rc=subprocess.call(['python3',str(control),'--root',str(root),'--harness',str(root/'bin/protocol-bench'),'--output',str(root/'evidence'/name)],cwd=root/'harness',stdout=log,stderr=subprocess.STDOUT)
print(name,rc,flush=True)
subprocess.run(['python3',str(summary),str(root/'evidence'/name)],check=True)
for suite,case,iterations,name in json.loads((root/'diagnostic-plan.json').read_text()):
 args=['python3',str(collector),'--root',str(root),'--harness',str(root/'bin/protocol-bench'),'--suite',suite,'--case',case,'--iterations',str(iterations),'--output',str(root/'evidence'/name)]
 with (root/(name+'.log')).open('w') as log:
  rc=subprocess.call(args,cwd=root/'harness',stdout=log,stderr=subprocess.STDOUT)
 print(name,rc,flush=True)
 subprocess.run(['python3',str(summary),str(root/'evidence'/name)],check=True)
