import subprocess
from pathlib import Path
import os
root=Path('/private/tmp/xray-v07-bench-20260919')
os.environ['GOTOOLCHAIN']='go1.26.5'
collector=root/'harness/scripts/run-v07-performance.py'
summary=root/'harness/scripts/summarize-v07-performance.py'
smokes=[('new','hysteria2-tun-upload-8','smoke-clean-hysteria-tun'),('new','wireguard-socks-upload-1','smoke-clean-wireguard-socks'),('tun','freedom-tun-full-duplex-1','smoke-clean-freedom-tun'),('reality',None,'smoke-clean-reality')]
plan=[(s,c,n,True) for s,c,n in smokes]+[(s,None,s+'-clean',False) for s in ['new','tun','reality','legacy']]
for suite,case,name,smoke in plan:
    args=['python3',str(collector),'--root',str(root),'--harness',str(root/'bin/protocol-bench'),'--suite',suite,'--output',str(root/'evidence'/name)]
    if smoke:args.append('--smoke')
    if case:args+=['--case',case]
    with (root/(name+'.log')).open('w') as log:
        rc=subprocess.call(args,cwd=root/'harness',stdout=log,stderr=subprocess.STDOUT)
    print(name,rc,flush=True)
    if smoke and rc:raise SystemExit('Clean smoke failed; inspect before continuing')
    subprocess.run(['python3',str(summary),str(root/'evidence'/name)],check=True)
