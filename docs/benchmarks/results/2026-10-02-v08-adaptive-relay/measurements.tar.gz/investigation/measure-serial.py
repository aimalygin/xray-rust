from pathlib import Path
import subprocess
r=Path('/Users/antonmalygin/xray-rust');b=r/'target/v08-quota-investigation'
shared=['--binary','baseline='+str(b/'baseline'),'--binary','adaptive='+str(b/'adaptive2'),'--binary','serial='+str(b/'serial'),'--reference',str(r/'target/v08-io-final/bin/xray'),'--repeats','3','--traffic','full-duplex']
for name,script,harness,extra in [
 ('serial-duplex','scripts/run-v08-cpu-controls.py','target/v08-io-final/bin/harness',['--profile','vmess-aes128','--profile','vmess-chacha20','--flows','1','--flows','8']),
 ('serial-cycles','target/v08-quota-investigation/cycles-controls.py','target/v08-duplex-profile/profile-harness',['--profile','vmess-aes128','--flows','1']),
]:
 c=['python3',str(r/script),*shared,'--harness',str(r/harness),*extra,'--output',str(b/name)]
 with (b/(name+'.log')).open('w') as log:subprocess.run(c,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('pass',name,flush=True)
