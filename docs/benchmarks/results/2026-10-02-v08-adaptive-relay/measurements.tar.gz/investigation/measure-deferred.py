from pathlib import Path
import subprocess
r=Path('/Users/antonmalygin/xray-rust');b=r/'target/v08-quota-investigation'
args=['python3',str(b/'guarded-controls.py'),'--binary','baseline='+str(b/'baseline'),'--binary','control='+str(b/'baseline'),'--binary','prior='+str(b/'selected'),'--binary','candidate='+str(b/'deferred'),'--reference',str(r/'target/v08-io-final/bin/xray'),'--harness',str(r/'target/v08-io-final/bin/harness'),'--profile','vmess-aes128','--profile','vmess-chacha20','--traffic','upload','--traffic','full-duplex','--repeats','4']
for i,case in enumerate(['vmess-aes128-socks-upload-1','vmess-aes128-socks-full-duplex-1','vmess-aes128-socks-full-duplex-8','vmess-chacha20-socks-full-duplex-1','vmess-chacha20-socks-upload-8']):
 name=f'deferred-pilot-{i+1}'
 with (b/(name+'.log')).open('w') as log:subprocess.run(args+['--case-id',case,'--output',str(b/name)],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('pass',name,flush=True)
