#!/usr/bin/env python3
"""Ordinary paired collector with explicit 1 GiB per direction/flow bulk cases.
The harness, cipher, buffers, client settings and latency cases are unchanged.
"""
import hashlib, importlib.util, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("controls", ROOT / "scripts/run-v08-cpu-controls.py")
controls = importlib.util.module_from_spec(spec)
spec.loader.exec_module(controls)
original_cases = controls.c.cases
def long_cases(profiles, smoke=False):
    cases = original_cases(profiles, smoke)
    for case in cases:
        if case["traffic"] in ("upload", "download", "full-duplex"):
            case["iterations"] = 16384
            assert case["iterations"] * case["payload_size"] == 1024**3
            case["id"] += "-1gib"
    return cases
controls.c.cases = long_cases
try:
    controls.main()
finally:
    out = Path(sys.argv[sys.argv.index("--output") + 1])
    path = out / "manifest.json"
    if path.exists():
        manifest = json.loads(path.read_text())
        manifest["file_hashes"][str(Path(__file__).resolve())] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        manifest["bulk_bytes_per_direction_per_flow"] = 1024**3
        path.write_text(json.dumps(manifest, indent=2) + "\n")
