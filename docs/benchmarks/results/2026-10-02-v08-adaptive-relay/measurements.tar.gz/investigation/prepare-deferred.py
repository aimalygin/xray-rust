from pathlib import Path
import subprocess
r=Path('/Users/antonmalygin/xray-rust')
assert subprocess.check_output(['git','remote','get-url','origin'],cwd=r,text=True).strip()=='git@github.com:aimalygin/xray-rust.git'
p=r/'crates/xray-proxy/src/vmess/stream.rs';s=p.read_text();old="                // With independent halves, a response read cannot drain the\n                // writer. Try immediately so a small request does not wait\n                // for the relay's periodic flush. Pending bytes stay owned.\n                if eager {"
new='                // A reader cannot flush an independent writer. Finish a\n                // complete write promptly, including small RPCs. If this\n                // write accepted only part of the input, the next poll drains\n                // the record before encrypting more, as in the combined path.\n                if eager && n == data.len() {'
assert s.count(old)==1;p.write_text(s.replace(old,new))
s=p.read_text();start=s.index('    #[test]\n    fn vmess_write_pairs_keep_record_boundaries_and_resume_under_backpressure()');end=s.index('    #[test]',start+12)
test=s[start:end].replace('vmess_write_pairs_keep_record_boundaries_and_resume_under_backpressure','vmess_split_bulk_tail_flushes_and_partial_ciphertext_resumes_exactly')
marker='                let header_len = client.write.pending.len();\n'
head,tail=test.split(marker,1)
test=head+marker+'                let (_, mut writer) = client.into_split_with(|wire| (tokio::io::empty(), wire));\n'+tail.replace('client.write','writer.state').replace('client.inner','writer.inner').replace('&mut client','&mut writer')
p.write_text(s[:end]+test+s[end:])
