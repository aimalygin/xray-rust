    async fn wait_for_admission(budget: &tokio::sync::Semaphore, available: usize) {
        tokio::time::timeout(Duration::from_secs(2), async {
            while budget.available_permits() != available {
                tokio::time::sleep(Duration::from_millis(1)).await;
            }
        }).await.unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn duplex_admission_releases_on_quiet_reacquires_and_aborts_without_leaks() {
        let (client, inbound) = tokio::io::duplex(1024);
        let (outbound, server) = tokio::io::duplex(1024);
        let (mut client_read, mut client_write) = split(client);
        let (mut server_read, mut server_write) = split(server);
        let (read, write) = split(outbound);
        let budget = test_permit();
        let traffic = Arc::new(ConnectionTraffic::default());
        let relay = tokio::spawn(copy_parallel_with_idle_timeout(
            budget.clone(), split(inbound), (Box::new(read), Box::new(write)),
            Duration::from_secs(5), 32768, traffic.clone(), std::future::pending(),
        ));
        // Initially idle connections never occupy admission.
        tokio::task::yield_now().await;
        assert_eq!(budget.available_permits(), 1);
        for cycle in 0..2 {
            let request = vec![0x31 + cycle; 256 * 1024];
            let response = vec![0x71 + cycle; 256 * 1024];
            let mut received_up = vec![0; request.len()];
            let mut received_down = vec![0; response.len()];
            tokio::time::timeout(Duration::from_secs(2), async {
                let (up, up_read, down, down_read) = tokio::join!(
                    client_write.write_all(&request), server_read.read_exact(&mut received_up),
                    server_write.write_all(&response), client_read.read_exact(&mut received_down),
                );
                up.unwrap(); up_read.unwrap(); down.unwrap(); down_read.unwrap();
            }).await.unwrap();
            assert_eq!(received_up, request);
            assert_eq!(received_down, response);
            wait_for_admission(&budget, 0).await;
            if cycle == 0 { wait_for_admission(&budget, 1).await; }
        }
        assert_eq!(traffic.uplink_bytes.load(Ordering::Relaxed), 512 * 1024);
        assert_eq!(traffic.downlink_bytes.load(Ordering::Relaxed), 512 * 1024);
        relay.abort();
        assert!(relay.await.unwrap_err().is_cancelled());
        wait_for_admission(&budget, 1).await;
        let mut byte = [0];
        assert_eq!(tokio::time::timeout(Duration::from_secs(1), client_read.read(&mut byte)).await.unwrap().unwrap(), 0);
        assert_eq!(tokio::time::timeout(Duration::from_secs(1), server_read.read(&mut byte)).await.unwrap().unwrap(), 0);
    }

    #[tokio::test(start_paused = true)]
    async fn quiet_migration_preserves_partial_write_all_cursor_and_half_close() {
        let (mut writer, mut reader) = tokio::io::duplex(3);
        let payload = b"pending partial write";
        let future: CopyFuture = Box::pin(async move {
            writer.write_all(payload).await?;
            writer.shutdown().await?;
            Ok(payload.len() as u64)
        });
        let budget = test_permit();
        let child = tokio::spawn(run_parallel_uplink(
            future, budget.clone().try_acquire_owned().unwrap(),
            Arc::new(IdleActivity::new()), Arc::new(IdleActivity::new()),
        ));
        tokio::task::yield_now().await;
        assert!(!child.is_finished());
        tokio::time::advance(PARALLEL_QUIET).await;
        let (permit, UplinkResult::Quiet(future)) = child.await.unwrap() else {
            panic!("blocked write must return its pending future");
        };
        assert_eq!(budget.available_permits(), 0);
        drop(permit);
        let mut received = Vec::new();
        let (written, read) = tokio::join!(future, reader.read_to_end(&mut received));
        assert_eq!(written.unwrap(), payload.len() as u64);
        assert_eq!(read.unwrap(), payload.len());
        assert_eq!(received, payload);
        assert_eq!(budget.available_permits(), 1);
    }
