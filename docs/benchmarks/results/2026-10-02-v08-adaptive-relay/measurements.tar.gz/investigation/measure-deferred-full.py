from pathlib import Path
import hashlib,json,subprocess
r=Path('/Users/antonmalygin/xray-rust');b=r/'target/v08-quota-investigation'
shared=['--binary','baseline='+str(b/'baseline'),'--binary','candidate='+str(b/'deferred'),'--reference',str(r/'target/v08-io-final/bin/xray')]
profiles=['--profile','vmess-aes128','--profile','vmess-chacha20']
harness=['--harness',str(r/'target/v08-io-final/bin/harness')]
def run(stage,script,args,held=False):
 attempt=0
 while True:
  attempt+=1;name=f'deferred-{stage}-attempt-{attempt}';out=b/name
  assert not out.exists(),'never overwrite a prior attempt'
  with (b/(name+'.log')).open('w') as log:status=subprocess.run(['python3',str(b/script),*args,'--output',str(out)],cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
  if not (out/'manifest.json').exists():
   p=out.with_suffix('.preflight-failure.json')
   if p.exists() and json.loads(p.read_text())['kind']=='preflight-busy':
    print('preflight overlap; wait again:',name,flush=True);continue
   raise RuntimeError('collector failed before a manifest: '+name)
  m=json.loads((out/'manifest.json').read_text());runs=m['runs']
  if held:
   # A held workload exception can coincide with external load. Inspect it;
   # never automatically retry a timeout/protocol/cleanup/observer failure.
   assert status==0 and m['status']=='pass',name
   assert not m['ambient_cpu']['compiler_load_detected'] and not m['ambient_cpu']['observer_errors'],name
  else:
   assert all(not row['returncode'] and not row['remaining_engine_processes'] and not row['surviving_process_group'] and row['process_group_empty_after_run'] and not row['ambient_cpu']['observer_errors'] for row in runs),'real failure: '+name
   quality=out/'measurement-quality.json'
   contaminated=any(row['ambient_cpu']['compiler_load_detected'] for row in runs) or (quality.exists() and bool(json.loads(quality.read_text())['compiler_load_detected']))
   if contaminated:
    print('Observed environment overlap; retained and retrying entire campaign:',name,flush=True);continue
   assert status==0 and m['status']=='pass',name
  print('pass',name,flush=True);return
run('broad','guarded-controls-v2.py',shared+profiles+harness+['--flows','1','--flows','8','--traffic','upload','--traffic','download','--traffic','full-duplex','--traffic','tcp-latency','--repeats','4'])
aa=shared+['--binary','control='+str(b/'baseline')]
run('confirmation','guarded-controls-v2.py',aa+profiles+harness+['--flows','1','--flows','8','--traffic','full-duplex','--repeats','6'])
run('cycles','guarded-cycles.py',aa+profiles+['--harness',str(r/'target/v08-duplex-profile/profile-harness'),'--flows','1','--traffic','full-duplex','--repeats','6'])
run('idle','guarded-controls-v2.py',shared+profiles+harness+['--flows','1','--traffic','full-duplex','--idle','15','--repeats','4'])
for size_name,size in [('large',1048576),('small',8192)]:
 for profile in ['vmess-aes128','vmess-chacha20']:
  run('held-'+size_name+'-'+profile,'guarded-held.py',shared+['--profile',profile,'--connections','512','--warmup-bytes',str(size),'--idle-seconds','11','--repeats','2'],held=True)
old=json.loads((r/'target/v08-split-investigation/reference-inputs.json').read_text());inputs={key:old[key] for key in ['xray','singbox','harness']}
inputs['candidate']={**json.loads((b/'deferred.json').read_text()),'path':str(b/'deferred')}
assert hashlib.sha256((b/'deferred').read_bytes()).hexdigest()==inputs['candidate']['sha256']
(b/'reference-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
args=['--inputs',str(b/'reference-inputs.json'),*profiles,'--repeats','6']
for profile in ['vmess-aes128','vmess-chacha20']:
 for count in [1,8]:args+=['--case-id',f'{profile}-socks-full-duplex-{count}']
run('reference','guarded-reference.py',args)
print('Deferred candidate: all campaigns finished; inspect every result before retaining.',flush=True)
