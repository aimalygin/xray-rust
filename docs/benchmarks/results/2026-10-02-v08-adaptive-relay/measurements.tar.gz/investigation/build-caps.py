from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path('/Users/antonmalygin/xray-rust');b=r/'target/v08-quota-investigation';source=r/'crates/xray-core-rs/src/outbound.rs'
assert subprocess.check_output(['git','remote','get-url','origin'],cwd=r,text=True).strip()=='git@github.com:aimalygin/xray-rust.git'
env={**os.environ,'CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':'target/v08-comparison-driver'}
compiler=subprocess.check_output(['rustc','-Vv'],cwd=r,text=True)
for limit in [1,2]:
 name=f'cap{limit}';s=source.read_text();s=s.replace('const PARALLEL_VMESS_CONNECTIONS: usize = 1;','const PARALLEL_VMESS_CONNECTIONS: usize = '+str(limit)+';');assert f'const PARALLEL_VMESS_CONNECTIONS: usize = {limit};' in s;source.write_text(s)
 with (b/(name+'-build.log')).open('w') as log:subprocess.run(['cargo','build','--locked','--offline','--release','-p','xray-cli'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 shutil.copy2(r/'target/v08-comparison-driver/release/xray-rust',b/name)
 patch=subprocess.check_output(['git','diff','--binary'],cwd=r);new=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null','crates/xray-proxy/src/vmess/split.rs'],cwd=r,capture_output=True);assert new.returncode==1;patch+=new.stdout;(b/(name+'.patch')).write_bytes(patch)
 meta={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'sha256':hashlib.sha256((b/name).read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest(),'limit':limit,'compiler':compiler,'build_args':['cargo','build','--locked','--offline','--release','-p','xray-cli'],'incremental':False}
 (b/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n');print('frozen',name,meta['sha256'],flush=True)
