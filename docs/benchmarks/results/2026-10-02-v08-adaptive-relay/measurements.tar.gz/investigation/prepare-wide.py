from pathlib import Path
r=Path('/Users/antonmalygin/xray-rust');p=r/'crates/xray-proxy/src/vmess/records.rs';s=p.read_text();a=s.index('    pub(super) fn seal_pair_into(');z=s.index('    fn append(',a)
s=s[:a]+'''    pub(super) fn max_bulk_payload(&self) -> usize {
        16384 - 16 - self.size_bytes() - 64
    }
    pub(super) fn seal_tcp_into(
        &mut self,
        payload: &[u8],
        output: &mut Vec<u8>,
    ) -> io::Result<usize> {
        if !output.is_empty() {
            return Err(invalid("VMess pending frames must be drained"));
        }
        let small = self.max_payload();
        // A bulk record reuses the existing 16 KiB write allocation. Enter
        // this path only at the former two-full-record threshold, so small
        // writes and datagrams retain their existing allocation bounds.
        let n = payload.len().min(if payload.len() >= 2 * small {
            self.max_bulk_payload()
        } else {
            small
        });
        if n != 0 {
            let bound = n + self.size_bytes() + 16 + 63;
            output.reserve_exact(bound.next_power_of_two().min(16384));
            self.append(&payload[..n], output)?;
        }
        Ok(n)
    }
''' +s[z:];p.write_text(s)
p=r/'crates/xray-proxy/src/vmess/stream.rs';s=p.read_text().replace('.seal_pair_into(','.seal_tcp_into(')
a=s.index('    fn vmess_write_pairs_keep_record_boundaries');z=s.index('    #[test]\n    fn vmess_short_writes',a)
x=s[a:z].replace('vmess_write_pairs_keep_record_boundaries_and_resume_under_backpressure','vmess_bulk_record_stays_bounded_and_resumes_under_backpressure').replace('let max = client.write.writer.max_payload();','let max = client.write.writer.max_bulk_payload();').replace('let data = [vec![0x31; max], vec![0x72; max], vec![0x93; 17]].concat();','let data = [vec![0x31; max], vec![0x93; 17]].concat();').replace('2 * max','max').replace('let pair =','let bulk =').replace('pair.as_slice()','bulk.as_slice()').replace('// Decode independently: two distinct authenticated records,','// Decode independently: one bulk authenticated record,').replace('for expected in [&data[..max], &data[max..max], &data[max..], &[]] {','for expected in [&data[..max], &data[max..], &[]] {')
assert 'data[max..max]' not in x
s=s[:a]+x+s[z:]
s=s.replace('fn vmess_second_record_nonce_exhaustion_discards_the_pair_and_fails_closed()', 'fn vmess_bulk_nonce_exhaustion_discards_plaintext_and_fails_closed()').replace('for _ in 0..u16::MAX {','for _ in 0..=u16::MAX {')
p.write_text(s)
