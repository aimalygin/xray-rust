#!/usr/bin/env python3
"""Long CPU diagnostic: eight sequential 256 MiB/direction connections.
Uses the frozen cycle-capable harness without a profiler, gate or instrumentation.
These timings are separate from ordinary single-workload control measurements.
"""
import hashlib, importlib.util, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("controls", ROOT / "scripts/run-v08-cpu-controls.py")
controls = importlib.util.module_from_spec(spec)
spec.loader.exec_module(controls)
original_cases = controls.c.cases
original_env = controls.c.bench.env
def cycle_cases(profiles, smoke=False):
    cases = original_cases(profiles, smoke)
    for case in cases:
        assert case["iterations"] <= 4096
        case["id"] += "-8cycles"
    return cases
controls.c.cases = cycle_cases
controls.c.bench.env = lambda: dict(original_env(), XRAY_PROFILE_CYCLES="8")
try:
    controls.main()
finally:
    out = Path(sys.argv[sys.argv.index("--output") + 1])
    path = out / "manifest.json"
    if path.exists():
        manifest = json.loads(path.read_text())
        manifest["file_hashes"][str(Path(__file__).resolve())] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        manifest["profile_cycles"] = 8
        manifest["diagnostic_only"] = True
        manifest["profiler_attached"] = False
        path.write_text(json.dumps(manifest, indent=2) + "\n")
