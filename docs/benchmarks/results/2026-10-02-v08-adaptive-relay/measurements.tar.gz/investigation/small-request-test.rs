    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn frequent_small_requests_never_occupy_parallel_admission() {
        let (mut client, inbound) = tokio::io::duplex(1024);
        let (outbound, mut server) = tokio::io::duplex(1024);
        let (read, write) = split(outbound);
        let budget = test_budget();
        let relay = tokio::spawn(copy_split_with_idle_timeout(
            budget.clone(), split(inbound), (Box::new(read), Box::new(write)),
            Duration::from_secs(2), 32768, Arc::default(), std::future::pending(),
        ));
        tokio::time::timeout(Duration::from_secs(2), async {
            let request = [0x37; 1024];
            let mut up = [0; 1024];
            let mut down = [0; 1024];
            for _ in 0..256 {
                let (written, read) = tokio::join!(client.write_all(&request), server.read_exact(&mut up));
                written.unwrap(); read.unwrap(); assert_eq!(up, request);
                let (written, read) = tokio::join!(server.write_all(&up), client.read_exact(&mut down));
                written.unwrap(); read.unwrap(); assert_eq!(down, request);
                tokio::task::yield_now().await;
                assert_eq!(budget.available_permits(), 1, "short RPCs must not monopolize bulk admission");
            }
        }).await.unwrap();
        relay.abort();
        assert!(relay.await.unwrap_err().is_cancelled());
    }
