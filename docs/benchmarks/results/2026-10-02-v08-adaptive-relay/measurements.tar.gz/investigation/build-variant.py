from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
r=Path('/Users/antonmalygin/xray-rust');b=r/'target/v08-quota-investigation';name=sys.argv[1]
assert name.replace('-','').isalnum() and not (b/name).exists()
assert subprocess.check_output(['git','remote','get-url','origin'],cwd=r,text=True).strip()=='git@github.com:aimalygin/xray-rust.git'
env={**os.environ,'CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':'target/v08-comparison-driver'}
compiler=subprocess.check_output(['rustc','-Vv'],cwd=r,text=True)
args=['cargo','build','--locked','--offline','--release','-p','xray-cli']
with (b/(name+'-build.log')).open('w') as log: subprocess.run(args,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
shutil.copy2(r/'target/v08-comparison-driver/release/xray-rust',b/name)
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=r)
for source in subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','crates'],cwd=r,text=True).splitlines():
 if '/src/' not in source:continue
 new=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',source],cwd=r,capture_output=True);assert new.returncode==1;patch+=new.stdout
(b/(name+'.patch')).write_bytes(patch)
meta={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'sha256':hashlib.sha256((b/name).read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256(patch).hexdigest(),'compiler':compiler,'build_args':args,'incremental':False}
(b/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n');print('frozen',name,meta['sha256'],flush=True)
