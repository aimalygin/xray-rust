from pathlib import Path
import subprocess
r=Path('/Users/antonmalygin/xray-rust');b=r/'target/v08-quota-investigation'
c=['python3',str(r/'scripts/run-v08-cpu-controls.py')]
for name in ['baseline','cap1','cap2']:c+=['--binary',name+'='+str(b/name)]
c+=['--reference',str(r/'target/v08-io-final/bin/xray'),'--harness',str(r/'target/v08-io-final/bin/harness'),'--profile','vmess-aes128','--profile','vmess-chacha20','--flows','1','--flows','8','--traffic','full-duplex','--repeats','3','--output',str(b/'quota-pilot')]
with (b/'quota-pilot.log').open('w') as log:subprocess.run(c,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
print('pass quota-pilot')
