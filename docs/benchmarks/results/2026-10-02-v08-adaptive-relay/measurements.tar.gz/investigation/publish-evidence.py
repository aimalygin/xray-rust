from pathlib import Path
import hashlib,importlib.util,io,json,shutil,subprocess,tarfile
ROOT=Path('/Users/antonmalygin/xray-rust');BASE=ROOT/'target/v08-quota-investigation';REPORT=ROOT/'docs/benchmarks/results/2026-10-02-v08-adaptive-relay'
assert subprocess.check_output(['git','remote','get-url','origin'],cwd=ROOT,text=True).strip()=='git@github.com:aimalygin/xray-rust.git'
DATA=REPORT/'data';DATA.mkdir(parents=True,exist_ok=True)
def sha(blob):return hashlib.sha256(blob).hexdigest()
def load(p):return json.loads(p.read_text())
items={};campaigns={}
for p in sorted(BASE.glob('*/manifest.json')):
 m=load(p);name=p.parent.name;assert m.get('status') in ['pass','fail'],'unfinished campaign '+name
 aliases={'baseline':'baseline','control':'baseline','cap1':'cap1','cap2':'cap2','adaptive':'adaptive2','wide':'adaptive-wide','separate':'separate-activity','serial':'serial','prior':'selected','xray':'xray','singbox':'singbox'}
 for prefix,variant in [('adaptive-','adaptive2'),('selected-','selected'),('final-','final'),('deferred-','deferred'),('chacha-','chacha')]:
  if name.startswith(prefix):aliases['candidate']=variant
 mapping={r['version']:aliases[r['version']] for r in m['runs']}
 campaigns[name]={'status':m['status'],'runs':len(m['runs']),'versions':mapping,'kind':'held' if 'arguments' in m else 'diagnostic' if m.get('diagnostic_only') else 'ordinary'}
 for source in [p,*(p.parent/r['output_relative']/'result.json' for r in m['runs']),p.parent/'source.patch',p.parent/'measurement-quality.json',*p.parent.glob('*.log')]:
  if source.exists():items[str(source.relative_to(BASE))]=source.read_bytes()
for p in BASE.iterdir():
 if p.is_file() and p.suffix in ['.py','.patch','.json','.log','.rs'] and p.name not in ['summary-preview.json']:
  if p.name=='background-observation.json':
   observation=load(p)
   for row in observation['processes']:row['executable']=Path(row['executable']).name
   observation['raw_local_sha256']=sha(p.read_bytes());items['investigation/'+p.name]=(json.dumps(observation,indent=2)+'\n').encode()
  else:items['investigation/'+p.name]=p.read_bytes()
for script in ['run-v08-cpu-controls.py','run-v08-idle-buffer-controls.py','run-v08-protocol-comparison.py','v08-reference-client.py','run-v07-performance.py','run-v07-performance-followup.py','run-v07-apple-protocol-fixture.py']:
 items['investigation/scripts/'+script]=(ROOT/'scripts'/script).read_bytes()
items['investigation/profile-harness.patch']=(ROOT/'target/v08-duplex-profile/profile-harness.patch').read_bytes()
variants={}
for p in sorted(BASE.glob('*.json')):
 i=load(p)
 if isinstance(i,dict) and {'base_commit','sha256','patch_sha256'}<=i.keys():
  binary=p.with_suffix('');patch=p.with_suffix('.patch');assert sha(binary.read_bytes())==i['sha256'];assert sha(patch.read_bytes())==i['patch_sha256']
  variants[p.stem]={**i,'patch':'investigation/'+patch.name,'identity':'investigation/'+p.name}
refs=load(BASE/'reference-inputs.json')
inputs={'baseline_runtime':'9198a8f2770496199022b531b01b3a2b35ec1bcc','baseline_sha256':sha((BASE/'baseline').read_bytes()),'variants':variants,'xray':refs['xray'],'singbox':refs['singbox'],'harness':refs['harness'],'campaigns':campaigns}
shutil.copyfile(BASE/'summarize.py',DATA/'summarize.py');shutil.copyfile(BASE/'verify.py',DATA/'verify.py')
spec=importlib.util.spec_from_file_location('summary',DATA/'summarize.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
(DATA/'summary.json').write_text(json.dumps(module.run(BASE),sort_keys=True,indent=2)+'\n');(DATA/'inputs.json').write_text(json.dumps(inputs,sort_keys=True,indent=2)+'\n')
index={}
with tarfile.open(REPORT/'measurements.tar.gz','w:gz') as tar:
 for name,data in sorted(items.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));index[name]=sha(data)
(REPORT/'evidence-index.json').write_text(json.dumps({'archive':'measurements.tar.gz','archive_sha256':sha((REPORT/'measurements.tar.gz').read_bytes()),'file_sha256':index},sort_keys=True,indent=2)+'\n')
print('Archived',len(index),'members;',len(campaigns),'campaigns;',len(variants),'frozen variants')
