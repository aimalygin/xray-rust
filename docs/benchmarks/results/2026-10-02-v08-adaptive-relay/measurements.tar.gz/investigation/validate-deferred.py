from pathlib import Path
import os, subprocess
r=Path('/Users/antonmalygin/xray-rust');b=r/'target/v08-quota-investigation'
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='target/v08-comparison-driver')
def run(name,args,extra={}):
 with (b/(name+'.log')).open('w') as log:subprocess.run(args,cwd=r,env=dict(env,**extra),stdout=log,stderr=subprocess.STDOUT,check=True)
 print('pass',name,flush=True)
run('deferred-core-tests',['cargo','test','--locked','--offline','-p','xray-core-rs','--lib'])
for reference,binary in [('xray','xray'),('sing-box','singbox')]:
 run('deferred-interop-'+reference,['cargo','test','--locked','--offline','-p','xray-core-rs','--test','vmess_runtime_tests','--test','runtime_data_path_tests','vmess_runtime_','--','--ignored','--nocapture'], {'XRAY_CLIENT_PROTOCOL_BINARY':str(r/'target/v08-io-final/bin'/binary),'XRAY_CLIENT_PROTOCOL_REFERENCE':reference})
run('deferred-stop-tests',['cargo','test','--locked','--offline','-p','xray-core-rs','--test','runtime_data_path_tests','stop'])
run('deferred-clippy-validation',['cargo','clippy','--locked','--offline','-p','xray-proxy','-p','xray-core-rs','--all-targets','--','-D','warnings'])
