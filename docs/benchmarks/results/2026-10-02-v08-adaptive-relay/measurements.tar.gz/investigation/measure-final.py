from pathlib import Path
import hashlib,json,subprocess
r=Path('/Users/antonmalygin/xray-rust');b=r/'target/v08-quota-investigation'
shared=['--binary','baseline='+str(b/'baseline'),'--binary','candidate='+str(b/'final'),'--reference',str(r/'target/v08-io-final/bin/xray'),'--profile','vmess-aes128','--profile','vmess-chacha20']
def run(name,script,args):
 with (b/(name+'.log')).open('w') as log:subprocess.run(['python3',str(r/script),*args,'--output',str(b/name)],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('pass',name,flush=True)
run('final-broad','scripts/run-v08-cpu-controls.py',shared+['--harness',str(r/'target/v08-io-final/bin/harness'),'--flows','1','--flows','8','--traffic','upload','--traffic','download','--traffic','full-duplex','--traffic','tcp-latency','--repeats','4'])
for name,size in [('final-held-large',1048576),('final-held-small',8192)]:
 run(name,'scripts/run-v08-idle-buffer-controls.py',shared+['--connections','512','--warmup-bytes',str(size),'--idle-seconds','11','--repeats','2'])
run('final-idle','scripts/run-v08-cpu-controls.py',shared+['--harness',str(r/'target/v08-io-final/bin/harness'),'--flows','1','--traffic','full-duplex','--idle','15','--repeats','4'])
# Eight fresh bounded connections in one process; distinct diagnostic series.
run('final-cycles','target/v08-quota-investigation/cycles-controls.py',shared+['--harness',str(r/'target/v08-duplex-profile/profile-harness'),'--flows','1','--traffic','full-duplex','--repeats','6'])
run('final-confirm','scripts/run-v08-cpu-controls.py',shared+['--harness',str(r/'target/v08-io-final/bin/harness'),'--flows','1','--flows','8','--traffic','full-duplex','--repeats','6'])
old=json.loads((r/'target/v08-split-investigation/reference-inputs.json').read_text());inputs={key:old[key] for key in ['xray','singbox','harness']}
inputs['candidate']={**json.loads((b/'final.json').read_text()),'path':str(b/'final')};assert hashlib.sha256((b/'final').read_bytes()).hexdigest()==inputs['candidate']['sha256'];(b/'reference-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
args=['--inputs',str(b/'reference-inputs.json'),'--profile','vmess-aes128','--profile','vmess-chacha20','--repeats','6']
for p in ['vmess-aes128','vmess-chacha20']:
 for n in [1,8]:args+=['--case-id',f'{p}-socks-full-duplex-{n}']
run('final-reference','scripts/run-v08-protocol-comparison.py',args)
