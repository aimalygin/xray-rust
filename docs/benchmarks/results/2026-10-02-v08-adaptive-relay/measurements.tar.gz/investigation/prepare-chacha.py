from pathlib import Path
import subprocess
r=Path('/Users/antonmalygin/xray-rust')
assert subprocess.check_output(['git','remote','get-url','origin'],cwd=r,text=True).strip()=='git@github.com:aimalygin/xray-rust.git'
p=r/'crates/xray-core-rs/src/outbound/vmess.rs';s=p.read_text()
old='    account: Account,\n';assert s.count(old)==1
s=s.replace(old,old+'    parallel_duplex: bool,\n')
old='            account,\n';assert s.count(old)==1
s=s.replace(old,old+'            parallel_duplex: cipher == Cipher::ChaCha20Poly1305,\n')
old='        if target.network == RoutingNetwork::Tcp\n            && matches!(self.0.carrier.transport_layer, TransportLayer::Raw)';assert s.count(old)==1
s=s.replace(old,'''        // Independent tasks reduce measured ChaCha CPU cost. Keep AES on the
        // combined relay: its parallel variant used more CPU for the same load.
        if self.0.parallel_duplex
            && target.network == RoutingNetwork::Tcp
            && matches!(self.0.carrier.transport_layer, TransportLayer::Raw)''')
p.write_text(s)
p=r/'crates/xray-transport/src/lib.rs';s=p.read_text();s=s.replace('    /// Experimental consuming capability; only direct VMess exposes it.', '    /// Consuming capability for independently owned protocol directions.');p.write_text(s)
