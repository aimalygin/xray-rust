from pathlib import Path
import subprocess,json
r=Path('/Users/antonmalygin/xray-rust');b=r/'target/v08-quota-investigation'
args=['python3',str(b/'guarded-controls-v2.py'),'--binary','baseline='+str(b/'baseline'),'--binary','control='+str(b/'baseline'),'--binary','prior='+str(b/'selected'),'--binary','candidate='+str(b/'deferred'),'--reference',str(r/'target/v08-io-final/bin/xray'),'--harness',str(r/'target/v08-io-final/bin/harness'),'--profile','vmess-aes128','--profile','vmess-chacha20','--traffic','upload','--traffic','full-duplex','--repeats','4']
for i,case in enumerate(['vmess-aes128-socks-upload-1','vmess-aes128-socks-full-duplex-1','vmess-aes128-socks-full-duplex-8','vmess-chacha20-socks-full-duplex-1','vmess-chacha20-socks-upload-8']):
 attempt=0
 while True:
  attempt+=1;name=f'deferred-clean-{i+1}-attempt-{attempt}'
  with (b/(name+'.log')).open('w') as log:status=subprocess.run(args+['--case-id',case,'--output',str(b/name)],cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
  manifest=b/name/'manifest.json'
  if not manifest.exists():
   preflight=b/(name+'.preflight-failure.json')
   if preflight.exists() and json.loads(preflight.read_text())['kind']=='preflight-busy':
    print('preflight overlap; wait again:',name,flush=True);continue
   raise RuntimeError('collector failed before manifest: '+name)
  m=json.loads(manifest.read_text());runs=m['runs']
  assert all(not x['returncode'] and not x['remaining_engine_processes'] and not x['surviving_process_group'] and x['process_group_empty_after_run'] and not x['ambient_cpu']['observer_errors'] for x in runs),'workload/cleanup/observer failure; do not retry'
  contaminated=any(x['ambient_cpu']['compiler_load_detected'] for x in runs)
  if contaminated:
   print('Render/build overlap; retain and retry whole block:',name,flush=True);continue
  assert status==0 and m['status']=='pass' and len(runs)==16,name
  print('pass',name,flush=True);break
