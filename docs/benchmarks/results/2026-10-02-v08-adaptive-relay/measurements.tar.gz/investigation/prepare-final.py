from pathlib import Path
r=Path('/Users/antonmalygin/xray-rust');p=r/'crates/xray-core-rs/src/policy.rs';s=p.read_text()
a=s.index('// Each direction has one writer.');z=s.index('\nasync fn copy_direction_with_counter',a);activity=s[a:z];s=s[:a]+s[z:]
a=s.index('type CopyFuture =');owned=s[a:];s=s[:a]
owned=owned.replace('let mut allow_parallel = false; // Serial split-codec control.', 'let mut allow_parallel = tokio::runtime::Handle::current().metrics().num_workers() > 1;')
owned=owned.replace('copy_parallel_with_idle_timeout','copy_split_with_idle_timeout').replace('test_permit','test_budget').replace('mod parallel_tests {','mod tests {')
header='''//! Bounded, demand-driven parallelism for owned VMess codec halves.
use super::{copy_direction_with_counter, CopyActivity};
use crate::connection::ConnectionTraffic;
use std::{io, time::Duration};
use tokio::io::{AsyncRead, AsyncWrite, AsyncWriteExt};
#[cfg(test)]
use tokio::io::{split, AsyncReadExt};

'''
module=r/'crates/xray-core-rs/src/policy/split_relay.rs';module.parent.mkdir(exist_ok=True);module.write_text(header+activity+'\n'+owned)
s=s.replace('use crate::connection::ConnectionTraffic;','use crate::connection::ConnectionTraffic;\n\nmod split_relay;\npub(crate) use split_relay::copy_split_with_idle_timeout;',1);p.write_text(s)
p=r/'crates/xray-core-rs/src/socks.rs';p.write_text(p.read_text().replace('copy_parallel_with_idle_timeout','copy_split_with_idle_timeout'))
# Freeze every new source file, not only the first codec split module.
p=r/'target/v08-quota-investigation/build-variant.py';s=p.read_text();old="new=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null','crates/xray-proxy/src/vmess/split.rs'],cwd=r,capture_output=True);assert new.returncode==1;patch+=new.stdout"
new="for source in subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','crates'],cwd=r,text=True).splitlines():\n if '/src/' not in source:continue\n new=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',source],cwd=r,capture_output=True);assert new.returncode==1;patch+=new.stdout"
assert old in s;s=s.replace(old,new);p.write_text(s)
