from pathlib import Path
r=Path('/Users/antonmalygin/xray-rust');p=r/'crates/xray-core-rs/src/policy.rs';s=p.read_text()
s=s.replace('fn record(&self);','fn record(&mut self, bytes: usize);').replace('fn record(&self) {\n        let _ = self.try_send(());','fn record(&mut self, _: usize) {\n        let _ = self.try_send(());')
s=s.replace('    elapsed_ns: std::sync::atomic::AtomicU64,\n','    elapsed_ns: std::sync::atomic::AtomicU64,\n    bulk: std::sync::atomic::AtomicBool,\n',1)
s=s.replace('            elapsed_ns: std::sync::atomic::AtomicU64::new(0),','            elapsed_ns: std::sync::atomic::AtomicU64::new(0),\n            bulk: std::sync::atomic::AtomicBool::new(false),',1)
a=s.index('impl CopyActivity for std::sync::Arc<IdleActivity>');z=s.index('\nasync fn copy_direction_with_counter',a)
s=s[:a]+'''const PARALLEL_BURST_BYTES: usize = 64 * 1024;
const PARALLEL_QUIET: Duration = Duration::from_millis(100);

struct BurstActivity {
    clock: std::sync::Arc<IdleActivity>,
    changed: std::sync::Arc<tokio::sync::Notify>,
    previous: tokio::time::Instant,
    bytes: usize,
}
impl CopyActivity for BurstActivity {
    #[inline]
    fn record(&mut self, bytes: usize) {
        use std::sync::atomic::Ordering::Relaxed;
        let now = tokio::time::Instant::now();
        if now.duration_since(self.previous) >= PARALLEL_QUIET {
            self.bytes = 0;
            self.clock.bulk.store(false, Relaxed);
        }
        self.previous = now;
        let before = self.bytes;
        self.bytes = self.bytes.saturating_add(bytes);
        let nanos = now.duration_since(self.clock.origin).as_nanos().min(u128::from(u64::MAX)) as u64;
        // A direction has exactly one polling owner, including across migration.
        self.clock.elapsed_ns.store(nanos, Relaxed);
        if before < PARALLEL_BURST_BYTES && self.bytes >= PARALLEL_BURST_BYTES {
            self.clock.bulk.store(true, Relaxed);
            self.changed.notify_one();
        }
    }
}

fn recent_duplex(up: &IdleActivity, down: &IdleActivity) -> bool {
    use std::sync::atomic::Ordering::Relaxed;
    up.bulk.load(Relaxed) && down.bulk.load(Relaxed)
        && up.last().min(down.last()) + PARALLEL_QUIET > tokio::time::Instant::now()
}
''' + s[z:]
s=s.replace('    activity: impl CopyActivity,','    mut activity: impl CopyActivity,',1).replace('                activity.record();','                activity.record(len);',1)
a=s.index('/// Diagnostic SOCKS relay');z=s.index('\n#[cfg(test)]\nmod parallel_tests',a)
s=s[:a]+'''type CopyFuture = std::pin::Pin<Box<dyn std::future::Future<Output = io::Result<u64>> + Send>>;
type AdmissionFuture = std::pin::Pin<Box<dyn std::future::Future<Output = Result<tokio::sync::OwnedSemaphorePermit, tokio::sync::AcquireError>> + Send>>;

enum UplinkResult {
    Complete(io::Result<u64>),
    // Returning the entire pinned future retains buffers and a partial write's
    // cursor. No I/O operation is cancelled and restarted during migration.
    Quiet(CopyFuture),
}

async fn run_parallel_uplink(
    mut upload: CopyFuture,
    permit: tokio::sync::OwnedSemaphorePermit,
    up: std::sync::Arc<IdleActivity>,
    down: std::sync::Arc<IdleActivity>,
) -> (tokio::sync::OwnedSemaphorePermit, UplinkResult) {
    let quiet = tokio::time::sleep(PARALLEL_QUIET);
    tokio::pin!(quiet);
    loop {
        tokio::select! {
            result = &mut upload => return (permit, UplinkResult::Complete(result)),
            () = &mut quiet => {
                if !recent_duplex(&up, &down) {
                    return (permit, UplinkResult::Quiet(upload));
                }
                quiet.as_mut().reset(up.last().min(down.last()) + PARALLEL_QUIET);
            },
        }
    }
}

/// Owned codec halves run locally by default. Only sustained duplex traffic
/// may move the uplink future into one additional task, under a shared quota.
/// A quiet direction returns the same future to the owner without losing I/O
/// state. JoinSet cancels the child if its owner is externally dropped.
pub(crate) async fn copy_parallel_with_idle_timeout<R, W>(
    budget: std::sync::Arc<tokio::sync::Semaphore>,
    inbound: (R, W),
    outbound: (xray_transport::ParallelRead, xray_transport::ParallelWrite),
    idle: Duration,
    buffer_size: usize,
    traffic: std::sync::Arc<ConnectionTraffic>,
    close: impl std::future::Future<Output = ()>,
) -> io::Result<(u64, u64)>
where
    R: AsyncRead + Unpin + Send + 'static,
    W: AsyncWrite + Unpin + Send + 'static,
{
    let (mut a_read, mut a_write) = inbound;
    let (mut b_read, mut b_write) = outbound;
    let up = std::sync::Arc::new(IdleActivity::new());
    let down = std::sync::Arc::new(IdleActivity::new());
    let changed = std::sync::Arc::new(tokio::sync::Notify::new());
    let reporter = |clock: &std::sync::Arc<IdleActivity>| BurstActivity {
        clock: clock.clone(), changed: changed.clone(), previous: clock.origin, bytes: 0,
    };
    let up_reporter = reporter(&up);
    let down_reporter = reporter(&down);
    let up_traffic = traffic.clone();
    let mut upload: Option<CopyFuture> = Some(Box::pin(async move {
        // Sniffed initial payload can already be buffered in the codec.
        b_write.flush().await?;
        copy_direction_with_counter(&mut a_read, &mut b_write, up_reporter,
            buffer_size, Some(&up_traffic.uplink_bytes)).await
    }));
    let mut download: CopyFuture = Box::pin(async move {
        copy_direction_with_counter(&mut b_read, &mut a_write, down_reporter,
            buffer_size, Some(&traffic.downlink_bytes)).await
    });
    let mut tasks = tokio::task::JoinSet::new();
    let mut admission: Option<AdmissionFuture> = None;
    let allow_parallel = tokio::runtime::Handle::current().metrics().num_workers() > 1;
    let deadline = tokio::time::sleep(idle);
    tokio::pin!(deadline, close);
    let (mut up_total, mut down_total) = (None, None);
    let outcome = loop {
        if up_total.is_some() && down_total.is_some() {
            break Ok((up_total.unwrap(), down_total.unwrap()));
        }
        let eligible = allow_parallel && upload.is_some() && down_total.is_none() && recent_duplex(&up, &down);
        if !eligible {
            admission = None;
        } else if admission.is_none() {
            // Waiting for admission never blocks either copy direction.
            admission = Some(Box::pin(budget.clone().acquire_owned()));
        }
        tokio::select! {
            result = async { upload.as_mut().unwrap().await }, if upload.is_some() => {
                upload = None;
                match result { Ok(n) => up_total = Some(n), Err(e) => break Err(e) }
            },
            result = &mut download, if down_total.is_none() => {
                match result { Ok(n) => down_total = Some(n), Err(e) => break Err(e) }
            },
            result = tasks.join_next(), if !tasks.is_empty() => {
                match result {
                    Some(Ok((_permit, UplinkResult::Complete(Ok(n))))) => up_total = Some(n),
                    Some(Ok((_permit, UplinkResult::Complete(Err(e))))) => break Err(e),
                    Some(Ok((_permit, UplinkResult::Quiet(future)))) => upload = Some(future),
                    Some(Err(e)) => break Err(io::Error::other(e)),
                    None => unreachable!("nonempty relay task set"),
                }
            },
            result = async { admission.as_mut().unwrap().await }, if admission.is_some() => {
                admission = None;
                if let Ok(permit) = result {
                    if recent_duplex(&up, &down) && down_total.is_none() {
                        tasks.spawn(run_parallel_uplink(upload.take().unwrap(), permit, up.clone(), down.clone()));
                    }
                }
            },
            () = changed.notified() => {},
            () = &mut deadline => {
                let expires = up.last().max(down.last()) + idle;
                if expires <= tokio::time::Instant::now() {
                    break Err(io::Error::new(io::ErrorKind::TimedOut, "connection idle timeout"));
                }
                deadline.as_mut().reset(expires);
            },
            () = &mut close => break Err(io::ErrorKind::Interrupted.into()),
        }
    };
    tasks.abort_all();
    while tasks.join_next().await.is_some() {}
    outcome
}
''' + s[z:]
s=s.replace('fn test_permit() -> tokio::sync::OwnedSemaphorePermit {\n        Arc::new(tokio::sync::Semaphore::new(1))\n            .try_acquire_owned()\n            .unwrap()\n    }','fn test_permit() -> Arc<tokio::sync::Semaphore> {\n        Arc::new(tokio::sync::Semaphore::new(1))\n    }')
s=s.replace('            budget.clone().try_acquire_owned().unwrap(),\n            split(inbound),','            budget.clone(),\n            split(inbound),',1)
s=s.replace('        assert!(budget.clone().try_acquire_owned().is_err());\n        relay.abort();','        assert_eq!(budget.available_permits(), 1);\n        relay.abort();',1)
p.write_text(s)
p=r/'crates/xray-core-rs/src/socks.rs';s=p.read_text();a=s.index('    if matches!(outbound, TcpOutbound::Vmess(_)) {');z=s.index('\n    let copied = tokio::select!',a)
s=s[:a]+'''    if matches!(outbound, TcpOutbound::Vmess(_)) {
        if let Some(halves) = outbound_stream.take_parallel_halves() {
            drop(outbound_stream);
            let _ = Box::pin(crate::policy::copy_parallel_with_idle_timeout(
                outbound_router.factory().parallel_vmess_budget(),
                inbound.into_split(), halves, tunnel_idle, relay_buffer_size,
                connection_traffic, wait_for_connection_close(&mut connection_close),
            )).await;
            connection.finish();
            return;
        }
    }
''' +s[z:];p.write_text(s)
p=r/'crates/xray-core-rs/src/outbound.rs';s=p.read_text();a=s.index('    /// One quota shared');z=s.index('\n    pub fn graph(',a)
s=s[:a]+'''    /// Shared by every router/inbound using this core. Relay I/O continues
    /// locally while waiting; only active duplex work can occupy admission.
    pub(crate) fn parallel_vmess_budget(&self) -> Arc<tokio::sync::Semaphore> {
        self.parallel_vmess_relays.clone()
    }
''' +s[z:]
s=s.replace('.try_parallel_vmess_relay()', '.parallel_vmess_budget().try_acquire_owned()').replace('.is_none()', '.is_none()')
# Only the newly added test uses Result now instead of Option.
a=s.index('mod parallel_relay_budget_tests');tail=s[a:].replace('.is_none()', '.is_err()').replace('.is_some()', '.is_ok()');s=s[:a]+tail;p.write_text(s)
