from pathlib import Path
import subprocess
r=Path('/Users/antonmalygin/xray-rust');b=r/'target/v08-quota-investigation'
args=['python3',str(r/'scripts/run-v08-cpu-controls.py'),'--binary','baseline='+str(b/'baseline'),'--binary','control='+str(b/'baseline'),'--binary','candidate='+str(b/'selected'),'--reference',str(r/'target/v08-io-final/bin/xray'),'--harness',str(r/'target/v08-io-final/bin/harness'),'--profile','vmess-aes128','--profile','vmess-chacha20','--traffic','upload','--traffic','full-duplex','--repeats','6','--output',str(b/'selected-noise')]
for case in ['vmess-aes128-socks-upload-1','vmess-aes128-socks-full-duplex-8','vmess-chacha20-socks-upload-8']:args+=['--case-id',case]
with (b/'selected-noise.log').open('w') as log:subprocess.run(args,cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
print('pass selected-noise',flush=True)
