#!/usr/bin/env python3
"""Paired controls with an additional headless-render load guard.
Wait for twelve quiet samples before starting; a detected overlap rejects the
whole case block. This supplements, and does not replace, the compiler guard.
"""
import hashlib,importlib.util,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('controls',ROOT/'scripts/run-v08-protocol-comparison.py')
controls=importlib.util.module_from_spec(spec);spec.loader.exec_module(controls)
original=controls.ambient

def ambient():
 result=original()
 rows=controls.bench.command(['ps','-axo','pid=,pcpu=,comm=']).splitlines()
 render=[]
 for line in rows:
  parts=line.strip().split(None,2)
  if len(parts)!=3:continue
  name=Path(parts[2]).name;cpu=float(parts[1])
  if name in {'chrome-headless-shell','ffmpeg','remotion'} and cpu>=5:
   render.append({'pid':int(parts[0]),'cpu':cpu,'name':name,'kind':'background_render'})
 result['compiler_load_detected'].extend(render)
 return result
controls.ambient=ambient
waits=[];quiet=0;started=time.time()
while quiet<12:
 sample={'unix':time.time(),**ambient()};waits.append(sample)
 quiet=0 if sample['compiler_load_detected'] else quiet+1
 if len(waits)%6==0:print('Waiting for quiet benchmark window',round(time.time()-started),'s',flush=True)
 if quiet<12:time.sleep(5)
try:controls.main()
except RuntimeError as error:
 if str(error)=='benchmark/compiler already running':
  out=Path(sys.argv[sys.argv.index('--output')+1])
  out.with_suffix('.preflight-failure.json').write_text(json.dumps({'kind':'preflight-busy','unix':time.time(),'error':str(error),'observation':ambient()},indent=2)+'\n')
 raise
finally:
 out=Path(sys.argv[sys.argv.index('--output')+1]);path=out/'manifest.json'
 if path.exists():
  m=json.loads(path.read_text());m.setdefault('status','fail');m.setdefault('finished_unix',time.time());m['file_hashes'][str(Path(__file__).resolve())]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();m['render_guard']={'minimum_cpu_percent':5,'names':['chrome-headless-shell','ffmpeg','remotion'],'preflight':waits};
  if any(row['ambient_cpu']['compiler_load_detected'] for row in m['runs']):m.update(status='fail',environment_rejected=True)
  path.write_text(json.dumps(m,indent=2)+'\n')
