#!/usr/bin/env python3
"""Paired PR42 Hysteria host regression measurements, retaining failures.

Uses repository fixtures and the same frozen pre-merge driver for both engines.
Does not modify host routes. --aa uses the baseline binary under both labels.
"""
import argparse
import contextlib
import copy
import importlib.util
import json
import os
from pathlib import Path
import platform
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--root', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--case', action='append')
p.add_argument('--repeats', type=int, default=5)
p.add_argument('--smoke', action='store_true')
p.add_argument('--aa', action='store_true')
a = p.parse_args()
root = a.root.resolve()
source = (root / 'candidate').resolve()
spec = importlib.util.spec_from_file_location('comparison', source / 'scripts/run-v08-protocol-comparison.py')
comparison = importlib.util.module_from_spec(spec)
spec.loader.exec_module(comparison)
b = comparison.bench
summary = comparison.module('summary', 'summarize-v07-performance.py')
for variable in ('GOMAXPROCS', 'TOKIO_WORKER_THREADS', 'GOMEMLIMIT', 'GOGC'):
    os.environ.pop(variable, None)
os.umask(0o077)
paths = {v: root / 'bin' / ('baseline' if a.aa else v) / 'xray-rust' for v in ('baseline', 'candidate')}
paths.update(harness=root / 'bin/baseline/xray-bench', xray=root / 'bin/xray-core')
comparison.device.verify_reference(paths['xray'])
if comparison.followup.inventory(paths.values()) or comparison.ambient()['compiler_load_detected']:
    raise RuntimeError('benchmark or compiler already running')
cases = []
def add(profile, path, traffic, count):
    # VMess deliberately closes before its 16-bit AEAD nonce can wrap.
    # Keep single-flow uploads below the existing bounded-record budget.
    bulk_iterations = (4096 if profile.startswith('vmess-') and count == 1 else 16384 // count)
    cases.append(dict(id=f'{profile}-{path}-{traffic}-{count}', profile=profile,
        path=path, traffic=traffic, connections=count,
        payload_size=1200 if traffic == 'udp' else 65536,
        iterations=(10 if a.smoke else 10000) if traffic == 'udp' else (4 if a.smoke else bulk_iterations)))
for count in (1, 8):
    for traffic in ('upload', 'download', 'full-duplex'):
        add('hysteria2', 'tun', traffic, count)
    add('hysteria2', 'socks', 'udp', count)
indexed = comparison.select_cases(cases, a.case)
out = a.output.resolve()
out.mkdir(parents=True, exist_ok=False)
files = [*paths.values(), Path(__file__).resolve(), Path(comparison.__file__),
         Path(b.__file__), Path(comparison.device.__file__), Path(comparison.followup.__file__), Path(summary.__file__)]
hashes = {str(f): b.sha(f) for f in files}
versions = {}
for label in ('baseline', 'candidate'):
    checkout = root / ('baseline' if a.aa else label)
    if b.command(['git', 'status', '--porcelain'], checkout):
        raise RuntimeError('source must be clean')
    versions[label] = dict(commit=b.command(['git', 'rev-parse', 'HEAD'], checkout),
        tree=b.command(['git', 'rev-parse', 'HEAD^{tree}'], checkout), dirty=False,
        engine_sha256=b.sha(paths[label]), binary=str(paths[label]),
        cargo_lock_sha256=b.sha(checkout / 'Cargo.lock'))
manifest = dict(schema_version=1, suite='v08', smoke=a.smoke, diagnostic=bool(a.case or a.aa),
    aa_control=a.aa, repeats=1 if a.smoke else a.repeats,
    cases=[c for _, c in indexed], versions=versions, file_hashes=hashes,
    reference_commit=b.REFERENCE, reference_sha256=b.sha(paths['xray']),
    harness_sha256=b.sha(paths['harness']), platform=platform.platform(),
    tools={tool:b.command(command) for tool,command in {'rust': ['rustc', '-Vv'],
        'cargo': ['cargo', '-V'], 'go': ['go', 'version'], 'xray_build': ['go', 'version', '-m', str(paths['xray'])]}.items()},
    build_flags='cargo build --locked --release -j2 -p xray-cli -p xray-bench; default release profile; baseline frozen from previous validated 3f07fa7 runtime (5ebcad0 only changed docs); candidate rebuilt in its existing same-worktree target',
    fixture_policy='fresh common Xray server/key set per pair; fresh clients in alternating order',
    worker_policy='stock defaults; Go/Tokio worker and GC overrides cleared',
    process_accounting='direct full client process; existing TUN setup/transfer boundaries; SOCKS UDP uses verified TCP warmup outside measurement',
    scope='Hysteria host loopback TUN bulk and SOCKS UDP; not device/release acceptance',
    bulk_budget='1 GiB per direction, except VMess single flow at 256 MiB to stay below the existing fail-closed AEAD record limit',
    started_unix=time.time(), runs=[])
b.save(out / 'manifest.json', manifest)
@contextlib.contextmanager
def fixture(profile, directory):
    if profile in comparison.PROFILES:
        with comparison.fixture(paths['xray'], directory, profile) as (config, _):
            yield config
    else:
        with b.fixture(paths['xray'], directory, reality=profile == 'reality-vision') as configs:
            yield configs[profile]
for index, case in indexed:
    for repeat in range(1, manifest['repeats'] + 1):
        if comparison.ambient()['compiler_load_detected']:
            raise RuntimeError('compiler started during measurement')
        order = ['baseline', 'candidate'] if (index + repeat) % 2 else ['candidate', 'baseline']
        with fixture(case['profile'], out / f"{case['id']}-server-{repeat}") as config:
            for version in order:
                name = f"{case['id']}-{version}-{repeat}"
                request = {k:case[k] for k in ('path', 'traffic', 'connections', 'iterations', 'payload_size')}
                request.update(binary=str(paths[version]), config=copy.deepcopy(config),
                    output=str(out / name), warmup=case['path'] == 'socks',
                    client_preface=case['path'] == 'socks' and case['traffic'] != 'udp')
                request_path = out / (name + '.json')
                b.save(request_path, request)
                result = comparison.measured_execute([str(paths['harness']), 'protocol-run', str(request_path)], out / (name + '.log'))
                remaining = comparison.followup.inventory([paths['baseline'], paths['candidate'], paths['harness']])
                result.update(case=case['id'], version=version, repeat=repeat, output_relative=name,
                    client_order=order, remaining_engine_processes=remaining)
                manifest['runs'].append(result)
                b.save(out / 'manifest.json', manifest)
                print(name, result['returncode'], round(result['seconds'], 2), flush=True)
                if remaining or result['surviving_process_group'] or result['ambient_cpu']['compiler_load_detected']:
                    raise RuntimeError('process leak or concurrent compiler invalidates measurement')
                if a.smoke and result['returncode']:
                    raise RuntimeError('smoke failure')
if comparison.followup.inventory(paths.values()):
    raise RuntimeError('benchmark process survived campaign')
for file, digest in hashes.items():
    if b.sha(file) != digest:
        raise RuntimeError('input changed during measurement: ' + file)
manifest.update(finished_unix=time.time(), status='pass' if all(r['returncode'] == 0 for r in manifest['runs']) else 'fail')
b.save(out / 'manifest.json', manifest)
b.save(out / 'summary.json', summary.summarize(out))
raise SystemExit(0 if manifest['status'] == 'pass' else 1)
