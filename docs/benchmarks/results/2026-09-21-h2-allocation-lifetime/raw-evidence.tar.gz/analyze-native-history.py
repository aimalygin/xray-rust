from pathlib import Path
import collections,hashlib,json,re
n=Path(__file__).resolve().parent
p=n/'histories/candidate2-full-16m/after-events.txt'
groups=collections.defaultdict(lambda:dict(allocations=0,cumulative_requested_bytes=0,sizes=collections.Counter(),example_stack=None))
def category(line,size):
 frames=line.rstrip().split(' | ')
 last=next((f for f in reversed(frames) if '(xray-rust)' in f),'')
 if 'tun_fd::platform::read_loop' in last and size==65536:return 'TUN input arena'
 if 'PrefixedPayload::with_capacity' in last:return 'TLS record payload'
 if 'drive_tun_tcp_stack' in last:return 'TCP stack to upload queue'
 if 'Bytes::copy_from_slice' in last and 'xhttp..h2..H2Upload' in line:return 'HTTP/2 upload DATA copy'
 if 'bridge_tcp_flow_inner' in last and size==65536:return 'Per-flow bridge read buffer'
 if 'write_stack_batch_to_remote' in line and 'finish_grow' in last:return 'Upload batch scratch growth'
 return 'Other'
for line in p.open():
 if not line.startswith('ALLOC '):continue
 match=re.match(r'ALLOC (0x[0-9a-f]+)-.*?\[size=(\d+)\]',line);assert match
 size=int(match[2]);g=groups[category(line,size)];g['allocations']+=1;g['cumulative_requested_bytes']+=size;g['sizes'][size]+=1
 if g['example_stack'] is None:g['example_stack']=line.rstrip()
rows=[]
for k,v in sorted(groups.items(),key=lambda x:x[1]['cumulative_requested_bytes'],reverse=True):
 rows.append(dict(category=k,**v));print(k,v['allocations'],round(v['cumulative_requested_bytes']/1048576,4),'MiB cumulative')
result=dict(source=str(p.relative_to(n)),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),validated_payload_bytes=134217728,groups=rows,meaning='Cumulative allocation requests over the workload, not RSS or simultaneous live bytes. Standard malloc_history output does not provide duration timestamps; paired-address histories may be ambiguous when allocator events interleave between threads.',usable_for_performance=False)
(n/'native-attribution.json').write_text(json.dumps(result,indent=2)+'\n')
