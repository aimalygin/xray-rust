"""Apple malloc allocation/free history of owned clients; never performance evidence."""
from pathlib import Path
import ctypes,hashlib,importlib.util,json,os,signal,subprocess,time,sys
n=Path(__file__).resolve().parent;prior=Path('/private/tmp/xray-h2-tun-memory-20260921');old=Path('/private/tmp/xray-v07-parity-20260920');s=old/'h3-read-batch-source'
spec=importlib.util.spec_from_file_location('bench',s/'scripts/run-v07-performance.py');bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
label=sys.argv[1] if len(sys.argv)>1 else 'candidate2-64m';workers=sys.argv[2] if len(sys.argv)>2 else '2';mib=int(sys.argv[3]) if len(sys.argv)>3 else 64
meta=json.loads((n/'candidate-symbols-build.json').read_text());assert meta['returncode']==0
binary=Path(sys.argv[4]) if len(sys.argv)>4 else Path(meta['binary'])
hmeta=json.loads((prior/'diagnostic-harness-build.json').read_text());harness=Path(hmeta['binary']);assert bench.sha(harness)==hmeta['binary_sha256']
out=n/'traces'/label;out.mkdir(parents=True,exist_ok=False);markers=out/'checkpoints';markers.mkdir();msl=out/'msl';msl.mkdir()
rec=dict(label=label,engine=str(binary),engine_sha256=bench.sha(binary),symbol_build=meta,harness=hmeta,diagnostic_only=True,usable_for_performance=False,mib_per_flow=mib,tools=[])
def save():bench.save(out/'diagnostic.json',rec)
def ps(pid):return subprocess.check_output(['ps','-p',str(pid),'-o','pid=,ppid=,rss=,time=,command='],text=True).strip()
def wait_stage(stage,child):
 deadline=time.monotonic()+100
 while not (markers/(stage+'.json')).exists():
  if child.poll() is not None:raise RuntimeError('harness exited before '+stage)
  if time.monotonic()>deadline:raise TimeoutError(stage)
  time.sleep(.025)
 return json.loads((markers/(stage+'.json')).read_text())
def tool(stage,name,args,pid):
 record=dict(stage=stage,name=name,command=args,started_unix=time.time(),ps_before=ps(pid));path=out/(stage+'-'+name+'.txt')
 try:
  with path.open('w') as f:code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=45).returncode
  record['returncode']=code
 finally:
  record.update(finished_unix=time.time(),bytes=path.stat().st_size);rec['tools'].append(record);save()
 assert code==0,(name,code)
with bench.fixture(old/'bin/xray-core',out/'server') as configs:
 controlled={'TOKIO_WORKER_THREADS':workers}
 request=dict(binary=str(binary),config=configs['xhttp-h2'],path='tun',traffic='upload',connections=8,iterations=mib*16,payload_size=65536,output=str(out/'run'),client_env=controlled)
 bench.save(out/'request.json',request)
 env=bench.env()
 for key in ['TOKIO_WORKER_THREADS','GOMAXPROCS','MallocStackLogging','MallocStackLoggingNoCompact','MallocMaxMagazines','MallocStackLoggingDirectory','DYLD_INSERT_LIBRARIES']:env.pop(key,None)
 env['XRAY_BENCH_MEMORY_CHECKPOINTS']=str(markers)
 command=[str(harness),'protocol-run',str(out/'request.json')];rec.update(command=command,client_env=controlled);save()
 with (out/'driver.log').open('w') as log:
  child=subprocess.Popen(command,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   pid=wait_stage('before',child)['pid'];rec['pid']=pid
   fields=ps(pid).split(None,4);assert int(fields[1])==child.pid and fields[4].startswith(str(binary)+' run ')
   lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib');token=ctypes.c_int();changed=ctypes.c_int()
   name=('xray-tun-allocations-'+str(pid)).encode()
   assert lib.notify_register_check(name,ctypes.byref(token))==0
   lib.notify_check(token,ctypes.byref(changed))
   trace_command=['xcrun','xctrace','record','--template','Allocations','--attach',str(pid),'--time-limit','15s','--output',str(out/'allocations.trace'),'--notify-tracing-started',name.decode()]
   rec['trace_command']=trace_command;save()
   with (out/'trace-record.log').open('w') as trace_log:
    tracer=subprocess.Popen(trace_command,stdout=trace_log,stderr=subprocess.STDOUT)
    try:
     deadline=time.monotonic()+40
     while True:
      assert lib.notify_check(token,ctypes.byref(changed))==0
      if changed.value:break
      if tracer.poll() is not None:raise RuntimeError('Allocations recorder exited before start')
      if time.monotonic()>deadline:raise TimeoutError('Allocations start')
      time.sleep(.1)
     rec['trace_started_unix']=time.time();save()
     (markers/'before.continue').touch()
     wait_stage('after',child);rec['after_unix']=time.time();save();(markers/'after.continue').touch()
     wait_stage('idle',child)
     rec['trace_returncode']=tracer.wait(timeout=40);assert rec['trace_returncode']==0
     (markers/'idle.continue').touch()
    finally:
     lib.notify_cancel(token)
     if tracer.poll() is None:
      tracer.send_signal(signal.SIGINT)
      try:tracer.wait(timeout=10)
      except subprocess.TimeoutExpired:tracer.kill();tracer.wait()
   rec['returncode']=child.wait(timeout=30);assert rec['returncode']==0
   result=json.loads((out/'run/result.json').read_text());assert result['status']=='pass' and result['diagnostic_memory_checkpoints']
   assert result['engine_sha256']==rec['engine_sha256'] and result['client_env']==controlled
   assert result['bytes_sent']==8*mib*1048576 and result['bytes_received']==0
   rec['validated_payload_bytes']=result['bytes_sent']
  finally:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   rec['process_group_empty']=True
   try:os.killpg(child.pid,0);rec['process_group_empty']=False
   except ProcessLookupError:pass
   rec['owned_engine_remaining']=str(binary)+' run -config '+str(out/'run/config.json') in subprocess.check_output(['ps','-axo','pid=,command='],text=True)
   save()
assert rec['process_group_empty'] and not rec['owned_engine_remaining']
print(json.dumps({k:rec[k] for k in ['label','returncode','validated_payload_bytes','process_group_empty','owned_engine_remaining']},indent=2))
