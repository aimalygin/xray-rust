"""Pre-run sampling reduces known host interference; it cannot prove an idle host."""
import json,time
from pathlib import Path
names={'SWBBuildService','rustc','cargo','swift-frontend','swiftc','clang','clang++','ld','metal','actool','compile','asm','link','xcodebuild','ANECompilerService'}
def wait_quiet(cpu):
 start=time.monotonic();samples=[];streak=0
 while True:
  sample=cpu();samples.append(sample)
  flagged=[x for x in sample['processes'] if Path(x['executable']).name in names and x['cpu']>=10]
  total=sum(x['cpu'] for x in sample['processes'] if x['cpu']>=10)
  streak=streak+1 if not flagged and total<100 else 0
  if streak>=3:return dict(samples=samples,required_consecutive_samples=3,sample_interval_seconds=1,total_sampled_cpu_limit_percent=100,seconds=time.monotonic()-start,scope='Pre-run only, followed by per-run compiler observation. Unflagged samples do not prove idle host.')
  if time.monotonic()-start>=180:
   p=Path(__file__).resolve().parent/('quiet-guard-timeout-'+str(time.time_ns())+'.json')
   p.write_text(json.dumps(samples,indent=2)+'\n')
   raise RuntimeError('No quiet starting window within 180 seconds; samples retained at '+str(p))
  time.sleep(1)
