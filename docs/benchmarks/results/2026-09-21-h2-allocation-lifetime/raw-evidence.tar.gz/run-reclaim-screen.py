"""Long paired controls for short-load legacy flags. Run with no other load."""
from pathlib import Path
import importlib.util, json, os, shutil, subprocess, sys, hashlib, threading, time

n = Path(__file__).resolve().parent
r = Path('/private/tmp/xray-v07-parity-20260920')
s = r / 'h3-read-batch-source'
old = Path('/private/tmp/xray-v07-bench-20260919')
assert len(sys.argv) == 2, 'pass immutable candidate binary'
primary = json.loads((r / 'reviewed-sequence.json').read_text())
assert primary['all_planned_groups_collected'] and len(primary['groups']) == 22
binary = Path(sys.argv[1]).resolve(strict=True)
worker12 = binary.parent.with_name(binary.parent.name + '-workers12') / 'xray-rust'
worker12.parent.mkdir(exist_ok=True)
if not worker12.exists():
    shutil.copy2(binary, worker12)
assert binary.read_bytes() == worker12.read_bytes()

spec = importlib.util.spec_from_file_location('follow', s / 'scripts/run-v07-performance-followup.py')
follow = importlib.util.module_from_spec(spec)
spec.loader.exec_module(follow)
original_execute = follow.bench.execute
original_cases = follow.bench.legacy_cases
original = original_execute
from quiet_bench_guard import wait_quiet
compiler_names={'SWBBuildService','rustc','cargo','swift-frontend','swiftc','clang','clang++','ld','metal','actool','compile','asm','link','xcodebuild','ANECompilerService'}
def cpu():
    records=[]
    for row in subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True).splitlines()[1:]:
        pid,percent,comm=row.strip().split(None,2)
        if float(percent)>=10 or Path(comm).name in compiler_names:
            records.append({'pid':int(pid),'cpu':float(percent),'executable':comm})
    return {'time_unix':time.time(),'processes':records}
def busy(snapshot):
    return [x for x in snapshot['processes'] if Path(x['executable']).name in compiler_names and x['cpu']>=10]
quality=[];contaminated=False
def observed_execute(args,log,cwd=None):
    global contaminated
    pre_run_quiet=wait_quiet(cpu)
    before=cpu()
    contaminated |= bool(busy(before))
    snapshots=[before];done=threading.Event()
    def watch():
        while not done.wait(2):snapshots.append(cpu())
    monitor=threading.Thread(target=watch,daemon=True);monitor.start()
    try:result=original(args,log,cwd)
    finally:done.set();monitor.join();snapshots.append(cpu())
    contamination=[item for snapshot in snapshots for item in busy(snapshot)]
    contaminated|=bool(contamination)
    observation={'sample_interval_seconds':2,'snapshots':snapshots,'pre_run_quiet':pre_run_quiet,
                 'compiler_threshold_cpu_percent':10,'compiler_load_detected':contamination}
    quality.append(observation);result['ambient_cpu']=observation
    return result


def execute(command, log, cwd=None):
    request_path=Path(command[-1]);request=json.loads(request_path.read_text())
    candidate=str(binary);reclaim=str(n/'bin/reclaim/xray-rust');baseline=str(old/'bin/baseline/xray-rust')
    controls={candidate:{'TOKIO_WORKER_THREADS':'2'},reclaim:{'TOKIO_WORKER_THREADS':'2'},baseline:{'TOKIO_WORKER_THREADS':'12'}}
    controlled=controls[request['binary']]
    request['client_env']=controlled
    follow.bench.save(request_path,request)
    # Keep the driver/server policy identical. Only the measured client receives overrides.
    for key in ['TOKIO_WORKER_THREADS','GOMAXPROCS','MallocMaxMagazines','MallocStackLogging','MallocStackLoggingNoCompact','MallocDebugReport','DYLD_INSERT_LIBRARIES']:
        os.environ.pop(key,None)
    result=observed_execute(command,log,cwd)
    result['controlled_environment']={'client_env':controlled,'harness_worker_override':None}
    return result

def long_cases(smoke):
    cases = original_cases(smoke)
    for case in cases:
        args = case['args']
        args[args.index('--iterations') + 1] = '65536'
    return cases

follow.bench.execute = execute
follow.bench.legacy_cases = long_cases
for suite, cases in [('tun', ['xhttp-h2-tun-upload-8'])]:
    name = 'reclaim-upload-screen'
    quality=[];contaminated=False
    out = n / 'evidence' / name
    sys.argv = [str(s / 'scripts/run-v07-performance-followup.py'), '--harness', str(r / 'bin/reviewed-parity/xray-bench'),
                '--reference', str(r / 'bin/xray-core'), '--suite', suite, '--repeats', '5', '--output', str(out),
                '--engine', 'candidate=' + str(binary), '--engine', 'reclaim=' + str(n/'bin/reclaim/xray-rust'),
                '--engine', 'baseline=' + str(old / 'bin/baseline/xray-rust')]
    if suite != 'legacy':
        sys.argv += ['--iterations', '8192']
    for case in cases:
        sys.argv += ['--case', case]
    print('START', name, flush=True)
    follow.main()
    (out/'measurement-quality.json').write_text(json.dumps({
        'compiler_load_detected':contaminated,'runs_observed':len(quality),
        'compiler_sample_interval_seconds':2,'compiler_threshold_cpu_percent':10,
        'scope':'exploratory if compiler load detected; otherwise sampled ambient control on the same host',
        'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    },indent=2)+'\n')
    control = {'purpose': 'Compare one arena-reuse patch with its frozen parent and 0.6.1; unchanged harness/server policy',
               'driver': str(Path(__file__)), 'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'reclaim_build': json.loads((n/'reclaim-build.json').read_text()), 'source_build': json.loads((binary.parent / 'build.json').read_text()),
               'workload_override': '4096 MiB per flow' if suite == 'legacy' else '512 MiB per flow',
               'measurements_replace_original_evidence': False}
    (out / 'control.json').write_text(json.dumps(control, indent=2) + '\n')
    subprocess.run(['python3', str(s / 'scripts/summarize-v07-performance.py'), str(out)], check=True)
    print('END', name, flush=True)

assert len(json.loads((out/'manifest.json').read_text())['runs'])==15
for row in json.loads((out/'manifest.json').read_text())['runs']:
 data=json.loads((out/row['output_relative']/'result.json').read_text())
 assert data['client_env']==row['controlled_environment']['client_env']
print('RECLAIM UPLOAD SCREEN COMPLETE',flush=True)
