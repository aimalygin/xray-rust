from pathlib import Path
import hashlib,json,os,subprocess,time
n=Path(__file__).resolve().parent;s=n/'candidate-source';target=n/'candidate-symbols-build'
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(target),CARGO_PROFILE_RELEASE_DEBUG='1',CARGO_PROFILE_RELEASE_STRIP='none')
cmd=['cargo','build','--offline','--locked','--release','-p','xray-cli','--bin','xray-rust'];start=time.time()
with (n/'candidate-symbols-build.log').open('w') as f:r=subprocess.run(cmd,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
b=target/'release/xray-rust'
record=dict(command=cmd,source_commit=subprocess.check_output(['git','-C',str(s),'rev-parse','HEAD'],text=True).strip(),environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_STRIP']},returncode=r.returncode,seconds=time.time()-start,diagnostic_only=True,binary=str(b),binary_sha256=hashlib.sha256(b.read_bytes()).hexdigest() if r.returncode==0 else None)
(n/'candidate-symbols-build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2));raise SystemExit(r.returncode)
