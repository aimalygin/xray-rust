from pathlib import Path
import hashlib, json, os, shutil, subprocess, xml.etree.ElementTree as ET

n = Path(__file__).resolve().parent
core = Path('/Users/antonmalygin/xray-rust')
old = Path('/private/tmp/xray-v07-parity-20260920')
prior = Path('/private/tmp/xray-h2-tun-memory-20260921')
def read(p): return json.loads(p.read_text())
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def git(*args, env=None):
    return subprocess.check_output(['git', '-C', str(n/'reclaim-source'), *args], text=True, env=env).strip()
def save(p, value): p.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

guard = read(n/'main-guard.json')
assert subprocess.check_output(['git','-C',str(core),'rev-parse','HEAD'], text=True).strip() == guard['head']
for name, expected in guard['files'].items(): assert sha(core/name) == expected, name

provenance = n/'source-provenance'; provenance.mkdir(exist_ok=True)
for src, dest in [(old/'bin/reviewed-parity/build.json','parent-build.json'),
                  (old/'bin/reviewed-parity/source.patch','parent.patch'),
                  (prior/'diagnostic-harness-build.json','diagnostic-harness-build.json'),
                  (prior/'diagnostic-harness.patch','diagnostic-harness.patch')]:
    shutil.copy2(src, provenance/dest)
collector = n/'collector-source'; collector.mkdir(exist_ok=True)
for name in ['run-v07-performance-followup.py','run-v07-performance.py','run-v07-apple-protocol-fixture.py','summarize-v07-performance.py']:
    shutil.copy2(old/'h3-read-batch-source/scripts'/name, collector/name)

patches = [
    ('parent.patch', guard['head'], 'b9577f874b3f102880ae078038855803d85f5d04'),
    ('diagnostic-harness.patch', 'b9577f874b3f102880ae078038855803d85f5d04', 'cac1b3f424ce7ce5f8db85869b6616c46cf4de60'),
    ('reclaim.patch', 'b9577f874b3f102880ae078038855803d85f5d04', '449469ae3dcd1dd9fbf5388160af513ff8ab440d'),
    ('pooled.patch', 'b9577f874b3f102880ae078038855803d85f5d04', '10dda33f17fc9ce13687f812d22836485573262e'),
]
reconstructed = []
for name, parent, commit in patches:
    patch = (provenance if name in ['parent.patch','diagnostic-harness.patch'] else n)/name
    index = n/'verify.index'; assert not index.exists()
    env = dict(os.environ, GIT_INDEX_FILE=str(index))
    try:
        git('read-tree', parent, env=env)
        git('apply', '--cached', '--whitespace=nowarn', '--check', str(patch), env=env)
        git('apply', '--cached', '--whitespace=nowarn', str(patch), env=env)
        tree = git('write-tree', env=env)
        expected = (subprocess.check_output(['git','-C',str(prior/'harness-source'),'rev-parse',commit+'^{tree}'],text=True).strip()
                    if name=='diagnostic-harness.patch' else git('rev-parse', commit+'^{tree}'))
        assert tree == expected
    finally: index.unlink(missing_ok=True)
    reconstructed.append(dict(patch=str(patch.relative_to(n)),sha256=sha(patch),parent=parent,commit=commit,tree=tree))
assert git('status','--porcelain') == ''
for _, parent, commit in patches[2:]:
    assert git('diff','--name-only',parent,commit) == 'crates/xray-core-rs/src/tun_fd.rs'

runtime_file = 'crates/xray-core-rs/src/tun_fd.rs'
base = 'ed5258a3a589c2a1f9330142f37c8f3d28a640fa'
parent = patches[0][2]
code_comparison = {}
for name in [runtime_file, 'crates/xray-transport/src/stream/xhttp/h2.rs']:
    # These existing allocations were not introduced by this v0.7 work.
    unchanged = git('diff','--name-only',base,parent,'--',name) == ''
    code_comparison[name] = {'unchanged_0_6_1_to_parent': unchanged}
    assert unchanged, name
    assert (core/name).read_bytes() == subprocess.check_output(['git','-C',str(n/'candidate-source'),'show',parent+':'+name])
for name in [runtime_file, 'crates/xray-core-rs/src/tun.rs','crates/xray-transport/src/stream/xhttp/h2.rs']:
    out = provenance/'parent-files'/name; out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(subprocess.check_output(['git','-C',str(n/'candidate-source'),'show',parent+':'+name]))
save(provenance/'code-comparison.json',code_comparison)

directory = n/'evidence/pooled-upload-screen'
m = read(directory/'manifest.json'); assert len(m['runs']) == 15
for name, expected in m['file_hashes'].items(): assert sha(Path(name)) == expected, name
for run in m['runs']:
    assert run['returncode']==0 and run['process_group_empty_after_run'] and not run['remaining_engine_processes']
    request = read(directory/Path(run['command'][-1]).name)
    result = read(directory/run['output_relative']/'result.json')
    assert result['status']=='pass' and result['bytes_sent']==4294967296 and result['bytes_received']==0
    assert result['iterations']==8192 and result['payload_size']==65536 and result['connections']==8
    assert result['engine_sha256']==m['versions'][run['version']]['engine_sha256']
    assert result['client_env']==request['client_env']==run['controlled_environment']['client_env']
    assert result['client_env']=={'TOKIO_WORKER_THREADS':'12' if run['version']=='baseline' else '2'}
    assert run['controlled_environment']['harness_worker_override'] is None
    assert not run['ambient_cpu']['compiler_load_detected']
assert not read(directory/'measurement-quality.json')['compiler_load_detected']
assert len(read(n/'evidence/reclaim-upload-screen/manifest.json')['runs'])==0

diagnostics = []
for family in ['histories','traces']:
    for p in sorted((n/family).iterdir()):
        d = read(p/'diagnostic.json')
        assert not d['usable_for_performance'] and not d['owned_engine_remaining'] and d['process_group_empty']
        assert d['engine_sha256']==sha(Path(d['engine']))
        assert d['harness']['binary_sha256']==sha(Path(d['harness']['binary']))
        success = d.get('returncode')==0
        if success:
            result = read(p/'run/result.json')
            assert result['status']=='pass' and result['diagnostic_memory_checkpoints']
            assert result['engine_sha256']==d['engine_sha256']
            assert result['bytes_sent']==d['validated_payload_bytes']==d['mib_per_flow']*8*1048576
            assert result['bytes_received']==0
            if family=='traces': assert d['trace_returncode']==0
        else:
            assert p.name=='candidate2-512m' and d['trace_returncode']==2
        diagnostics.append({'path':str(p.relative_to(n)), 'completed_validated':success,
                            'classification':'diagnostic_success' if success else 'Instruments_attach_failure',
                            'owned_cleanup_verified':True})
assert sum(x['completed_validated'] for x in diagnostics)==6 and len(diagnostics)==7

# Never put the full inherited environment or opaque raw trace in the repository.
toc = n/'traces/candidate2-512m-signed/toc.xml'
tree = ET.parse(toc); removed = 0
for p in tree.iter():
    for child in list(p):
        if child.tag == 'environment': removed += len(list(child)); p.remove(child)
assert removed == 63
tree.write(toc.with_name('toc-sanitized.xml'),encoding='unicode',xml_declaration=True)
trace_index = {}
for p in sorted((n/'traces').rglob('*')):
    if p.is_file() and (any(part.endswith('.trace') for part in p.parts) or p.name=='toc.xml'):
        trace_index[str(p.relative_to(n))] = {'bytes':p.stat().st_size,'sha256':sha(p)}
save(n/'private-trace-index.json',{'private_root':str(n),'not_embedded_in_report':True,'reason':'Raw trace/TOC may contain unrelated inherited environment; retain privately. Sanitized TOC, safe allocation-list export and lifetime observations are archived.','files':trace_index,'environment_items_removed_from_delivered_toc':removed})

mobile = Path('/Users/antonmalygin/xray-rust-mobile')
assert not subprocess.check_output(['git','-C',str(mobile),'status','--porcelain'],text=True)
result = dict(timed_runs_verified=15,diagnostic_attempts=diagnostics,quiet_guard_timeout_before_any_timed_run=True,
              patch_reconstruction=reconstructed,guarded_core_files_verified=len(guard['files']),
              core_head_unchanged=guard['head'],mobile_clean=True,
              production_tun_fd_unchanged=True,prepared_extra_protocol_validations_executed=False)
save(n/'input-verification.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ['patch_reconstruction','diagnostic_attempts']},indent=2))
