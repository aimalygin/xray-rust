#!/usr/bin/env python3
"""Recompute allocation diagnostics and the separate unprofiled screen."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import re
import statistics

ROOT = Path(__file__).resolve().parent


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def live_body(path):
    value = path.read_text()
    start = re.search(r'^\d+ calls? for ', value, re.M)
    assert start, path
    return value[start.start():]


def history(root):
    counts = collections.Counter()
    events = collections.Counter()
    for line in (root / 'after-events.txt').open():
        if line.startswith('ALLOC '):
            match = re.search(r'\[size=(\d+)\]', line)
            assert match, line[:100]
            counts[int(match[1])] += 1
            events['allocations'] += 1
        elif line.startswith('FREE '):
            events['frees'] += 1
    heap = re.search(r'All zones: (\d+) nodes \((\d+) bytes\)', (root / 'idle10-heap.txt').read_text())
    assert heap
    return {
        'events_sha256': sha(root / 'after-events.txt'),
        **events,
        'cumulative_requested_bytes': sum(size * count for size, count in counts.items()),
        'allocations_65536_bytes': counts[65536],
        'allocation_size_counts': dict(sorted(counts.items())),
        'live_stack_groups_unchanged_after_to_idle10': live_body(root / 'after-live.txt') == live_body(root / 'idle10-live.txt'),
        'idle10_heap_nodes': int(heap[1]),
        'idle10_heap_bytes': int(heap[2]),
        'meaning': 'Cumulative requested bytes are not live heap, allocator-rounded bytes, RSS, or a lifetime distribution.',
    }


def live_attribution():
    # Unlike ALLOC records, -allBySize can also contain mmap/thread-stack regions.
    # Keep those outside the malloc requested-byte subtotal.
    body = live_body(ROOT / 'histories/candidate2-full-16m/after-live.txt')
    groups = collections.defaultdict(lambda: {'calls': 0, 'requested_bytes': 0, 'example': None})
    parts = re.split(r'(?m)^(\d+) calls? for (\d+) bytes: *\n', body)
    for idx in range(1, len(parts), 3):
        calls, size, stack = int(parts[idx]), int(parts[idx + 1]), parts[idx + 2]
        top = next((line for line in stack.splitlines() if re.match(r'\d+ +xray-rust ', line)), '')
        if not stack.startswith('0   libsystem_malloc.dylib'):
            category = 'Non-malloc or unclassified region (excluded from heap subtotal)'
        elif 'tun_fd::platform::read_loop' in top and size == calls * 65536:
            category = 'Current TUN input arena'
        elif 'PrefixedPayload::with_capacity' in top:
            category = 'TLS outbound payload'
        elif 'Bytes::copy_from_slice' in top and 'H2Upload' in stack:
            category = 'H2 upload DATA payload'
        elif 'drive_tun_tcp_stack' in top:
            category = 'TCP stack to upload queue'
        elif 'bridge_tcp_flow_inner' in top and size == calls * 65536:
            category = 'Per-flow bridge read buffer'
        elif 'jent_entropy_collector_alloc_internal' in stack:
            category = 'AWS-LC entropy collector'
        elif 'DeframerVecBuffer' in stack:
            category = 'TLS input deframer buffers'
        elif 'h2::' in stack or 'xhttp::h2::' in stack or 'H2Pool' in stack:
            category = 'Other H2 connection state / capacity'
        else:
            category = 'Other malloc allocations'
        item = groups[category]
        item['calls'] += calls
        item['requested_bytes'] += size
        if item['example'] is None:
            item['example'] = f'{calls} calls for {size} bytes:\n{stack}'
    return dict(sorted(groups.items()))


def timed():
    spec = importlib.util.spec_from_file_location('parity', ROOT / 'analysis-source/summarize-v07-protocol-parity.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    directory = ROOT / 'evidence/pooled-upload-screen'
    summary = read(directory / 'summary.json')
    row = summary['rows'][0]
    versions = row['versions']
    # The collector's candidate label is the unchanged parent, not the pool.
    comparisons = {}
    for left, right in [('pooled', 'candidate'), ('pooled', 'baseline'), ('candidate', 'baseline')]:
        metrics = {}
        for metric in ['rss_mib', 'throughput_mib_s', 'cpu_ms']:
            a = versions[left]['metrics'][metric]
            b = versions[right]['metrics'][metric]
            metrics[metric] = {
                'left_median': a['median'], 'right_median': b['median'],
                'ratio': a['median'] / b['median'],
                'difference': a['median'] - b['median'],
                'paired_bootstrap_95pct': module.ratio_interval(a['samples'], b['samples']),
                'meets_point_target': module.point_target(metric, a['median'], b['median'], 3),
            }
        comparisons[f'{left}_over_{right}'] = metrics
    return {
        'case': row['case'], 'versions': versions, 'comparisons': comparisons,
        'summary_sha256': sha(directory / 'summary.json'),
        'quality': read(directory / 'measurement-quality.json'),
        'acceptance': 'RSS strictly lower; throughput decrease/CPU increase at most 3%; sampling uncertainty retained.',
        'decision': 'Do not promote either prototype. Pool RSS median is worse, despite fewer allocation requests. Further prepared protocol validation was not run.',
    }


def main():
    histories = {
        root.name: history(root) for root in sorted((ROOT / 'histories').iterdir())
        if 'full-16m' in root.name
    }
    parent = histories['parent-release2-full-16m']
    pool = histories['pooled-release2-full-16m']
    result = {
        'native_histories': histories,
        'pool_over_parent': {key: pool[key] / parent[key] for key in ['allocations_65536_bytes', 'cumulative_requested_bytes']},
        'symbolized_live_attribution': live_attribution(),
        'individual_lifetimes': read(ROOT / 'sampled-lifetimes.json'),
        'unprofiled_screen': timed(),
        'limits': [
            'Diagnostic native requested-byte totals must not be mixed with Instruments usable-size totals or timed RSS.',
            'Only two UI-inspected lifetime examples, not a distribution. The input-arena example includes an inferred attribution.',
            'Address-order anomalies in full native logs preclude naive whole-heap live/peak reconstruction; size totals do not depend on address pairing.',
            'No paired symbolized 0.6.1 allocation trace was collected; exact causal decomposition of its RSS difference remains unresolved.',
        ],
    }
    (ROOT / 'analysis.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    for name, values in result['unprofiled_screen']['comparisons'].items():
        print(name, {k: [round(v['ratio'], 5), v['paired_bootstrap_95pct']] for k, v in values.items()})
    print('Live attribution:', {k: v['requested_bytes'] for k, v in result['symbolized_live_attribution'].items()})


if __name__ == '__main__':
    main()
