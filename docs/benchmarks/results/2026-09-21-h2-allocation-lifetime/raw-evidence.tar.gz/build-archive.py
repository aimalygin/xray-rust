from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile, tempfile

n = Path(__file__).resolve().parent
out = n/'report'; out.mkdir(exist_ok=True)
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def save(p, value): p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

files = []
for root in ['evidence','histories','traces','source-provenance','collector-source','analysis-source']:
    for p in (n/root).rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts: continue
        if root == 'traces' and (any(x.endswith('.trace') for x in p.parts) or p.name=='toc.xml'): continue
        files.append(p)
for p in n.iterdir():
    if (p.is_file() and p.suffix in {'.py','.json','.log','.txt','.patch','.plist'}
            and p.name not in {'archive-driver.log','delivery-receipt.json'}):
        files.append(p)
files.append(n/'README-report.md')
files = sorted(set(files))
assert all(not p.is_symlink() for p in files)
assert not any(p.name=='toc.xml' or any(x.endswith('.trace') for x in p.parts) for p in files)
index = {str(p.relative_to(n)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files}
save(out/'raw-evidence-index.json',index)
print('Archiving',len(files),'files;',sum(x['bytes'] for x in index.values()),'input bytes',flush=True)
archive_path = out/'raw-evidence.tar.gz'
with tarfile.open(archive_path,'w:gz',compresslevel=6) as archive:
    for p in files: archive.add(p,arcname=str(p.relative_to(n)),recursive=False)
with tarfile.open(archive_path,'r:gz') as archive:
    members = archive.getmembers()
    assert len(members)==len(index)==len({m.name for m in members})
    for member in members:
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert member.size==index[member.name]['bytes']
        with archive.extractfile(member) as data:
            assert hashlib.file_digest(data,'sha256').hexdigest()==index[member.name]['sha256'],member.name
print('All archive members verified; recalculating from extracted evidence',flush=True)
with tempfile.TemporaryDirectory(prefix='h2-allocation-reanalysis-',dir='/private/tmp') as temp:
    t = Path(temp)
    with tarfile.open(archive_path,'r:gz') as archive: archive.extractall(t,filter='data')
    for script in ['analyze-native-history.py','analyze-allocation-lifetime.py']:
        subprocess.run(['python3',script],cwd=t,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    for name in ['native-attribution.json','analysis.json']:
        assert json.loads((t/name).read_text())==json.loads((n/name).read_text()),name
    expected_lifetimes=json.loads((t/'sampled-lifetimes.json').read_text())['samples']
    for sample in expected_lifetimes:
        assert abs(round((sample['free_seconds']-sample['allocation_seconds'])*1e6)-sample['lifetime_us'])<=1
save(out/'archive-verification.json',{
    'members':len(index),'all_member_hashes_verified':True,
    'archive_sha256':sha(archive_path),'archive_bytes':archive_path.stat().st_size,
    'native_attribution_reproduced_from_archive_only':True,
    'analysis_reproduced_from_archive_only':True,
    'lifetime_arithmetic_verified':True,
    'lifetime_observations_require_private_original_trace_to_reinspect':True,
    'unrelated_inherited_environment_not_delivered':True,
})
for name in ['analysis.json','native-attribution.json','sampled-lifetimes.json','input-verification.json','private-trace-index.json']:
    shutil.copy2(n/name,out/name)
shutil.copy2(n/'README-report.md',out/'README.md')
(out/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print(json.dumps(json.loads((out/'archive-verification.json').read_text()),indent=2),flush=True)
