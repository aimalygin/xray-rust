from pathlib import Path
import hashlib,json,os,subprocess,time
n=Path(__file__).resolve().parent;s=n/'reclaim-source';target=n/'reclaim-build'
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(target)
for k in ['CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_STRIP','RUSTFLAGS','TOKIO_WORKER_THREADS','MallocStackLogging','MallocStackLoggingNoCompact']:env.pop(k,None)
commands=[['cargo','build','--offline','--locked','--release','-p','xray-cli','--bin','xray-rust'],['cargo','test','--offline','--locked','--release','-p','xray-core-rs','--lib','tun_fd::']]
records=[]
for i,cmd in enumerate(commands):
 start=time.time()
 with (n/f'reclaim-build-{i}.log').open('w') as f:r=subprocess.run(cmd,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(command=cmd,returncode=r.returncode,seconds=time.time()-start))
 (n/'reclaim-build-progress.json').write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
b=target/'release/xray-rust';frozen=n/'bin/reclaim/xray-rust';frozen.parent.mkdir(parents=True,exist_ok=True)
import shutil
shutil.copy2(b,frozen)
record=dict(commands=records,source_commit=subprocess.check_output(['git','-C',str(s),'rev-parse','HEAD'],text=True).strip(),source_tree=subprocess.check_output(['git','-C',str(s),'rev-parse','HEAD^{tree}'],text=True).strip(),binary=str(frozen),binary_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest(),profile='unchanged production release settings',target=str(target))
(n/'reclaim-build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
