#!/usr/bin/env python3
"""Apply the predeclared investigation policy to every complete primary group."""
import json
from pathlib import Path
import subprocess
import time

root = Path('/private/tmp/xray-pr42-main-validation')
for _ in range(360):
    path = root / 'perf-primary-complete/summary.json'
    if path.exists():
        break
    time.sleep(5)
else:
    raise RuntimeError('primary campaign did not complete')
primary = json.loads(path.read_text())
if primary['failures']:
    raise RuntimeError('primary failures require review')
selected = []
for row in primary['rows']:
    r = row['ratios']
    reasons = []
    if r.get('throughput_mib_s', 1) < .97:
        reasons.append('throughput median below 97%')
    if r.get('cpu_ms_per_mib', 1) > 1.05:
        reasons.append('CPU/MiB median above 105%')
    if r.get('rss_mib', 1) > 1.08:
        reasons.append('RSS median above 108%')
    if r.get('latency_us', 1) > 1.05:
        reasons.append('UDP latency median above 105%')
    m = [row['versions'][v]['metrics']['throughput_mib_s']['samples'] for v in ('baseline', 'candidate')]
    if all(c < b for b,c in zip(*m)):
        reasons.append('throughput lower in all five pairs')
    if reasons:
        selected.append({'case': row['case'], 'reasons': reasons, 'primary_ratios': r})
(root / 'analysis-selection.json').write_text(json.dumps(selected, indent=2) + '\n')
if not selected:
    print('No predeclared investigation trigger crossed.', flush=True)
else:
    print(json.dumps(selected, indent=2), flush=True)
    args = ['python3', str(root / 'paired-main.py'), '--root', str(root)]
    for row in selected:
        args += ['--case', row['case']]
    for name, extra in [('confirmation', []), ('aa', ['--aa'])]:
        with (root / ('performance-' + name + '.log')).open('w') as log:
            subprocess.run(args + ['--output', str(root / ('perf-' + name))] + extra,
                           check=True, stdout=log, stderr=subprocess.STDOUT)
