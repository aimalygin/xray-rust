set -euo pipefail
for script in scripts/*.sh scripts/tests/*.sh; do
  bash -n "$script"
done
bash scripts/tests/check-release-version.test.sh
bash scripts/tests/check-prerelease-workflow.test.sh
bash scripts/tests/check-rc-interop.test.sh
bash scripts/tests/check-scheduled-pinned-interop.test.sh
bash scripts/tests/check-xray-main-smoke.test.sh
bash scripts/tests/check-scheduled-interop-workflow.test.sh
bash scripts/tests/check-public-fixtures.test.sh
bash scripts/tests/check-benchmark-publication.test.sh
bash scripts/tests/check-v05-performance.test.sh
bash scripts/tests/check-v05-host-hardening.test.sh
bash scripts/tests/check-mobile-device-evidence.test.sh
python3 -m unittest scripts.tests.test_v06_release_evidence scripts.tests.test_v06_stable_promotion scripts.tests.test_v07_release_evidence scripts.tests.test_v07_stable_promotion scripts.tests.test_v08_release_evidence
python3 -m unittest scripts.tests.test_v07_protocol_parity scripts.tests.test_v07_performance_processes scripts.tests.test_v08_protocol_comparison scripts.tests.test_v08_android_fixture
python3 scripts/tests/set-xray-ss2022-udp-pmtu.test.py
bash scripts/tests/bench-xhttp-memory.test.sh
if [[ -f docs/benchmarks/results/2026-08-29-v26.7.28/manifest.json ]]; then
  python3 scripts/check-benchmark-publication.py docs/benchmarks/results/2026-08-29-v26.7.28
fi
