#!/usr/bin/env python3
"""Keep the first five complete uncontaminated pairs, retaining every attempt.

Reject whole pairs only for observed system compiler activity, never by metric.
Do not stop or modify unrelated host processes. Alternate order by logical pair.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import time

root = Path('/private/tmp/xray-pr42-main-validation')
spec = importlib.util.spec_from_file_location('comparison', root / 'candidate/scripts/run-v08-protocol-comparison.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
summary = c.module('summary', 'summarize-v07-performance.py')
ledger = []
def clean(run):
    return not run['returncode'] and not run['ambient_cpu']['compiler_load_detected'] and not run['ambient_cpu']['observer_errors'] and not run['remaining_engine_processes'] and not run['surviving_process_group']
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def controls(name, case, aa=False, udp_iterations=1000, seed=None):
    accepted = []
    if seed:
        source = root / seed
        manifest = json.loads((source / 'manifest.json').read_text())
        for repeat in range(1, 6):
            group = [r for r in manifest['runs'] if r['repeat'] == repeat]
            if len(group) == 2 and all(clean(r) for r in group):
                accepted.append((source, manifest, group))
    attempts = 0
    while len(accepted) < 5:
        attempts += 1
        if attempts > 15:
            raise RuntimeError('system activity repeatedly prevented clean pairs')
        quiet = 0
        for _ in range(180):
            quiet = quiet + 1 if not c.ambient()['compiler_load_detected'] else 0
            if quiet >= 3:
                break
            time.sleep(5)
        else:
            raise RuntimeError('no quiet measurement window')
        source = root / f'perf-attempt-{name}-{attempts}'
        args = ['python3', str(root / 'paired-control-input.py'), '--root', str(root),
                '--output', str(source), '--case', case, '--repeats', '1',
                '--repeat-offset', str(len(accepted)), '--udp-iterations', str(udp_iterations)]
        if aa:
            args.append('--aa')
        with (root / (source.name + '.log')).open('w') as log:
            code = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT).returncode
        path = source / 'manifest.json'
        if not path.exists():
            raise RuntimeError('control preflight failed; inspect retained log')
        manifest = json.loads(path.read_text())
        group = manifest['runs']
        valid = len(group) == 2 and all(clean(r) for r in group) and not code
        ledger.append({'case': case, 'aa': aa, 'attempt': source.name,
                       'logical_pair': len(accepted) + 1, 'accepted': valid,
                       'manifest_sha256': digest(path)})
        c.bench.save(root / 'control-ledger.json', ledger)
        if valid:
            accepted.append((source, manifest, group))
            print(name, 'clean pair', len(accepted), flush=True)
        elif group and all(not r['returncode'] and not r['remaining_engine_processes'] and not r['surviving_process_group'] for r in group) and any(r['ambient_cpu']['compiler_load_detected'] for r in group):
            c.bench.save(source / 'quality.json', {'usable_for_performance': False,
                'reason': 'Observed system compiler activity; discard whole pair from metric aggregation, retain all raw attempts.'})
            print(name, 'retained contaminated pair', attempts, flush=True)
        else:
            raise RuntimeError('control failed for a reason other than system compiler activity')
    out = root / ('perf-' + name)
    out.mkdir(exist_ok=False)
    combined = copy.deepcopy(accepted[0][1])
    combined.update(runs=[], repeats=5, derived_view=True, status='pass', finished_unix=time.time(),
        derivation='First five complete pairs without observed compiler activity; whole-pair rejection by external-load criterion only. Original attempts and order retained.',
        source_manifests={str((s / 'manifest.json').relative_to(root)): digest(s / 'manifest.json') for s,_,_ in accepted})
    for index, (source, manifest, group) in enumerate(accepted, 1):
        assert manifest['versions'] == combined['versions'] and manifest['cases'] == combined['cases']
        for original in group:
            run = copy.deepcopy(original)
            run.update(repeat=index, output_relative=f"pair-{index}/{original['output_relative']}")
            target = out / run['output_relative']
            target.mkdir(parents=True)
            for path in (source / original['output_relative']).rglob('*'):
                if path.is_file() and (path.name == 'result.json' or path.suffix == '.log'):
                    dest = target / path.relative_to(source / original['output_relative'])
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(path, dest)
                    assert digest(path) == digest(dest)
            combined['runs'].append(run)
    c.bench.save(out / 'manifest.json', combined)
    c.bench.save(out / 'summary.json', summary.summarize(out))
controls('memory-aa-clean', 'vmess-auto-tun-full-duplex-8', aa=True, seed='perf-memory-aa')
for aa in (False, True):
    for profile in ('ss2022-chacha20', 'vmess-aes128', 'vmess-chacha20'):
        controls('udp-long-' + ('aa-' if aa else 'confirmation-') + profile,
                 profile + '-socks-udp-8', aa=aa, udp_iterations=10000)
