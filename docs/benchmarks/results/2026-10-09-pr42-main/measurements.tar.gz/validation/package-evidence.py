#!/usr/bin/env python3
"""Archive public measurements only; omit generated credentials and requests."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/private/tmp/xray-pr42-main-validation')
repo = Path('/private/tmp/xray-rust-pr42-main')
assert subprocess.check_output(['git', 'remote', 'get-url', 'origin'], cwd=repo, text=True).strip() == 'git@github.com:aimalygin/xray-rust.git'
destination = repo / 'docs/benchmarks/results/2026-10-09-pr42-main'
destination.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('summary', repo / 'scripts/summarize-v07-performance.py')
summary = importlib.util.module_from_spec(spec)
spec.loader.exec_module(summary)
members = {}
summaries = {}
for directory in sorted(root.glob('perf-*')):
    if not directory.is_dir():
        continue
    for path in directory.rglob('*'):
        if path.is_file() and (path.name in ('result.json', 'manifest.json', 'summary.json', 'quality.json') or path.suffix == '.log'):
            members[path.relative_to(root).as_posix()] = path
    manifest = json.loads((directory / 'manifest.json').read_text())
    for run in manifest['runs']:
        if run['returncode']:
            continue
        paths = list((directory / run['output_relative']).rglob('result.json'))
        assert len(paths) == 1
        result = json.loads(paths[0].read_text())
        assert result['engine_sha256'] == manifest['versions'][run['version']]['engine_sha256']
    if manifest.get('finished_unix') and not (directory / 'quality.json').exists():
        data = summary.summarize(directory)
        for row in data['rows']:
            row['review'].sort()
        summaries[directory.name] = data
    else:
        summaries[directory.name] = {'incomplete': True, 'retained_runs': len(manifest['runs'])}
for path in root.iterdir():
    if path.is_file() and (path.suffix in ('.log', '.py') or path.name in ('release-builds.json', 'validation.json', 'analysis-policy.json', 'analysis-selection.json', 'control-ledger.json', 'check-repo-scripts.sh', 'ci-jobs-38024178277.json')):
        members['validation/' + path.name] = path
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
archive = destination / 'measurements.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, path in sorted(members.items()):
        tar.add(path, arcname=name, recursive=False)
index = {'archive': archive.name, 'archive_sha256': sha(archive),
         'members': {name: {'bytes': path.stat().st_size, 'sha256': sha(path)} for name, path in sorted(members.items())}}
(destination / 'evidence-index.json').write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
(destination / 'summaries.json').write_text(json.dumps(summaries, indent=2, sort_keys=True) + '\n')
(destination / 'validation.json').write_bytes((root / 'validation.json').read_bytes())
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(members)
    for member in tar.getmembers():
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == index['members'][member.name]['sha256']
print(json.dumps({'members': len(members), 'bytes': archive.stat().st_size, 'campaigns': list(summaries)}, indent=2))
