#!/usr/bin/env python3
"""Derive a complete view without deleting or altering any original attempt."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import time

root = Path('/private/tmp/xray-pr42-main-validation')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for _ in range(120):
    completed = root / 'perf-reality-completion/summary.json'
    if completed.exists():
        break
    time.sleep(5)
else:
    raise RuntimeError('completion campaign did not finish')
original = json.loads((root / 'perf-primary/manifest.json').read_text())
completion = json.loads((root / 'perf-reality-completion/manifest.json').read_text())
assert completion['status'] == 'pass'
for manifest in (original, completion):
    for name, digest in manifest['file_hashes'].items():
        assert sha(Path(name)) == digest
out = root / 'perf-primary-complete'
out.mkdir(exist_ok=False)
manifest = copy.deepcopy(original)
manifest['runs'] = []
omitted = []
for case in original['cases']:
    group = [r for r in original['runs'] if r['case'] == case['id']]
    clean = len(group) == 10 and all(not r['returncode'] and not r['ambient_cpu']['compiler_load_detected'] and not r['ambient_cpu']['observer_errors'] and not r['remaining_engine_processes'] and not r['surviving_process_group'] for r in group)
    source = root / ('perf-primary' if clean else 'perf-reality-completion')
    if not clean:
        omitted.append({'case': case['id'], 'retained_original_runs': len(group), 'reason': 'incomplete paired group or concurrent system compilation'})
        group = [r for r in completion['runs'] if r['case'] == case['id']]
    assert len(group) == 10
    for run in group:
        assert run['returncode'] == 0 and not run['ambient_cpu']['compiler_load_detected']
        directory = source / run['output_relative']
        dest = out / run['output_relative']
        dest.mkdir()
        for path in directory.rglob('*'):
            if path.is_file() and (path.name == 'result.json' or path.suffix == '.log'):
                target = dest / path.relative_to(directory)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, target)
                assert sha(path) == sha(target)
        log = source / (run['output_relative'] + '.log')
        shutil.copyfile(log, out / log.name)
        manifest['runs'].append(run)
manifest.update(status='pass', finished_unix=completion['finished_unix'],
    derived_view=True, excluded_groups=omitted,
    derivation='29 complete original cases with zero observed compiler load plus two fresh full REALITY duplex cases. All original 299 attempts remain in perf-primary; no individual sample replacement.',
    source_manifests={str(p.relative_to(root)): sha(p) for p in [root / 'perf-primary/manifest.json', root / 'perf-reality-completion/manifest.json']})
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
spec = importlib.util.spec_from_file_location('summary', root / 'candidate/scripts/summarize-v07-performance.py')
summary = importlib.util.module_from_spec(spec)
spec.loader.exec_module(summary)
(out / 'summary.json').write_text(json.dumps(summary.summarize(out), indent=2, sort_keys=True) + '\n')
print('Complete 31-case view verified; all original attempts retained.', flush=True)
