#!/usr/bin/env python3
"""Read-only monitor for explicitly supplied release CI runs."""
import json
import subprocess
import sys
import time

targets = [arg.rsplit(':', 1) for arg in sys.argv[1:]]
assert targets
assert all(repo in {'aimalygin/xray-rust', 'aimalygin/xray-rust-mobile'}
           and run.isdecimal() for repo, run in targets)
last = {}
while True:
    terminal = 0
    failed = False
    for repo, run in targets:
        result = subprocess.run(
            ['gh', 'run', 'view', run, '--repo', repo, '--json',
             'status,conclusion,headSha,jobs,url'],
            capture_output=True, text=True, timeout=45,
        )
        if result.returncode:
            print(json.dumps({'repository': repo, 'run': run, 'queryError': result.stderr}), flush=True)
            continue
        data = json.loads(result.stdout)
        snapshot = {
            'repository': repo, 'run': run, 'head': data['headSha'],
            'status': data['status'], 'conclusion': data['conclusion'],
            'jobs': [{key: job[key] for key in ('name', 'status', 'conclusion')}
                     for job in data['jobs']],
        }
        if snapshot != last.get(run):
            print(json.dumps(snapshot), flush=True)
            last[run] = snapshot
        if data['status'] == 'completed':
            terminal += 1
            failed |= data['conclusion'] != 'success'
    if failed or terminal == len(targets):
        raise SystemExit(int(failed))
    time.sleep(45)
