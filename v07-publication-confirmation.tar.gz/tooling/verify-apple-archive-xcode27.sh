#!/usr/bin/env bash
set -euo pipefail

# Xcode 27 lipo rejects multiple -verify_arch arguments as multiple input
# files. Preserve the same required-architecture checks one invocation at a
# time. Every other command and the committed verifier remain unchanged.
lipo() {
  if [[ "$#" -gt 3 && "$2" == -verify_arch ]]; then
    local library="$1"
    shift 2
    local architecture
    for architecture in "$@"; do
      /usr/bin/lipo "$library" -verify_arch "$architecture" || return "$?"
    done
  else
    /usr/bin/lipo "$@"
  fi
}
export -f lipo

root="$(git rev-parse --show-toplevel)"
"$root/scripts/verify-apple-archive.sh" "$1"
