#!/usr/bin/env python3
"""Download and authenticate the published 0.7.0 SDK without changing GitHub."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REPO = "aimalygin/xray-rust-mobile"
COMMIT = "82dd22531256e5d089917e55e9588f29e525f542"
TAG_OBJECT = "4a0aa16ec5116d1c1a6721b7cbf923a1cb850ae2"
APPLE = "3198c0cf4404602eac35f1ae03d7575cc5b8755e679eaae39a7e585e88df5394"

def api(path):
    return json.loads(subprocess.check_output(["gh", "api", f"repos/{REPO}/{path}"]))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

release = api("releases/tags/v0.7.0")
assert not release["draft"] and not release["prerelease"]
assert release["immutable"] is True
ref = api("git/ref/tags/v0.7.0")
assert ref["object"]["type"] == "tag" and ref["object"]["sha"] == TAG_OBJECT
tag = api(f"git/tags/{TAG_OBJECT}")
assert tag["object"]["type"] == "commit" and tag["object"]["sha"] == COMMIT
expected = {"XrayRust.xcframework.zip", "xray-rust-mobile-0.7.0.aar",
            "xray-rust-mobile-0.7.0-maven.zip", "release-manifest.json", "SHA256SUMS"}
assert len(release["assets"]) == 5
assert {asset["name"] for asset in release["assets"]} == expected
target = ROOT / "mobile-public-assets"
target.mkdir(exist_ok=True)
for asset in release["assets"]:
    path = target / asset["name"]
    if not path.exists():
        subprocess.run(["gh", "release", "download", "v0.7.0", "--repo", REPO,
                        "--pattern", asset["name"], "--dir", str(target)], check=True)
    assert path.stat().st_size == asset["size"]
    assert asset["digest"] == "sha256:" + digest(path)
    if path.suffix in {".zip", ".aar"}:
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            assert len(archive.namelist()) == len(set(archive.namelist()))
checksums = {}
for line in (target / "SHA256SUMS").read_text().splitlines():
    sha, name = line.split()
    assert name in expected and name not in checksums
    assert digest(target / name) == sha
    checksums[name] = sha
assert set(checksums) == expected - {"SHA256SUMS"}
manifest = json.loads((target / "release-manifest.json").read_text())
assert manifest["mobileVersion"] == "0.7.0" and manifest["ffiAbiMajor"] == 1
assert manifest["core"]["commit"] == "67969094b352f948c6b8b9e2ac75402c577cb7f7"
assert manifest["core"]["tag"] == "v0.7.0"
assert manifest["core"]["tagObject"] == "f1c59308012efad0e7b9b60c2a9976906b9dba9b"
assert manifest["appleWorkflowArtifact"]["runId"] == 36355936115
assert manifest["appleWorkflowArtifact"]["sourceCommit"] == "fba37e6ab81e253391fdf342d85c20e6d103732b"
assert set(manifest["artifacts"]) == expected - {"SHA256SUMS", "release-manifest.json"}
assert all(checksums[name] == sha for name, sha in manifest["artifacts"].items())
assert checksums["XrayRust.xcframework.zip"] == APPLE
assert digest(ROOT / "apple-canonical-archive/XrayRust.xcframework.zip") == APPLE
report = {"verifiedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "repository": REPO, "version": "0.7.0", "tagObject": TAG_OBJECT,
          "commit": COMMIT, "published": True, "immutable": True,
          "url": release["html_url"], "releaseId": release["id"],
          "result": "pass", "sha256": {name: digest(target / name) for name in sorted(expected)},
          "exactAssetSet": True, "serverDigestsMatched": True,
          "archiveIntegrity": "pass", "coreIdentityMatched": True,
          "canonicalAppleBytesMatched": True}
(ROOT / "mobile-publication.json").write_text(json.dumps(report, indent=2) + "\n")
(ROOT / "mobile-release-api.json").write_text(json.dumps(release, indent=2) + "\n")
print(json.dumps(report, indent=2))
