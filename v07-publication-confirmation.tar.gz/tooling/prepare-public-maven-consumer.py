#!/usr/bin/env python3
"""Pin the public consumer to bytes from the verified immutable SDK bundle."""
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
archive = Path(sys.argv[1])
manifest = json.loads(Path(sys.argv[2]).read_text())
assert manifest["mobileVersion"] == "0.7.0"
assert manifest["artifacts"][archive.name] == hashlib.sha256(archive.read_bytes()).hexdigest()
group, artifact, version = "io.github.aimalygin", "xray-rust-mobile", "0.7.0"
prefix = f"{group.replace('.', '/')}/{artifact}/{version}/"
names = [f"{artifact}-{version}{suffix}" for suffix in
         (".aar", ".pom", ".module", "-sources.jar", "-javadoc.jar")]
target = ROOT / "public-consumers" / "expected-maven"
target.mkdir(exist_ok=True)
digests = {}
with zipfile.ZipFile(archive) as source:
    assert source.testzip() is None
    for name in names:
        member = prefix + name
        assert source.namelist().count(member) == 1
        content = source.read(member)
        (target / name).write_bytes(content)
        digests[name] = hashlib.sha256(content).hexdigest()

metadata = ROOT / "public-consumers/android/gradle/verification-metadata.xml"
ns = "https://schema.gradle.org/dependency-verification"
ET.register_namespace("", ns)
ET.register_namespace("xsi", "http://www.w3.org/2001/XMLSchema-instance")
def tag(name):
    return "{" + ns + "}" + name
tree = ET.parse(metadata)
root = tree.getroot()
trusted = root.find(f"{tag('configuration')}/{tag('trusted-artifacts')}")
if trusted is not None:
    for item in list(trusted):
        if item.get("group") == group and item.get("name") == artifact:
            trusted.remove(item)
components = root.find(tag("components"))
assert components is not None
for component in list(components):
    if component.get("group") == group and component.get("name") == artifact:
        components.remove(component)
component = ET.SubElement(components, tag("component"), group=group, name=artifact, version=version)
for name, digest in digests.items():
    item = ET.SubElement(component, tag("artifact"), name=name)
    ET.SubElement(item, tag("sha256"), value=digest,
                  origin="Verified immutable 0.7.0 release bundle")
ET.indent(tree, space="   ")
tree.write(metadata, encoding="UTF-8", xml_declaration=True)
report = {"version": version, "archiveSha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
          "files": digests, "sdkTrustExceptionRemoved": True}
(ROOT / "public-consumers/maven-expected.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
