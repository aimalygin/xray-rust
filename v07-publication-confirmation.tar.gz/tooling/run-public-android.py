#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "public-consumers"
expected = json.loads((BASE / "maven-expected.json").read_text())["files"]
url = "https://repo.maven.apache.org/maven2/io/github/aimalygin/xray-rust-mobile/0.7.0/"
target = BASE / "central-public"
target.mkdir(exist_ok=True)
for attempt in range(40):
    available = True
    for name, digest in expected.items():
        path = target / name
        if not path.exists():
            temporary = target / (name + ".part")
            response = subprocess.run(["/usr/bin/curl", "--silent", "--show-error",
                "--max-time", "60", "--output", str(temporary), "--write-out", "%{http_code}",
                url + name], capture_output=True, text=True, check=True)
            if response.stdout == "404":
                temporary.unlink()
                available = False
                break
            assert response.stdout == "200", (name, response.stdout)
            assert hashlib.sha256(temporary.read_bytes()).hexdigest() == digest, name
            temporary.replace(path)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    if available:
        break
    if attempt == 0:
        print("Waiting for public Maven Central propagation", flush=True)
    time.sleep(15)
else:
    raise SystemExit("Maven Central propagation did not complete within 10 minutes")
print("Five public Maven Central files exactly match the immutable release bundle", flush=True)
env = os.environ.copy()
env.update(JAVA_HOME="/opt/homebrew/Cellar/openjdk@17/17.0.15/libexec/openjdk.jdk/Contents/Home",
           ANDROID_HOME="/Users/antonmalygin/Library/Android/sdk",
           ANDROID_SDK_ROOT="/Users/antonmalygin/Library/Android/sdk",
           GRADLE_USER_HOME=str(BASE / "gradle-home"), XRAY_MOBILE_VERSION="0.7.0")
mobile = ROOT.parents[1]
assert (mobile / "release/version.env").is_file()
args = [str(mobile / "android/gradlew"), "-p", str(BASE / "android"),
        ":consumer:assembleRelease", "--dependency-verification", "strict",
        "--no-daemon", "--refresh-dependencies"]
with (BASE / "android-build.log").open("w") as log:
    process = subprocess.Popen(args, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        log.write(line)
        log.flush()
        if line.startswith(("> Task", "BUILD ", "FAILURE:", "* What went wrong:")):
            print(line, end="", flush=True)
    code = process.wait()
    if code:
        print((BASE / "android-build.log").read_text()[-7000:])
    raise SystemExit(code)
