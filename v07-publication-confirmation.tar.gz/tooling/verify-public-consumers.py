#!/usr/bin/env python3
"""Verify the outputs of the isolated public SwiftPM and Maven consumers."""
import datetime
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "public-consumers"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
resolved = json.loads((BASE / "swift/Package.resolved").read_text())
pins = [pin for pin in resolved["pins"] if pin["identity"] == "xray-rust-mobile"]
assert len(pins) == 1
pin = pins[0]
assert pin["location"] == "https://github.com/aimalygin/xray-rust-mobile.git"
assert pin["state"]["version"] == "0.7.0"
assert pin["state"]["revision"] == "82dd22531256e5d089917e55e9588f29e525f542"
swift_log = (BASE / "swift-build.log").read_text()
assert "Remote SwiftPM 0.7.0: FFI 1.7, Hysteria2/WireGuard capabilities and imports passed" in swift_log
assert (BASE / "swift-build/release/ReleaseConsumer").is_file()
checkout = BASE / "swift-build/checkouts/xray-rust-mobile"
assert checkout.is_dir() and not (checkout / "Artifacts/XrayRust.xcframework").exists()
package = (checkout / "Package.swift").read_text()
assert "3198c0cf4404602eac35f1ae03d7575cc5b8755e679eaae39a7e585e88df5394" in package
assert 'let releaseVersion = "0.7.0"' in package
assert "https://github.com/aimalygin/xray-rust-mobile/releases/download/v0.7.0/XrayRust.xcframework.zip" in package.replace(r"\(releaseVersion)", "0.7.0")
expected = json.loads((BASE / "maven-expected.json").read_text())
assert expected["sdkTrustExceptionRemoved"]
assert "BUILD SUCCESSFUL" in (BASE / "android-build.log").read_text()
assert "XRAY_MAVEN_REPOSITORY" not in (BASE / "android/settings.gradle.kts").read_text()
cache = BASE / "gradle-home/caches/modules-2/files-2.1/io.github.aimalygin/xray-rust-mobile/0.7.0"
cached = {}
for name, digest in expected["files"].items():
    public = BASE / "central-public" / name
    assert public.is_file() and sha(public) == digest
    if name.endswith((".aar", ".pom", ".module")):
        matches = list(cache.glob("*/" + name))
        assert len(matches) == 1, (name, matches)
        assert sha(matches[0]) == digest
        cached[name] = digest
apk = BASE / "android/consumer/build/outputs/apk/release/consumer-release-unsigned.apk"
abis = ["arm64-v8a", "armeabi-v7a", "x86", "x86_64"]
with zipfile.ZipFile(apk) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    for abi in abis:
        for library in ["libxray_ffi.so", "libxray_mobile_jni.so"]:
            assert names.count(f"lib/{abi}/{library}") == 1
manifests = list((BASE / "android/consumer/build/intermediates/merged_manifests/release").rglob("AndroidManifest.xml"))
assert len(manifests) == 1, manifests
manifest = ET.parse(manifests[0]).getroot()
android = "{http://schemas.android.com/apk/res/android}"
services = manifest.findall("application/service")
vpn = [s for s in services if any(a.get(android + "name") == "android.net.VpnService"
                                for a in s.findall("intent-filter/action"))]
assert len(vpn) == 1
assert vpn[0].get(android + "name") == "org.xrayrust.mobile.smoke.AppVpnService"
assert vpn[0].get(android + "permission") == "android.permission.BIND_VPN_SERVICE"
assert vpn[0].get(android + "exported") == "false"
assert vpn[0].get(android + "foregroundServiceType") == "systemExempted"
assert all(s.get(android + "name") != "org.xrayrust.mobile.XrayVpnService" for s in services)
report = {"verifiedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "version": "0.7.0", "newPhysicalDeviceRun": False,
          "swift": {"result": "pass", "pin": pin, "ffi": "1.7",
                    "products": ["XrayMobileAdapter", "XrayAppleShared", "XrayAppleTunnel"],
                    "profileImports": ["Hysteria2", "WireGuard"],
                    "logSha256": sha(BASE / "swift-build.log")},
          "android": {"result": "pass", "repository": "Maven Central",
                      "coordinate": "io.github.aimalygin:xray-rust-mobile:0.7.0",
                      "r8Release": True, "abis": abis,
                      "allFivePublicFilesMatchRelease": True,
                      "cachedArtifacts": cached, "apkSha256": sha(apk),
                      "singleAppVpnService": True,
                      "logSha256": sha(BASE / "android-build.log")}}
(BASE / "results.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
