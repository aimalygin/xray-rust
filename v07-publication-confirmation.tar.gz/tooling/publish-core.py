#!/usr/bin/env python3
"""Finalize the prepared 0.7.0 source release only after its exact gates pass."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REPOSITORY = "aimalygin/xray-rust"
COMMIT = "67969094b352f948c6b8b9e2ac75402c577cb7f7"
TAG_OBJECT = "f1c59308012efad0e7b9b60c2a9976906b9dba9b"
TAG = "v0.7.0"


def gh(*args):
    return subprocess.check_output(["gh", *args], text=True)


def api(path):
    return json.loads(gh("api", f"repos/{REPOSITORY}/{path}"))


assert sys.argv[1:] in ([], ["--publish"])
runs = {}
for name, run_id in {"fullCi": 36344835351, "evidence": 36344840384,
                     "tagCi": 36355379619}.items():
    run = api(f"actions/runs/{run_id}")
    assert run["head_sha"] == COMMIT
    assert run["status"] == "completed" and run["conclusion"] == "success", (name, run["status"], run["conclusion"])
    runs[name] = {"id": run_id, "url": run["html_url"], "headSha": run["head_sha"], "conclusion": run["conclusion"]}

ref = api(f"git/ref/tags/{TAG}")
assert ref["object"]["type"] == "tag" and ref["object"]["sha"] == TAG_OBJECT
tag = api(f"git/tags/{TAG_OBJECT}")
assert tag["object"]["type"] == "commit" and tag["object"]["sha"] == COMMIT
matches = [item for item in api("releases?per_page=100") if item["tag_name"] == TAG]
assert len(matches) == 1
release = matches[0]
release_id = release["id"]
assert release["tag_name"] == TAG and not release["prerelease"]
assets = {asset["name"]: asset for asset in release["assets"]}
expected = {"xray-rust-0.7.0.tar.gz", "release-metadata.txt", "source-validation.json", "SHA256SUMS"}
assert len(release["assets"]) == len(expected) and set(assets) == expected
digests = {}
for name in sorted(expected):
    local = ROOT / "core-stable-source-bundle" / name
    remote = ROOT / "core-stable-remote" / name
    assert local.read_bytes() == remote.read_bytes()
    digest = hashlib.sha256(local.read_bytes()).hexdigest()
    assert assets[name]["size"] == local.stat().st_size
    assert assets[name]["digest"] == "sha256:" + digest
    digests[name] = digest

if sys.argv[1:] == ["--publish"] and release["draft"]:
    subprocess.run(["gh", "release", "edit", TAG, "--repo", REPOSITORY,
                    "--draft=false", "--prerelease=false", "--latest"], check=True)
    release = api(f"releases/{release_id}")
    assert not release["draft"] and not release["prerelease"]
report = {"tag": TAG, "tagObject": TAG_OBJECT, "commit": COMMIT,
          "runs": runs, "assets": digests, "published": not release["draft"],
          "immutable": release.get("immutable"), "url": release["html_url"]}
(ROOT / "core-publication.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
