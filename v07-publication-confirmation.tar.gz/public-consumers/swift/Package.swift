// swift-tools-version: 5.9
import PackageDescription
let package = Package(
    name: "ReleaseConsumer",
    platforms: [.macOS(.v11)],
    dependencies: [.package(url: "https://github.com/aimalygin/xray-rust-mobile.git", exact: "0.7.0")],
    targets: [.executableTarget(name: "ReleaseConsumer", dependencies: [
        .product(name: "XrayMobileAdapter", package: "xray-rust-mobile"),
        .product(name: "XrayAppleShared", package: "xray-rust-mobile"),
        .product(name: "XrayAppleTunnel", package: "xray-rust-mobile"),
    ])]
)
