import Foundation
import XrayMobileAdapter
import XrayAppleShared
import XrayAppleTunnel

let info = XrayCore.ffiInfo
precondition(info.version.major == 1 && info.version.minor >= 7)
precondition(info.supportsProfileImport(.hysteria2))
precondition(info.supportsProfileImport(.wireguard))
let hy = try XrayProfileImporter.profile(
    from: "hysteria2://fixture-pass@hy.example.invalid:443/?sni=hy.example.invalid",
    format: .hysteria2,
    dnsServers: ["1.1.1.1"]
)
let privateKey = Data(repeating: 1, count: 32).base64EncodedString()
let publicKey = Data(repeating: 2, count: 32).base64EncodedString()
let wg = try XrayProfileImporter.profile(from: """
[Interface]
PrivateKey = \(privateKey)
Address = 10.7.0.2/32
DNS = 1.1.1.1
[Peer]
PublicKey = \(publicKey)
Endpoint = wg.example.invalid:51820
AllowedIPs = 0.0.0.0/0
""", format: .wireguard)
precondition(!hy.configJSON.isEmpty && !wg.configJSON.isEmpty)
print("Remote SwiftPM 0.7.0: FFI \(info.version.major).\(info.version.minor), Hysteria2/WireGuard capabilities and imports passed")
