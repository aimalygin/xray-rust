# Public release consumers

These independent consumers resolve version 0.7.0 from public SwiftPM/GitHub release assets and Maven Central after publication. No local SDK project or Maven repository is configured. Swift caches and Gradle user home are isolated for this run.

The Swift executable links all three public products and calls ABI/capability/profile-import functions for both new protocols without starting a VPN. The Android consumer is copied from the committed R8 smoke application, with the staged repository removed. Before execution, replace its SDK trust exception with exact checksums verified against the immutable Maven release bundle.

Preparation alone is not a passing result; retain command logs and resolved artifact identities after execution.
