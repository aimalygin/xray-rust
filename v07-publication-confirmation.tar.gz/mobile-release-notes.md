Stable channel with Hysteria2/WireGuard support. The measured device archive
retains its original candidate identity and the documented owner decisions.

- Synchronize Hysteria2 and WireGuard configuration/profile import, capability
  discovery, DNS bootstrap and carrier network-change APIs with C ABI 1.7.
- Preserve WireGuard peers, PSKs, split routes and protected Android sockets;
  update Apple path observation and endpoint-route handling.
- Pin annotated core tag `v0.7.0`, commit
  `67969094b352f948c6b8b9e2ac75402c577cb7f7`, its tree and source checksums.
  Canonical Apple preparation and publication verify this immutable identity.
- Require v0.7 exact-candidate Apple/Android evidence, including both protocols
  and Android FileDescriptor/PacketPump paths. Publish directly to the stable
  channel after final CI, canonical artifact preparation and consumer checks.
- Preserve owner decisions: Android cellular handover was not tested, and the
  investigated Android WireGuard timeout case is accepted for 0.7 with its
  original failures retained. No generic reliability waiver or product fix is claimed.
- Retain documented core performance limitations, including deferred H2/TUN RSS
  investigation and separate Hysteria2 comparison gaps.

Core: [xray-rust 0.7.0](https://github.com/aimalygin/xray-rust/releases/tag/v0.7.0), commit `67969094b352f948c6b8b9e2ac75402c577cb7f7`.

Apple installation with Swift Package Manager:

```swift
.package(url: "https://github.com/aimalygin/xray-rust-mobile.git", exact: "0.7.0")
```

Android coordinate:

```kotlin
implementation("io.github.aimalygin:xray-rust-mobile:0.7.0")
```

The attached release manifest and SHA256SUMS identify the exact Apple and Android artifacts. See the [source/device evidence and accepted limitations](https://github.com/aimalygin/xray-rust/blob/v0.7.0/docs/v07-stable-promotion.md) and [performance record](https://github.com/aimalygin/xray-rust/blob/v0.7.0/docs/v07-performance.md). The original measured candidate identity and failed attempts are preserved; promotion does not claim a new physical-device run.
